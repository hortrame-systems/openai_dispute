# Deliberately omitted material

- Confidential Codex raw snapshot, authentication files, credentials, full prompts, unrelated source code and client/company content: privacy, access and purpose boundaries.
- Private identifier map, source account addresses, case/invoice/payment identifiers, Gmail message identifiers and private URLs: unnecessary to the public technical findings. Correlation uses consistent aliases.
- Bank/payment documents and individual remediation demand/calculation files: individual settlement is handled separately; their inclusion would add disclosure without closing the technical questions.
- Unrelated runtime eligibility, machine, agent-role and automation-schedule detail: removed or aliased where it does not change a reproduced result.
- Historical integrated HTML report: excluded because its broad narrative and embedded context were not approved for public disclosure. Its source hash remains in the provenance/omission inventory; bounded technical tables and correction history are retained.
- Private-package verification code that enforces the individual demand or private delivery profile: replaced by public verification, with source identity and reason retained.
- Full MIME/signatures and complete correspondence: minimized provider excerpts and reported receiver-authentication verdicts are included; original authentication remains controlled-access work.

These are disclosure decisions. They do not turn an unavailable source into evidence for or against a hypothesis. Every omitted source-package member has a reason and source hash in `OMISSIONS.csv`. The private alias map is kept outside the public archive.
