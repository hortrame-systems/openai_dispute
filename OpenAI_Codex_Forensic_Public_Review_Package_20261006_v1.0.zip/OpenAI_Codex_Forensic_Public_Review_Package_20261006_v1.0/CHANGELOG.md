# Change log from v1.6.4 to the public v1.0 derivative

The build source is the latest complete v1.7.0 package, as selected by the owner's later instruction. This is not a restoration of v1.6.4.

1. Replaced the cash-remedy framing with a public remediation boundary. The private credit request remains provisional and outside the public technical thesis.
2. Integrated the controlling v1.7.0 evidence classifications, post-event Priority configuration, provider-favorable 89.47% compatibility, credit/funding distinctions and provider-record needs.
3. Preserved the withdrawal of the v1.6.4 guardian token-range estimator. The demonstrated cross-turn counter error remains reproducible; no replacement range is invented.
4. Corrected guardian overlap: 21 local submissions include one represented persisted segment and 20 additional submissions.
5. Preserved the known-tier Priority cohort denominator and first-party-versus-provider currency distinction.
6. Added the two-regime working model with separate workload-generation and price/debit questions, without promoting a replay, orchestration or accounting hypothesis to fact.
7. Added later provider-authored escalation, pending-determination and closure correspondence, plus the latest AI-assisted case-state uncertainty.
8. Replaced direct identifiers and private locators consistently, minimized unrelated operational fields, and excluded confidential material while retaining source bindings.
9. Replaced private remedy-specific verification gates with public membership, privacy, path, claim-classification and reproduction checks. Included raw-dependent tools expose their access requirements.
10. Added GitHub, Developer Community and journalist drafts, an under-five-minute landing document, and explicit omission/reproduction boundaries.

Rejected hypotheses, contrary observations, sensitivity assumptions and correction history remain inspectable. Source packages are preserved unchanged.
