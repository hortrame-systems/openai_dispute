# Independent review guide

Start with README, CLAIMS and Support history. Rerun the public verifier and included reproductions; inspect current assumptions and contrary evidence. Test extraction-dependent claims only with permitted originals. A package or script PASS is not independent acceptance of causation, completeness, wrongdoing or entitlement. Report the exact claim, evidence, consequence and what would reverse a finding.
