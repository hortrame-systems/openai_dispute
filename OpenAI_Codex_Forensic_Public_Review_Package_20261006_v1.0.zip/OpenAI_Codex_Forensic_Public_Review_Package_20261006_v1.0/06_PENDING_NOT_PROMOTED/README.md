# Pending, not promoted

Files in this folder are preserved leads, not evidence or claims in this release.

`BILLING_CURRENCY_DELTA_20260919.md` references screenshots that are not present in the supplied source directory or authorized read-only raw snapshot. Do not rely on its amounts until the original images and calculation trail are obtained and verified.
