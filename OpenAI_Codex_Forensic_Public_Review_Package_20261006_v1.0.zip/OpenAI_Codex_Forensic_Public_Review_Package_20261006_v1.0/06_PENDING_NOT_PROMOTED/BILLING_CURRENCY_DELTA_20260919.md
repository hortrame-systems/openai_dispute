# Post-v1.5.6 billing/currency delta — 2026-09-19

Status: evidence/analysis delta awaiting incorporation into the next full master.

## New source material identified

File Library contains a 2026-09-19 billing screenshot set covering personal ChatGPT transaction history, workspace invoices, and a Desjardins card transaction.

The most directly load-bearing new pair is:

- ChatGPT billing history entry showing a 2026-09-19 `ChatGPT Pro 20x` charge displayed as `$229.95`.
- Desjardins transaction detail showing an OpenAI/ChatGPT card authorization of `330.38 $` dated 2026-09-19.

The broader branch reconciliation matched the OpenAI transaction history against bank transactions and treated the provider amounts and card-settlement amounts as different currencies. That reconciliation should be incorporated with its original screenshots and calculation trail, not merely as prose.

## Evidence boundary

This new material can support reconciliation of displayed provider charges against CAD card debits. It does **not**, by itself, prove what currency a historical upgrade page displayed when the user was logged out or at the moment of an earlier purchase. The user's recollection about what they saw remains recollection unless a contemporaneous screenshot/provider record establishes it.

## Source filenames currently visible in File Library

- `Screenshot from 2026-09-19 15-37-17.png` — personal transaction history; includes ChatGPT Pro 20x / credits entries.
- `ID_6562.png` — Desjardins OpenAI/ChatGPT transaction, 330.38 CAD, 2026-09-19.
- `Screenshot from 2026-09-19 15-35-53.png` — workspace invoice history.
- `Screenshot from 2026-09-19 15-36-14.png` — earlier workspace invoice entries.
- `Screenshot from 2026-09-19 15-37-26.png`
- `Screenshot from 2026-09-19 15-37-33.png`
- `Screenshot from 2026-09-19 15-37-39.png`
- `Screenshot from 2026-09-19 15-37-46.png` — historical personal transaction-history pages.

These image bytes are in File Library but are not exportable into the current sandbox through the available file-search interface. They therefore remain external dependencies for the physical next-master build.
