# Codex credit depletion: public forensic review package

Public release v1.0, identifier date 2026-10-06. Prepared from the complete v1.7.0 submission, with later support correspondence. All incident and support timestamps below are UTC unless stated otherwise.

## What happened?

The account owner reported recurring rapid credit use followed by an acute September 15 evening episode in America/Toronto (September 16 UTC). The owner states that Fast/Priority was never knowingly authorized. Local records show Priority settings, large cached-input accounting totals, additional guardian submissions, an authentication failure, catalog changes and inconsistent thread projections.

The working model distinguishes earlier elevated consumption from the acute large-context episode. Fast/Priority may explain a substantial part of earlier elevated consumption. A tier price multiplier alone does not explain why the acute workload repeatedly carried so much cached input. Context replay, orchestration, legitimate continuation and accounting behavior are competing explanations; none is established as the incident's cause.

## What does the client-side evidence establish?

- Six paired persisted task segments contain 56 usage updates and 50 post-initial continuations. Their final cumulative input counters sum to 29,225,371 tokens.
- Post-initial deltas total 26,386,511 input tokens, including 26,350,976 cached tokens. These are accounting counters across segments, not unique context size, physical resident memory or 29 million tokens in one request.
- Twenty-one guardian submissions are identified in local logs: one is represented in the six segments; twenty are additional. Their tokens and debits are unresolved.
- Five acute new-turn client requests carried Priority fields. Inputs attached to an older root are recorded, but the visible composer and intended task are unresolved.
- Within the specified September 2–15 known-tier settings cohort, 1,441 of 1,444 records were Priority. This is a settings-event statistic, not billed-token share.

The tables, calculation scripts and claim coverage identify which observations can be rederived from included evidence and which still require controlled source access.

## What does it not establish?

The archive does not prove wrong-account billing, unauthorized debits, double billing, deliberate task switching, a particular refund entitlement, or causation by a cache defect. Owner testimony, extracted client telemetry and provider accounting remain distinct. Some source-extraction and authentication claims require retained confidential originals.

## Why is Fast/Priority relevant?

It is a recorded tier state and a plausible cost multiplier. It does not identify its writer or establish informed authorization. A post-event configuration snapshot also contains Priority; that is an important local alternative, with historical effectiveness unresolved.

Current official documentation distinguishes included-limit and purchased-credit multipliers. It cannot establish September's effective terms. The package preserves the original analysis's frozen rate assumptions instead of silently substituting today's documentation. See [the dated documentation note](02_PUBLIC_REVIEW/DOCUMENTATION_AND_RATE_BOUNDARY.md).

## Why does Fast alone not explain the acute event?

The workload and the price applied to it are separate questions. A multiplier can increase charges for a given workload; it does not explain the creation, repetition or necessity of that workload.

There is substantial provider-favorable evidence: a frozen-rate scenario maps known-model usage in one reported balance interval to 651.3204 credits versus a nominal 728-credit decline, or 89.47% compatibility. This uses a cross-time conversion, reported balances and an assumed multiplier; it excludes unpriced guardian work. It neither proves historical billing correctness nor rules ordinary charging out. The unresolved additional question is workload generation and request/debit attribution, not a demonstrated extra overcharge.

## Which provider records would resolve the remaining questions?

Historical requested and resolved tier, authorization provenance, request-level usage and parentage, account/workspace/funding-pool attribution, effective pricing and multiplier stack, purchased-credit debits, balance and transaction ledger, delayed or negative settlement, and applicable adjustments. The detailed request is in [the provider-record schedule](02_PUBLIC_REVIEW/PROVIDER_RECORDS.md). Their absence client-side supplies no presumption for or against OpenAI.

## What has Support confirmed?

On October 3, provider-authored correspondence recorded CASE_A as open and escalated, with provider-side reconciliation pending and no confirmation that substantive examination had begun. That correspondence identified v1.7.0 as controlling, credits as the requested remedy, and a separate grant as unapplied to the disputed balance in the documented record.

CASE_B was subsequently closed with no verified billing error established, while acknowledging that the requested historical reconciliation had not been provided. A later AI-assisted reply in CASE_C could not confirm prior internal case states. This is a procedural tension between threads; it establishes neither intent nor a billing finding. Read [the dated support record](02_PUBLIC_REVIEW/SUPPORT_HISTORY.md).

## How can an independent reviewer reproduce the findings?

Use Python 3.11 or newer, preferably in a fresh virtual environment:

```text
python -B 05_VERIFICATION/verify_public_release.py
python -B 05_VERIFICATION/run_included_reproductions.py
```

The first command checks exact membership, every manifest hash, privacy patterns, current references and core calculations. The second reruns the included arithmetic and counter-boundary checks. [Reproduction instructions](05_VERIFICATION/PUBLIC_REPRODUCTION.md) distinguish distributed evidence from controlled-raw queries.

Confidential originals and the private alias map are withheld under a confidentiality boundary. Their source bindings and extraction limits are documented; this is not a claim that provenance is absent. Pseudonyms preserve internal joins, but exact times and unusual aggregates remain potentially linkable.

Individual remediation is being pursued separately through OpenAI's support process. This release concerns the technical and accounting evidence.
