# Supporting analyses

Analyses 15, 16 and 18 remain aggregate supporting material. Analysis 17 is historical and narrowed by current analyses 40 v0.2, 47 v0.3, 49 v0.5, 50 v1.2, 57, 58, 59 and 62.

The controlling claim ledger is 51 v1.6.9. The claimant credit-remedy implementation is 55 v1.6.9. The currency boundary is 57 v1.6.9. The evidence/disclosure map is 61 v0.1. The plan/credit remedy boundary is 62 v0.2.

Broad source tables are present only in the everything-substantive trusted-review profile.
