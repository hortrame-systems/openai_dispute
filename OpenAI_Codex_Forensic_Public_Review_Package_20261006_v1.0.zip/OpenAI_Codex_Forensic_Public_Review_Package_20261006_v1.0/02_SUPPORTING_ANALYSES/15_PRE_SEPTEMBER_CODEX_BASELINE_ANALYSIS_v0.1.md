# Pre-September Codex baseline analysis v0.1

**Date:** 2026-09-17  
**Status:** new standalone evidence-first analysis  
**Question:** What evidence exists before September 1, and when does sustained Codex use actually appear in the preserved corpus?

## 1. Primary-source chronology

The complaint extractor's source manifest contains preserved Codex rollout files in:

- **April 2026:** 4 rollout files, 360 message records;
- **May 2026:** 3 rollout files, 56 message records;
- **August 2026:** 679 rollout files, 23,026 message records;
- **September 2026:** 691 rollout files, 14,282 message records.

Therefore the recollection “I started using Codex mid-August” is **not established as literal first-ever use** by the current corpus. Preserved rollout activity exists earlier.

The earliest preserved rollout filename in the supplied manifest is dated **2026-04-24**, with multiple message-bearing rollouts that day.

After May, the next preserved activity begins **2026-08-04**:

- Aug 4: 2 rollout files / 462 message records;
- Aug 9: 3 / 20;
- Aug 10: 2 / 2,781;
- Aug 11: 2 / 733;
- Aug 12: 1 / 66;
- Aug 13: 5 / 268;
- Aug 14: 1 / 25.

This shows that substantial August Codex activity was already underway by Aug 10, before the middle of the month.

A separate question remains open: whether April/May were isolated earlier trials while August marks the start of **sustained HORTRAME/OLDER_TASK use**. That cannot be decided from filename chronology alone.

## 2. Large pre-Priority baseline

The first locally observed `service_tier=priority` event is already established at:

**2026-08-30 07:43:43.328 EDT**  
(2026-08-30 11:43:43.328 UTC)

Before Aug 30, the existing service-tier forensic extraction reports **1,100 / 1,100 observed billable-model settings as Default** and zero Priority.

The source manifest contains, in rollout files dated Aug 4–29:

- **457 rollout files**
- **17,848 message records**
- **2,764,111,787 source bytes**

This is a substantial pre-Priority comparison corpus. It should be treated as the principal behavioral baseline rather than beginning the integrity study on Sep 1.

Aug 30–31 alone then contain:

- **222 rollout files**
- **5,178 message records**

That creates a natural chronology:

1. earlier/isolated preserved Codex use: Apr–May;
2. August ramp-up / all-observed-Default period: Aug 4–29;
3. first Priority onset and oscillation: Aug 30–31;
4. predominantly Priority period: Sep 2 onward.

## 3. Complaint-extractor evidence before Priority

The broad complaint extractor produces **548 lexical candidate hits before the first Priority timestamp**, but these are not failure counts.

The overwhelming majority are broad matches such as `keep going` and `don't stop`, plus quality-control language. As already established in the complaint adjudication, raw lexical hits cannot be used as integrity incidence.

Importantly, the current extraction does **not** show a directly model-bound primary sycophancy complaint before first Priority onset. The two earlier `SYCOPHANCY` candidates in the corpus are May review-wrapper content with no direct primary-model binding.

This is only an extraction result. It is **not evidence that sycophancy never occurred before Priority**, because:

- the regex may miss different wording;
- not every interaction is model-bound;
- absence of a lexical complaint is not absence of the behavior.

## 4. Concrete Default-period errors exist before Priority

A useful pre-Priority counterexample occurs on **2026-08-14 15:52 EDT**, under **GPT-5.5 / Default**.

Immediately beforehand, the assistant reported:

> `44 failures / 48 attempts | fail 91.7% | success 8.3%`

and announced that the 25-failure stop threshold had been reached.

The owner responded:

> “That was clearly very wrong.”

The assistant then replied:

> “Bad count source. Fixing monitor method first ... no proxy guess.”

This is a directly preserved measurement/counting failure under Default.

It does not establish a comparable rate against Priority, but it demonstrates that consequential integrity/measurement errors predate Priority onset.

## 5. Evidence of good epistemic behavior under Default also exists

The pre-Priority period should not be treated only as a source of errors.

On **2026-08-20 14:03 EDT**, under **GPT-5.6 Sol / Default**, the owner asked whether the system was “filling it up with bullshit.”

The assistant did not simply reassure. It reported that only 3/3 currently examined victims were confirmed, explicitly stated that three observations were far too few to establish the expected rate, gave a 95% confidence lower bound of 43.9%, and flagged a possible metadata error for further checking.

Later that day, when the owner requested a random sample of HIGH-confidence cases, the assistant reported that the sample had already exposed **2 of 25 HIGH-confidence rows pointing to GoDaddy ‘for sale’ pages**, called them invalid HIGH-confidence victim confirmations, and continued the audit.

These examples are useful negative controls: the Default-period corpus contains both errors and explicit self-limiting / adversarial behavior.

## 6. What happens Aug 30–31

The first Priority transition occurs Aug 30 at 07:43 EDT.

The previously established tier extraction shows the broader Aug 30–Sep 1 interval contains a mix of Default and Priority settings rather than a clean one-time switch.

Before local midnight Sep 1, the complaint extractor contains many apparent sycophancy candidates, but manual inspection shows the directly model-bound Sol candidates on Aug 31 (`C00016`, `C00017`) are **preventive/protocol language about avoiding sycophancy**, not owner complaints that current behavior was sycophantic.

Therefore, based on current adjudicated complaint evidence:

- a clear pre-Priority integrity error exists under Default;
- explicit sycophancy complaints become clearly documented on Sep 1 and later;
- the absence of a validated Aug 30–31 sycophancy complaint cannot be promoted into an onset claim.

## 7. Consequence for study design

The behavioral study should use **Aug 4–29** as the principal pre-Priority baseline, with a possible narrower high-intensity baseline beginning Aug 10.

The study should not use “before Sep 1” as synonymous with “before Fast,” because Priority first appears on Aug 30.

Recommended windows:

### Baseline A — broad preserved pre-Priority August
Aug 4 through Aug 29.

### Baseline B — intensive-use pre-Priority
Aug 10 through Aug 29.

This controls somewhat better for the user's later high-volume work pattern.

### Transition window
Aug 30 through Sep 1, analyzed using actual per-message/per-task tier rather than date.

### Persistent-Priority window
Sep 2 onward, again using exact structured tier when possible.

April/May should be retained as an older historical control but not automatically pooled with August because workload, client version, model, and project context may differ.

## 8. Claim-status table

| Claim | Status |
|---|---|
| The preserved corpus contains Codex rollouts before mid-August | **ESTABLISHED** |
| Earliest preserved rollout in this corpus is Apr 24 | **ESTABLISHED from manifest** |
| August Codex activity is present by Aug 4 | **ESTABLISHED** |
| Intensive August use is present by Aug 10 | **ESTABLISHED from rollout/message volume** |
| The user first-ever started Codex in mid-August | **CONTRADICTED as a literal statement by current preserved corpus, unless earlier sessions are outside the intended meaning of 'started'** |
| Sustained HORTRAME/OLDER_TASK Codex use began in mid-August | **UNRESOLVED; likely needs an operational definition** |
| Before first Priority, observed billable settings were Default | **ESTABLISHED in the existing tier extraction: 1,100/1,100** |
| Consequential integrity errors existed before Priority | **ESTABLISHED by at least one preserved Default-period example** |
| Sycophancy did not occur before Priority | **NOT ESTABLISHED** |
| Validated explicit sycophancy complaints are currently observed only after Priority begins | **ESTABLISHED within current complaint extraction/adjudication; not an incidence or causality claim** |
| Priority caused the later complaints | **UNRESOLVED** |

## 9. Next evidence

The message-exposure denominator extraction should cover the entire preserved corpus, not begin Sep 1.

After it returns, rate analysis should report at minimum:

- Apr–May historical control;
- Aug 4–9 early August;
- Aug 10–29 intensive pre-Priority baseline;
- Aug 30–Sep 1 exact tier-resolved transition window;
- Sep 2 onward persistent-Priority period.

This avoids selecting a baseline after the anomaly had already started.

## Conclusion

The evidence says the relevant baseline starts **well before September 1**.

The preserved corpus contains substantial activity before the first Priority event, including 17,848 message records in Aug 4–29 rollout files and at least one concrete integrity/measurement failure under Default. Therefore any study that begins at Sep 1 would discard the strongest available control period.

The correct comparison is not “before Sep 1 versus after Sep 1.” It is **exact Default exposure before and during Aug 30–Sep 1 versus exact Priority exposure**, with Aug 4–29 serving as the large pre-Priority behavioral baseline.
