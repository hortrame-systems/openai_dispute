# Credit / quota depletion speed — primary forensic analysis v0.1

**Date:** 2026-09-17  
**Status:** exploratory evidence-first analysis  
**Primary question:** Did effective Codex quota / purchased-credit depletion accelerate around the Aug 30 Priority onset, and can the observed change be explained by a comparable increase in locally visible work?

## 1. Study priority correction

The main forensic question is **usage economics and depletion speed**, not model-quality degradation.

Integrity failures are relevant only as possible explanatory evidence for extra work, retries, looping, or orchestration. They are not the primary outcome.

The primary outcome should be:

> quota / credit consumed per unit of comparable locally visible work, before versus after the first observed Priority state.

## 2. Established chronology

### Personal-account reset inventory

The preserved reset history records:

- reset received: **2026-08-21 20:18 EDT**
- reset used: **2026-08-31 21:24 EDT**

Elapsed hold time:

- **241.1 hours**
- **10.0458 days**

This is directly preserved in the reset-history screenshot and independently transcribed into the cost/capacity tracker.

This does not by itself prove the weekly allowance was not exhausted during those ten days. It proves only that this particular manual reset remained unused until Aug 31.

### First locally observed Priority

The existing tier extraction places the first observed `service_tier=priority` at:

**2026-08-30 07:43:43.328 EDT**

The manual reset was used about:

**37.67 hours after that first Priority observation.**

### Purchased-credit anomaly

The preserved forensic chronology records:

- first large auto-reload: approximately **Aug 31 19:13 EDT**, 5,125 displayed credits / $164.99;
- second large auto-reload: approximately **Aug 31 21:14 EDT**, 5,048 displayed credits / $162.51;
- interval: approximately **2.02 hours**;
- personal manual reset used: **Aug 31 21:24 EDT**, about 10 minutes after the second reload;
- support case opened: **Sep 1 01:31 UTC / Aug 31 21:31 EDT**, about 17 minutes after the second reload.

The exact request-to-debit sequence is not locally available. Therefore the defensible statement remains:

> the system triggered a second large automatic reload roughly two hours after the first.

It is not yet established that exactly 5,125 credits were debited to zero during that interval.

## 3. Was the visible workload itself unprecedented?

Local task-start counts provide one useful workload proxy. They are **not** equivalent to token volume or billed work, but they can test the simplest explanation: that Aug 31 merely contained orders-of-magnitude more task activity.

### Daily task starts

- Aug 26: 350
- Aug 27: 331
- Aug 28: 523
- Aug 29: 1049
- Aug 30: 571
- Aug 31: 1274

Aug 31 therefore had about **1.21×** as many task starts as Aug 29.

That is a material increase, but it is not an orders-of-magnitude increase.

### Two-hour burst comparison

The approximate two-hour interval between the two large Aug 31 reloads contains:

- **128 task starts**
- 70 explicitly Priority
- 29 explicitly Default
- 29 without a tier value in this safe extraction
- 84 VS Code-source task starts
- 44 subagent task starts

However, the **largest two-hour task-start burst before the first observed Priority** in the Aug 19–30 baseline was:

- **381 task starts**
- from 2026-08-29T12:36:55.431000-04:00 to 2026-08-29T14:36:55.431000-04:00

The largest two-hour burst after first Priority but before Sep 1 was:

- **277 task starts**
- from 2026-08-31T15:23:03.280000-04:00 to 2026-08-31T17:23:03.280000-04:00

Therefore the local record already contains at least one **higher task-start-rate period before Priority** than any two-hour period after Priority on Aug 30–31.

This is important negative evidence against the simplest hypothesis:

> “the credits dropped unusually fast only because the user suddenly initiated far more tasks per unit time.”

It does **not** rule out greater token volume per task, larger context replay, different models, additional hidden orchestration, or different quota weighting.

## 4. Other workload proxies

The rollout manifest also gives coarse local-volume proxies.

### Aug 29 — pre-Priority day

- 101 rollout files
- 2284 message records
- 299,437,591 source bytes
- 1049 task starts

### Aug 31 — mixed Default/Priority day

- 161 rollout files
- 3477 message records
- 876,017,789 source bytes
- 1274 task starts

Relative to Aug 29, Aug 31 has approximately:

- **1.21× task starts**
- **1.52× message records**
- **2.93× local rollout bytes**

These are imperfect proxies, not billing units. The task/message increases are nowhere near orders of magnitude; local source bytes are about 2.9× higher.

## 5. What this establishes

### ESTABLISHED

- A personal manual reset received Aug 21 remained unused until Aug 31 21:24 EDT.
- The first locally observed Priority state occurs Aug 30 07:43:43 EDT.
- Two large personal-account automatic reload transactions occur around Aug 31/Sep 1, roughly two hours apart.
- The billing problem was reported contemporaneously within minutes after the second reload.
- Aug 31 contains more local activity than Aug 29 by several proxies.
- The increase in task starts and message records is modest relative to the scale implied by the reported credit-depletion discontinuity.
- A two-hour pre-Priority period on Aug 29 contains **more task starts** than any two-hour Aug 30–31 post-onset period in the current safe task extraction.

### NOT ESTABLISHED

- The first 5,125-credit reload was literally debited to zero in two hours.
- Priority caused the second reload.
- The quota/credit cost per token increased by a specific factor.
- Aug 31 token volume was comparable to Aug 29 token volume.
- Manual-reset use proves a weekly allowance was exhausted at that exact moment.
- The local task count captures all provider-side work.

## 6. Most important missing evidence

To make the depletion-speed case quantitative, the study needs two synchronized series:

### A. Work performed

For comparable periods:

- request / completed-response count;
- input tokens;
- cached-input tokens;
- output tokens;
- reasoning tokens;
- context size;
- tool/model cycles;
- subagent/background activity.

### B. Capacity consumed

At matching timestamps:

- weekly quota remaining;
- five-hour quota remaining, if applicable;
- purchased-credit balance;
- automatic reload threshold;
- debit amount per request;
- manual reset state.

Then compute:

- quota percentage per million input tokens;
- quota percentage per million cached tokens;
- purchased credits per million tokens;
- purchased credits per completed response;
- purchased credits per task start;
- depletion rate per active hour.

## 7. Critical limitation of current local extraction

The current `token_usage_events.csv` begins on Sep 4. It therefore cannot yet supply the Aug 19–31 token-volume denominator.

The raw Codex rollout corpus may contain older-format rate-limit/quota/token observations that were not included in the current safe extraction.

A dedicated deterministic historical quota/usage extractor should therefore be the next technical pass.

## Conclusion

The strongest current evidence is a **temporal and workload-normalized anomaly lead**, not yet a priced causal result.

The personal account carried an unused manual reset for roughly ten days before the Aug 31 event. Priority first appears on Aug 30. The following evening, two large auto-reloads occur about two hours apart, the stored reset is used minutes later, and the user opens a billing dispute almost immediately.

At the same time, locally visible work did increase on Aug 31, but simple activity counts do **not** show an orders-of-magnitude increase. Indeed, the raw task log contains a higher two-hour task-start burst before Priority than after it.

That makes “vastly more user-initiated tasks” insufficient as a complete explanation on present evidence.

The decisive next question is whether **tokens/context/replay per task** or **quota/credit weighting per unit of comparable work** changed around Aug 30.
