# User attestation — Fast/Priority non-authorization

**Date recorded:** 2026-09-21  
**Affected period:** 2026-08-30 through 2026-09-15  
**Source class:** first-party human testimony  
**Independent corroboration:** no exact `/fast` command in the searched local corpus; historical client/provider authorization records remain required

## Attestation

In direct response to whether they knowingly enabled or authorized Fast/Priority during the affected period through a command, UI toggle, saved setting, workspace/admin setting, automation or any other method, the account owner stated:

> “Absolutely not. Never. I do not use the fast models, they're not safe for the work I do.”

## Scope

The owner denies knowingly authorizing Fast/Priority through every mechanism named in the question. The statement addresses conscious authorization, not whether the client nevertheless transmitted or resolved `service_tier=priority`.

## Evidentiary effect

This is current, scoped first-party testimony. It is not client telemetry and cannot identify the setting writer by itself. It increases the importance of UI/config/managed-default/catalog provenance for the Priority state. A provider response that only shows the transmitted tier does not contradict the attestation; a contrary authorization finding would require an attributable deliberate-authorization event or equivalent evidence.
