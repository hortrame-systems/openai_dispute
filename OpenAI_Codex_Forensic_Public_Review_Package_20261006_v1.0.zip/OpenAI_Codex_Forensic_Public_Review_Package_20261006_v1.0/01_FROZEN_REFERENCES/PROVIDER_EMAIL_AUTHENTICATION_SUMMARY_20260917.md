# Provider email authentication summary

**Date of connector verification:** 2026-09-17  
**Source:** connected Gmail account, raw MIME requested through the provider connector  
**Scope:** two automatic-reload notices and the September 17 support reply

This artifact records authentication and message metadata independently re-read from the connected mailbox during the v1.5 review. It is not a substitute for preserving the complete RFC822/EML source. Full raw-message exports remain external to this ZIP.

## Automatic reload — invoice INVOICE_0003

- Gmail message ID: `1a05a19c98b51165`
- Date header: 2026-08-31 23:13:54 UTC
- From: OpenAI `<ACCOUNT_0002>`
- Message-ID: `<178821803347.242.10556400155501026791@sa-server-8bf568dd5-vlkmr>`
- DKIM: pass for `tm.openai.com`
- SPF: pass
- DMARC: pass for `tm.openai.com`
- Message states that $164.99 was charged to automatically add 5,125 credits under the current auto-reload settings.
- Invoice number: INVOICE_0003

## Automatic reload — invoice INVOICE_0004

- Gmail message ID: `1a05a884fc05b82d`
- Date header: 2026-09-01 01:14:37 UTC
- From: OpenAI `<ACCOUNT_0002>`
- Message-ID: `<178822527650.195.3097102968612014189@sa-server-5dbcf76f78-sgngj>`
- DKIM: pass for `tm.openai.com`
- SPF: pass
- DMARC: pass for `tm.openai.com`
- Message states that $162.51 was charged to automatically add 5,048 credits under the current auto-reload settings.
- Invoice number: INVOICE_0004

## Support reply — Case CASE_PREDECESSOR

- Gmail message ID: `1a0af5dfe8e3541e`
- Date header: 2026-09-17 12:36:06 UTC
- From: OpenAI Support `<PROVIDER_SUPPORT_MAILBOX>`
- Message-ID: `<ACCOUNT_0001>`
- DKIM: pass for `openai.com`
- SPF: pass
- DMARC: pass for `openai.com`

The message states, in substance, that the information available to the handling support agent does not show the historical auto-reload maximum for invoices INVOICE_0003 and INVOICE_0004 and does not provide the transaction-level ledger needed to reconstruct balances and intervening debits. The agent therefore does not classify the transactions as a billing error or determine a refund amount from the available records.

## Evidentiary status

The authentication results materially strengthen provenance for the existence and sender-domain authenticity of the three messages. The package still does not contain the complete raw MIME bytes, so an offline reviewer cannot independently rerun DKIM verification from this ZIP alone. That limitation remains explicit.
