# Owner statement on transaction currency

**Recorded:** 2026-09-22  
**Source:** owner's direct statement in the dispute-package task  
**Exact statement:** “Everything is in USD, I confirmed it in my bank account.”

## Evidentiary classification

This is first-party testimony that the relevant bank-account transactions were denominated in USD. It supports typing the Event A payment-instrument currency as owner-attested USD.

The bank statement itself is not embedded in this package. The statement therefore does not independently establish OpenAI's internal transaction/accounting currency, historical contract terms, debit validity or liability.

Event B has a separate basis: contemporaneous user-authored messages represented the balance endpoints as `US$33.72` and `US$4.60`. That first-party USD representation likewise does not convert the endpoints into provider ledger rows.

The package keeps these evidence types separate while using them as the stated first-party basis for the US$356.62 opening settlement position.
