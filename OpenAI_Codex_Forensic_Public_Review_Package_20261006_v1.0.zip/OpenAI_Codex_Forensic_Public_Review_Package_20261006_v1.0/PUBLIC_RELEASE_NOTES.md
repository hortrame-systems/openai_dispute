# Public release notes — v1.0

This public derivative uses the complete v1.7.0 package as its source. The source passed its original verifier and matches the ZIP hash recorded by Support. Earlier v1.6.4 material is retained only where it documents source lineage, adverse findings or supersession.

The public edition retains broad structured telemetry needed to examine settings cohorts, activity, context counters, transitions and correlation. Direct identifiers are replaced consistently; unused operational fields are removed or withheld. Raw prompts, credentials, client content, bank/payment details, private mapping and the confidential snapshot are excluded.

Current claim categories distinguish client observation, derived result, testimony, working hypothesis, public/examined external observation, provider-controlled unknown and rejected/superseded claim. Supporting data does not inherit a stronger status from a verifier PASS.

The public incident model separates chronic elevated consumption from the acute large-context episode. It preserves the original 89.47% conditional charging compatibility and post-event Priority configuration as material counterevidence. It makes no finding that Fast itself could not charge for the observed workload. A further explanation of workload generation remains unresolved.

Later Support messages are represented by dated, minimized excerpts and procedural summaries. Their receiver-reported authentication results are retained as an observation; this archive cannot independently authenticate the full withheld messages. CASE_A's last documented open/escalated status is dated, CASE_B's closure is preserved with its stated reasons, and CASE_C's inability to confirm internal states is included.

The original cash request is withdrawn as a current claim. Individual credit remediation, entitlement and any settlement calculation remain in the private support process. Historic demands may remain only as labelled correction history.

The verifier checks package bytes and selected calculations. Confidential-source extraction, provider completeness, causal entailment and independent reviewer conclusions remain separate. Raw-source helpers require controlled source access and, where identities are needed for selection, the privately held source-identity map. They do not silently use an installed user's Codex home.

The archive is prepared for public review. Companion posts are drafts. No external publication, issue, forum post or journalist message is created by building it.

See `SOURCE_PROVENANCE.csv` for source-to-public transformations, `OMISSIONS.csv` and `DELIBERATE_OMISSIONS.md` for exclusions, and `CHANGELOG.md` for consequential corrections.

Preparation and analysis used AI assistance. Executable checks, attributable source records and correction history accompany the text. AI peer review does not constitute independent human peer review, provider confirmation or certification of the incident's cause.

**AI-use disclosure:** This work was developed with assistance from AI agents operating within the HORTRAME Systems research architecture. Depending on the research stage, these agents contributed to literature analysis, mathematical formulation, proof reconstruction, adversarial review, counterexample search, simulation and code analysis, verification design, reproducibility checks, revision, and manuscript preparation. AI-agent outputs were treated as research artifacts subject to verification and correction rather than as independent authority. G. Bolduc is the human author responsible for the manuscript, its claims, source selection, and publication decisions. AI-agent review does not constitute independent human peer review, proof-assistant certification, experimental validation, or publication acceptance.
