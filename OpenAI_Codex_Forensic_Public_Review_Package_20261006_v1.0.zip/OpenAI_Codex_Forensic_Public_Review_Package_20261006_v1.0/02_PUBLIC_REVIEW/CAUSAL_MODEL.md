# Two-regime working model and competing explanations

## Earlier elevated consumption

The earlier-period interpretation concerns observed Priority settings and the examined Fast-labelled purchased-credit export. The settings cohort and the export measure different populations. They do not supply a workload-normalized historical billing comparison. Fast/Priority may explain a substantial part of elevated consumption if the historical multiplier and funding rules were applicable.

## Acute large-context episode

The reproduced acute trace covers September 15 evening America/Toronto, September 16 UTC. It establishes large cumulative input/cached-input quantities across six persisted segments and repeated continuations, with additional guardian submissions. It does not establish unique resident memory, one request containing the aggregate, or a complete provider request inventory. A wider September 14–15 incident description is not wholly reconstructed by this narrower trace.

## Separate workload and price questions

A fixed price multiplier can raise cost for a given workload. Under that mathematical assumption it does not create or repeat the workload. A Fast implementation could have other behavior; the client record does not rule that out or establish it. Thus “Fast alone does not explain the acute event” means the price multiplier alone leaves workload generation and attribution unanswered, rather than proving that ordinary charging could not explain the observed balance movement.

The 89.47% frozen-rate compatibility calculation is retained. A multiplier-only 2x alternative is also shown with other assumptions fixed. Neither reconstructs September's historical terms. Unpriced guardian work, reported rather than provider balance endpoints, settlement timing and funding identity remain unresolved.

The models-manager file cache discussed in the historical public-code record concerns model-catalog eligibility and provider/auth binding. The inference accounting field `cached_input_tokens` concerns input processing. These are different caches. The catalog-cache weakness does not establish duplicated prompt processing, incorrect cached-input accounting or incident causation.

## Competing explanations and discriminating evidence

| Explanation | Surviving support | Limit / discriminating record |
| --- | --- | --- |
| Legitimate large-context continuation | Repeated usage updates and cached deltas; substantial conditional charging compatibility | Request-level context boundaries, useful work, parentage and historical debit rules |
| Client instruction/context accumulation or orchestration | Large cumulative context and background review traffic are compatible | Actual request construction, per-request token boundaries and parentage |
| Context replay or redundant dispatch | A mechanism that could repeat input | No incident-specific duplicate/replay proof; provider request IDs, deduplication and debits |
| Tier/configuration/catalog pathway | Priority client fields, post-event Priority configuration and exact-runtime cache mechanism evidence | Historical writer, effective configuration/catalog and auth binding |
| Account/funding or settlement behavior | Linked symptoms require reconciliation | Provider account/workspace/pool mapping, pricing, debit/balance and settlement ledger |

The regimes are a working decomposition of the incident, not a statistically validated change point or two established defects. Rejecting one mechanism need not erase the observations or establish another.
