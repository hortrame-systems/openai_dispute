# Documentation and rate boundary

The source package's sensitivity calculations use its frozen reference rates and a 2.5x Fast assumption. They are retained as conditional calculations. They do not reconstruct September's historical rates, funding pool, multiplier stack or final debits.

During public-release preparation, the fetched [official Speed page](https://learn.chatgpt.com/docs/agent-configuration/speed) distinguished 2.5x included-limit consumption from 2x purchased-credit and Enterprise pay-as-you-go billing. That present statement is material contrary context for treating 2.5x as a universal purchased-credit multiplier. It does not identify the terms effective for the disputed September requests.

The [API Fast guide](https://developers.openai.com/api/docs/guides/fast-mode) describes `priority` and `fast` request values and response-tier reporting. API token pricing and ChatGPT credit multipliers must not be conflated.

For a transparent multiplier-only sensitivity, holding the old scenario's other assumptions fixed, replacing 2.5x with 2x scales 651.3204 to 521.05632 credits. This is neither a new historical charge reconstruction nor a provider-proven reduction.

The exact runtime cache references inherited from v1.7.0 are public-source implementation observations with incident-causation limits. A provider-unscoped cache eligibility weakness and a later cache-isolation correction do not show that this incident invoked the weakness. The original verification record remains under `02_CURRENT_ANALYSES`.

Public-source pages are mutable. The observation here is a dated preparation snapshot associated with release identifier 20261006, not a guarantee of future pricing or account-specific behavior.
