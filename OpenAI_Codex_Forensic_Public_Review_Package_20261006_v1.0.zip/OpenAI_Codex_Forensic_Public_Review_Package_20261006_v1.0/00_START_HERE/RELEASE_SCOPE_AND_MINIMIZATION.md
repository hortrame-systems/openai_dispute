# Release scope and profiles

v1.6.9 is issued in two profiles. Both separate evidence/inference under `02_CURRENT_ANALYSES`, claimant-selected credit remedy under `03_CLAIMANT_POSITION`, and review under `04_REVIEW`.

## Independent external reviewer

Contains the current controlling case, claim-specific evidence, source coverage and portable reproduction materials. It excludes broad unrelated telemetry and historical HTML.

Run:

`05_VERIFICATION/verify_external_reviewer_materials_v1.6.9.py`

## Everything substantive

Adds broad safe telemetry, complaint/source inventory, historical report, exact historical scripts and superseded analysis. Stable ChatGPT host/project identifiers are replaced with package-local pseudonyms. This profile remains restricted to trusted reviewers.

Run:

`05_VERIFICATION/verify_everything_substantive_v1.6.9.py`

## Common exclusions

The confidential raw snapshot and Tier Guard remain separately preserved and undistributed. Neither package's directory name or verifier PASS constitutes independent substantive validation.
