# Parent reconstruction limitation

Two integrity statements must be kept separate.

1. **Extracted-content verification passed.** All 230 files in the v1.5.5 parent manifest were reconstructed and matched their expected SHA-256 values.
2. **Current-runtime carrier byte identity did not reproduce.** Re-zipping that verified tree under Python 3.12.14 with zlib 1.3.2 produced SHA-256 `df66733d60b561464e7748dbd0dbf9332138ea3c8c2f237c4e0e46a8f4b07240`, not the historical carrier SHA-256 `413f3e308653b39df0a9407cae27d77546ef3ae014384679097856d20ccd0069`.

ZIP byte identity can depend on archive metadata and compression/runtime behavior even when extracted contents match. This release relies on the verified extracted-file manifest and the independently verified v1.5.6 source ZIP, not on a claim that the historical v1.5.5 carrier can be reproduced byte-for-byte across runtimes.
