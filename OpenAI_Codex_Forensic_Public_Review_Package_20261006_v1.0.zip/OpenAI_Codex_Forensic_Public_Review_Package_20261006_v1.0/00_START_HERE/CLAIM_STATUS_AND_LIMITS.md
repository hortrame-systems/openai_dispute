# Public review entrypoint

Read [the public README](../README.md), [provider records](../02_PUBLIC_REVIEW/PROVIDER_RECORDS.md) and [release notes](../PUBLIC_RELEASE_NOTES.md). Individual remediation remains in the private support process.
