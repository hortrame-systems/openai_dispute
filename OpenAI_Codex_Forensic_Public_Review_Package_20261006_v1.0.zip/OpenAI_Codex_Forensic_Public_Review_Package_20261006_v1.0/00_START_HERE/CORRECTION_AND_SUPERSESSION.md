# Correction and supersession map — v1.6.9

v1.6.9 supersedes v1.6.8 for circulation. v1.6.8 remains archived intact.

## Corrections

- withdrew the US$356.62 request because dollar aggregation is the wrong remedy metric across nonuniform plan surfaces;
- separated subscription/seat allowance, manual credit purchases, automatic reload funding and purchased-credit debits;
- recorded 10,173 exact Event A reload credits, the 14,287.106991-credit workspace export, its 5,004.180745 September 15 bucket and the 8,570.9725482-credit conditional Fast-premium sensitivity without adding overlapping figures;
- superseded the PRIVATE_REMEDIATION_AMOUNT_WITHHELD-credit component-selection request with one non-overlapping PRIVATE_REMEDIATION_AMOUNT_WITHHELD-credit grand total;
- combined 10,173 Event A credits with the conditional 8,570.9725482-credit full-export Fast-premium component while excluding the overlapping September 15 bucket;
- refused to convert the US$164.17 residual manual-purchase funding into credits without purchase/balance records;
- preserved personal `ChatGPT Pro 20x` local corroboration while typing US$200 personal and US$125/10x Work plan details as owner testimony where provider records are absent;
- retained the earlier v1.6.8 corrections below;
- removed the v1.6.6 review-layer commitment to preserve the owner's preferred settlement stance;
- separated the forensic review from the claimant-selected NORM/ACTION layer;
- retained the post-event `service_tier="priority"` configuration snapshot as CL169-36 with strict temporal limits;
- moved the 89.47% current-rate compatibility alternative into the executive foreground;
- replaced Event A “anomaly” wording with “rapid-depletion/reload episode requiring reconciliation”;
- replaced direct provider “must” language with the epistemic need for records and an explicit request;
- added claimant/account-holder/payer/negotiation/reimbursement authority mapping without inventing identity equivalence;
- assigned every claim a disclosure/evidence class;
- restored the missing provider-email authentication summary used by both Event A components;
- separated first-party USD representation/attestation from provider-authoritative accounting currency;
- demoted the fixed approximately 5,000-credit target from a supported alternative to a provider-configuration-dependent hypothesis;
- added deterministic component-reference and claim-source path checks, without claiming automated semantic validation;
- permitted privacy-preserving linked identifiers and attributable provider attestation while rejecting aggregate assurance;
- “presumed due” / “permitted reduction” → opening settlement demand maintained pending request-level reconciliation;
- unilateral burden language → explicit settlement posture without asserted legal/contractual authority;
- missing current Fast testimony → dated first-party non-authorization attestation;
- generic cache failure class → exact `rust-v0.154.0-alpha.6.2` implementation evidence plus later fix;
- `07_INDEPENDENT_REVIEW` → `07_EXTERNAL_REVIEW_MATERIALS`, which does not imply completed independent validation;
- package-generic README → profile-specific README and verifier instructions;
- broad stable ChatGPT host/project identifiers in trusted-review telemetry → deterministic package-local pseudonyms;
- 21 guardian submissions outside the six segments → 21 total, one represented in the six and 20 additional;
- v1.6.4 guardian token range → suspended after a demonstrated cross-turn counter-boundary defect;
- first-party Event B `US$` representation and provider-authoritative currency now occupy separate machine fields;
- 1,441/1,444 Priority → America/Toronto Sep. 2–15, known-tier GPT-5.6 Sol/GPT-6 Astra settings, with model and missing-tier exclusions explicit;
- “user-initiated” characterization → MESSAGE_0004 inputs whose visible composer, device, intended task and authorization remain unresolved;
- v1.6.7 compatibility/reproduction boundaries retained.

The forensic review states the strongest surviving evidentiary proposition independently of the claimant's credit request. The exact final remedy remains a provider-ledger calculation; the separate claimant layer records a provisional request without presenting it as review-derived.
