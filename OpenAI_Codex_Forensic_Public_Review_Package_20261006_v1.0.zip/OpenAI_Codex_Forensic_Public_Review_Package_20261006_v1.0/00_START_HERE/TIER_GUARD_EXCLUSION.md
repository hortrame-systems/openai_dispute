# Tier Guard exclusion

At the owner's direction, Tier Guard software, rescue/prepackage carriers, historical Tier Guard builds, and Tier Guard-only analyses are excluded from this OpenAI evidence package.

This exclusion does not remove the underlying Priority/Fast observations, transition evidence, or billing-label evidence. Those are dispute evidence independent of the separate Tier Guard tool.

The standalone Tier Guard files are preserved outside the release under `separate/tier_guard`, with original filenames, hashes, and an audit ledger. Nothing was deleted.
