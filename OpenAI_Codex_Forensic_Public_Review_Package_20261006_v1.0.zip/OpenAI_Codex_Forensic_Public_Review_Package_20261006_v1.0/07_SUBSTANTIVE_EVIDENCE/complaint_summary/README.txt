Complaint-anchored extraction complete.

source_files_scanned=1389
source_bytes_scanned=7334439830
safe_user_assistant_messages=37724
complaint_hits=1688
source_inventory_sha256=34c6c9c3a0246ecaa6a96fea53a0f0f96216cd0dda3392894fbfb9d5e83bc263

Candidate hits are lexical/semantic-pattern leads, not validated integrity failures.
Review COMPLAINT_CONTEXT.csv before causal interpretation.

Privacy boundary: exports explicit user/assistant natural-language messages only.
Reasoning, tool calls/results, system/developer content, environment-only messages,
encrypted content, and other record classes are excluded by construction.
