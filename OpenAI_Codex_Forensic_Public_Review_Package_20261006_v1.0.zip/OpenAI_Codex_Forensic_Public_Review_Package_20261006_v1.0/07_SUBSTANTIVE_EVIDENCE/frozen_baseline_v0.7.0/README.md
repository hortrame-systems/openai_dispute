# Frozen baseline reference

`Codex_Forensic_Baseline_v0.7.0.html` is extracted from the preserved historical carrier `Codex_Forensic_Adversarial_Review_WIP_v0.7.0.zip` and retained because the current claim ledger cites the frozen v0.7.0 baseline for several Priority/Fast and purchased-credit facts.

The historical carrier itself is not nested in this release. Its package-level descriptions referred to a broader evidence tree that is not present in that small WIP carrier. This release therefore treats the HTML as a historical integrated report, not as a complete standalone evidence package. The current safe tables, claim ledger, and release manifest are controlling.

Source carrier SHA-256: `082aa44e43374e2179bfd9d329af3ee21a6e1f2e5418be75ab46c07a73f13689`
