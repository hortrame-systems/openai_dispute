# Substantive supporting evidence

This directory restores broad safe telemetry, complaint/source inventory and the historical integrated report.

The historical HTML contains superseded language and is non-controlling. The broad tables contain extensive operational metadata. Host/user and project identifiers in `stage2safe/local_thread_catalog_safe.csv` are replaced with deterministic package-local pseudonyms; other thread/task/timing metadata remains.

Use `SUBSTANTIVE_INVENTORY.csv` to verify membership and hashes. Current claim status is defined only by the v1.6.9 claim ledger.
