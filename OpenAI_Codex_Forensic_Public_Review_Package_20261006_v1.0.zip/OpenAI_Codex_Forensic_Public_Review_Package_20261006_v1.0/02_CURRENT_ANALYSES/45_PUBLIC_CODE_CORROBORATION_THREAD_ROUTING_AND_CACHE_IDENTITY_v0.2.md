# Public OpenAI code corroboration — exact-runtime cache identity and routing v0.2

**Verified:** 2026-09-21  
**Role:** mechanism-class and exact-runtime implementation evidence; not incident-specific causation

## Exact Event B runtime cache weakness

The affected local rows identify Codex CLI `0.154.0-alpha.6.2`. OpenAI's public source at tag `rust-v0.154.0-alpha.6.2` contains this cache-eligibility TODO in `models-manager/src/manager.rs`:

> Include provider identity in cache eligibility so switching providers does not reuse a fresh `models_cache.json` entry from another provider.

At the same tag, `ModelsCacheEntry` in `models-manager/src/cache.rs` contains `fetched_at`, `etag`, `client_version` and `models`, with no provider or auth-identity field.

Sources:

- http<PRIVATE_PATH>
- http<PRIVATE_PATH>

This proves the relevant public runtime line retained a provider-isolation weakness in the file-cache eligibility path. It does not prove that an actual provider/account switch invoked the weakness during Event B or that it caused a debit.

## Later OpenAI fix

Commit `f046cf35df0978a628d78a7d4bb6b1d3362a27dd` says switching providers or authentication could reuse a previous identity's catalog, including its default service tier. The fix adds provider/auth identity matching and treats legacy identity-less entries as misses.

Source:

- http<PRIVATE_PATH>

The exact-tag source and later fix together materially support a provider investigation into catalog/tier provenance. They remain mechanism evidence, not proof of account-specific causation.

## Same-runtime routing report

Public issue #45709 reports Windows Desktop using one UI/persisted thread ID while `turn/started` and `turn/completed` arrived under another conversation ID. It identifies bundled CLI `0.154.0-alpha.6.2` and a September 15, 2026 reproduction.

Source:

- http<PRIVATE_PATH>

This is a contemporaneous third-party failure report, not an OpenAI adjudication and not proof that the owner's older-root inputs were misrouted.

## Metadata semantics

Current public source documents `parent_thread_id` as a subagent field and `thread_source` as analytics classification. These fields do not prove which visible composer or human intent created a later root turn. Authoritative submission-surface records remain required.
