# Public-source verification — 2026-09-21

## Exact runtime

OpenAI's public `rust-v0.154.0-alpha.6.2` source was opened and checked. `manager.rs` explicitly states that provider identity still needed to be included in cache eligibility to prevent reuse of another provider's fresh `models_cache.json`. `cache.rs` shows the file-cache entry fields as fetch time, ETag, client version and models, without provider/auth identity.

- http<PRIVATE_PATH>
- http<PRIVATE_PATH>

## Later fix

OpenAI commit `f046cf3` confirms that switching provider/authentication could reuse a previous catalog including its default service tier and adds provider/auth identity isolation.

- http<PRIVATE_PATH>

## Routing report

Issue #45709 remains an unverified public report on the same bundled CLI version describing divergence between UI/persisted thread identity and turn-notification identity.

- http<PRIVATE_PATH>

## Current official pricing and tier semantics

Official OpenAI documentation states:

- credit purchase prices and discounts depend on plan or agreement;
- actual charges must be reconciled to invoices, billing period and contractual terms;
- Fast mode uses increased credit consumption;
- Codex GPT-5.6 and Astra Fast currently use a 2.5× credit multiplier; and
- `service_tier=priority` and `service_tier=fast` select the same Fast behavior on supported models.

Current sources:

- http<PRIVATE_PATH>
- http<PRIVATE_PATH>
- http<PRIVATE_PATH>
- http<PRIVATE_PATH>

Current rules are used only for present-day semantics and sensitivity analysis. They do not establish the affected historical contract, transaction currency, rate card or debit.
