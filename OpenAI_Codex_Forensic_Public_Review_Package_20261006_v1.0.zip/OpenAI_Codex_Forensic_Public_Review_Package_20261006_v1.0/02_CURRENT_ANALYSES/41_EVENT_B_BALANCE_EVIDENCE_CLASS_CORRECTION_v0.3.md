# Event B balance evidence-class and currency correction v0.3

The values `US$33.72`, `US$29.48` and `US$4.60` are preserved in the included frozen evidence as contemporaneous user-authored reports. The current derived submission evidence independently preserves the exact input `US$4.60  FFS WRAP IT UP!`. These are first-party currency representations, not provider ledger entries.

Relevant timestamps:

- 01:00:18.979 UTC — `US$33.72` reported remaining;
- 01:01:16.727 UTC — `US$29.48` warning; and
- 01:07:30.134 UTC — `US$4.60` reported remaining.

Conditional arithmetic:

- displayed decline: **29.12**;
- elapsed persisted-message interval: **431.155 seconds**; and
- first-party currency notation: `US$` / USD;
- first-party represented decline: **US$29.12**; and
- provider-authoritative accounting currency: **UNDERDETERMINED**.

Correct classification:

**CONTEMPORANEOUS FIRST-PARTY USD REPRESENTATION — PROVIDER-AUTHORITATIVE CURRENCY UNDERDETERMINED**

The first-party USD representation is evidence and must not be erased merely because the provider ledger is unavailable. It does not promote the endpoints into provider ledger rows, establish the provider's accounting currency, establish a historical rate, or prove a particular request-level debit.
