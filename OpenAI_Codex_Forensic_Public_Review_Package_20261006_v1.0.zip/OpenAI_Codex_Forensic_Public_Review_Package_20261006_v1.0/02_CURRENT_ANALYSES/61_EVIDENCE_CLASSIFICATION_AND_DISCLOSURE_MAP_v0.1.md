# Evidence classification and disclosure map v0.1

Disclosure status and truth status are separate. A source may be authentic but undistributed; an included file may be reproducible but still fail to prove a broader claim.

The controlling `CLAIM_SOURCE_COVERAGE.csv` assigns one or more of these classes to every current claim:

| Class | Meaning |
| --- | --- |
| `PACKAGE_REPRODUCIBLE` | A recipient can inspect or mechanically reproduce the scoped observation from distributed package material. |
| `ESTABLISHED_FROM_AUTHENTICATED_EXTERNAL_SOURCE_NOT_DISTRIBUTED` | The package records a prior authenticated examination, but the underlying raw source is withheld; the recipient cannot rerun authentication from this ZIP. |
| `ESTABLISHED_FROM_EXAMINED_EXTERNAL_SOURCE_NOT_DISTRIBUTED` | A prior examination supports the scoped claim, but the examined source is not distributed. |
| `EXTERNAL_SOURCE_INVENTORY_BOUND` | The relevant source corpus/inventory digest is external to the package. |
| `FIRST_PARTY_TESTIMONY` | The owner directly reports knowledge or observation; this is not independent telemetry. |
| `PUBLIC_SOURCE_EVIDENCE` | The claim depends on identified public source material with its own scope and temporal limits. |
| `CONDITIONAL_INFERENCE` | The result follows only under stated assumptions or counterfactual parameters. |
| `PROVIDER_CONTROLLED_CLOSURE` | Provider-side records are needed to determine or close the claim. |
| `NORMATIVE_ACTION` | A claimant-selected request or decision, not an evidence/inference output. |
| `CORRECTION_RECORD` | A current statement that an earlier claim or metric is superseded; it preserves history without keeping the old claim active. |

Multiple classes may apply. `ESTABLISHED` never means “all source bytes are distributed,” and `PACKAGE_REPRODUCIBLE` never means “the broader allegation is proven.”
