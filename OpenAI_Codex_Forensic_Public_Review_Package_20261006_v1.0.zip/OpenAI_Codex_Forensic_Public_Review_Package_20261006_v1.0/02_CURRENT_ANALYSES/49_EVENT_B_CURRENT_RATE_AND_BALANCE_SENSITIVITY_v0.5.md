# Event B current-rate compatibility sensitivity v0.5

**Status:** diagnostic compatibility test; not a historical charge or currency reconstruction

Current official OpenAI documentation lists the present credit rates and Fast multipliers used in this sensitivity. It also says credit purchase prices depend on plan/agreement and actual charges must be confirmed against invoices and contractual terms.

Current sources:

- http<PRIVATE_PATH>
- http<PRIVATE_PATH>
- http<PRIVATE_PATH>

Known-model response-accounting increments from the first-party `US$33.72` report to the `US$4.60` submission correspond under current rates to 651.3204 credits.

A separate historical interface observation reported 5,000 credits for US$200, or 25 credits per US dollar. The Event B endpoints were contemporaneously represented by the owner as `US$33.72` and `US$4.60`, so the first-party represented decline is US$29.12. Under the separate, cross-time assumption that the historical 25-credits-per-US-dollar interface observation applies to this balance representation, 651.3204 credits become nominally US$26.0528, US$29.12 becomes nominally 728 credits, and the comparison yields 89.47% compatibility.

This removes an unnecessary free-floating USD assumption while preserving the decisive boundary: first-party USD representation is supported; provider-authoritative accounting currency remains underdetermined.

The Event A notices instead imply approximately 31.0626 credits per displayed dollar symbol in aggregate. The package does not treat those conversion observations as interchangeable.

Nine guardian submissions occurred in the interval. Their tokens and debit are unknown; the defective v1.6.4 guardian range is not used.

The result establishes magnitude compatibility under stated assumptions. It does not establish provider-authoritative currency, historical pricing, authorization, account attribution, probability or final refund.
