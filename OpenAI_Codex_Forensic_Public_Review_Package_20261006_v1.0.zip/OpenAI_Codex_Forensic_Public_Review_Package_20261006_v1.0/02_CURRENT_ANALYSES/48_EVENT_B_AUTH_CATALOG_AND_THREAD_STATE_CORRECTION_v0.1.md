# Event B auth, catalog and thread-state correction v0.1

**Date:** 2026-09-20  
**Status:** CURRENT SUPPORTING

## Auth/catalog boundary

The local model-manager log records this sequence:

| UTC | Local observation |
| --- | --- |
| 00:54:32 fetched | seven-model catalog, ETag `W/"4e4e297d42f112aa77e9e4388ca7c744"` |
| 00:56:11 | first acute Astra submission |
| 00:56:12 | `/backend-api/codex/models` refresh failed `401 Unauthorized`, `token_revoked` |
| 00:56:16 fetched | eight-model catalog, ETag `W/"01ce13a37c722793c713e18e91130d5c"` |
| 00:56:20 onward | eight-model catalog reused across the acute roots and guardian threads |
| 01:00:42 onward | `token_revoked` model-refresh failures recur approximately every 270 seconds |

The snapshot's `models_cache.json` contains `fetched_at`, `etag`, `client_version` and `models`, without visible provider/auth identity fields. This is compatible with a legacy-shaped disk entry; it does not prove the in-memory client lacked identity checks.

OpenAI's public commit `f046cf35df0978a628d78a7d4bb6b1d3362a27dd` documents a defect class in which switching provider/auth identity could reuse a previous model catalog, including its default service tier. The local timeline is mechanism-compatible but not case-causal proof.

## Client Priority state

Each of the five new acute user-root turns captured in the union window explicitly carries `service_tier=priority` in the client request. Steering messages contain no new tier override and inherit the active turn.

This narrows the tier question:

> What wrote or resolved the persisted client Priority state, and which account/workspace/catalog identity authorized it?

The absence of an exact `/fast` command does not mean the request lacked an explicit effective tier.

## Thread-state projection inconsistency

The Sep. 16 state database projects `has_user_event=0` for all three acute user roots even though their rollouts and session-handler logs contain explicit user inputs.

The older root's projected creation time is Sep. 15, while preserved session metadata places that same logical root in the corpus by Aug. 26. This may reflect pagination/import projection rather than canonical creation history.

These inconsistencies support a state/projection desynchronization mechanism class for sidebar recency, task selection or routing. They do not establish that the user saw one task while another root received the input.

## Remote, queue and automation paths

- Two enabled remote-control enrollment rows bind the same desktop/server name to two distinct hashed account and environment IDs; their recorded update times are after the acute window.
- Queue revision state includes all three acute roots. The only still-queued item in the snapshot belongs to the ROOT_C and predates Event B.
- Two automations target the older root, but both were paused before Event B and neither prompt matches the acute short inputs.

These are real alternative submission paths. None is selected as the Event B cause from local evidence.

## Evidence

- `03_CORRECTED_DERIVED_EVIDENCE/EVENT_B_AUTH_CATALOG_TIMELINE.json`
- `03_CORRECTED_DERIVED_EVIDENCE/EVENT_B_EXECUTION_PATHS.json`
- `03_CORRECTED_DERIVED_EVIDENCE/SOURCE_BINDING.json`
