# Post-event Priority configuration boundary v0.1

## Established local observation

`03_MINIMIZED_SAFE_EVIDENCE/SELECTED_CONFIG_KEYS.CSV` records a live local configuration snapshot with:

- file modification time: `2026-09-16T14:31:42.964316+00:00`;
- key: `service_tier`; and
- value: `"priority"`.

The modification time is approximately 13 hours 24 minutes after the final `US$4.60` Event B endpoint at 01:07 UTC.

## Consequence

This is material adverse evidence because it supplies a concrete local configuration pathway capable of causing client requests to carry Priority after the recorded modification time. It must be considered alongside UI, managed-default, provider/auth/catalog/cache and other tier-resolution pathways.

## Limits

The snapshot does not establish:

- when `service_tier="priority"` was first written;
- whether that value existed or was effective during Event B;
- which user or process wrote it;
- whether it resulted from a UI choice, inheritance, cache/catalog state, automation or another mechanism; or
- knowing owner authorization.

**Classification:** ESTABLISHED POST-EVENT LOCAL CONFIGURATION SNAPSHOT; EVENT-B CAUSAL ROLE UNRESOLVED.

The discriminating evidence is historical configuration and tier-resolution provenance covering Event B and the later snapshot.
