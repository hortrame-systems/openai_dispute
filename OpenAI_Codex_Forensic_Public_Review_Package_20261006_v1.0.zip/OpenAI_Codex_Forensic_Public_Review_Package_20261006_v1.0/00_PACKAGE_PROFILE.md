# Public forensic review profile

Derived from complete v1.7.0. Minimized structured evidence, correction history, provenance, bounded support excerpts and reproduction tools. Confidential raw, private mapping and Tier Guard excluded.
