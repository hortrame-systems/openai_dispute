> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Unified credit-depletion case thesis v0.6

**Status:** controlling analysis

## Core question

Were the observed requests attached to the intended work, charged to the correct account and funding pool, knowingly authorized for Fast/Priority, and priced and settled under the applicable historical rules?

## Event A

Two authenticated reload notices total US$327.50. Task starts alone do not explain or reject the depletion. Historical tokens, reload settings, account allocation and request/debit rows remain absent.

The repeated approximately 5,000-credit magnitude may follow from a reload target or pack size. It does not validate the consumption that triggered or exhausted either purchase.

## Event B

Six paired persisted segments contain 29,225,371 final cumulative input tokens and 26,386,511 post-initial input tokens. Twenty-one transient guardian submissions also occurred, only one of which appears as a paired persisted segment.

The older-root turns had explicit inputs. The local record establishes root attachment, not the visible task the owner saw or intended. Neither deliberate task switching nor unintended targeting is ranked.

Five acute new turns explicitly carried `service_tier=priority`. At onset, a catalog refresh failed `token_revoked`, followed by a seven-to-eight-model ETag transition reused across the acute roots. This establishes Priority request state and auth/catalog churn, not wrong-account billing.

## Economic interpretation

The current-rate scenario explains 89.47% of the nominal reported Event B decline before any guardian debit. That is a compatibility result assembled from current rates, the current multiplier, a historical nominal purchase conversion and first-party balance reports. It does not establish the historical ledger or rank ordinary charging above unauthorized-tier or wrong-attribution explanations.

## Settlement posture

The opening claim is US$356.62:

- US$327.50 for the two Event A reloads; and
- US$29.12 for the Event B reported decline.

The amount is presumed due unless OpenAI disproves a portion request by request. The presumption governs reconciliation and settlement; it does not itself establish final historical damages.

OpenAI earns a reduction only for a specific historical debit that it proves was correctly attributed, knowingly authorized, correctly priced and correctly settled. Any portion not disproved remains due.

## Falsifiable disposition

- A fully reconciled request reduces the claim by its actual historical debit.
- Valid Standard usage without proved Fast authorization reduces only the proven Standard portion; the historical Fast premium remains claimed.
- Correct arithmetic with wrong account, funding pool or intended target leaves the full request debit claimed.
- Aggregate assurances and client-side tier fields do not close provenance.

## Public-facing statement

> HORTRAME requests US$356.62, presumed due unless OpenAI disproves a portion request by request. Local records establish substantial Fast/Priority workload, explicit client inputs, guardian submissions and an auth/catalog transition, but do not establish the historical writer of the tier state, the intended visible task or the charged funding identity. Current-rate arithmetic shows magnitude compatibility only. OpenAI must produce request-level identity, authorization, usage, pricing and settlement rows for every proposed reduction.
