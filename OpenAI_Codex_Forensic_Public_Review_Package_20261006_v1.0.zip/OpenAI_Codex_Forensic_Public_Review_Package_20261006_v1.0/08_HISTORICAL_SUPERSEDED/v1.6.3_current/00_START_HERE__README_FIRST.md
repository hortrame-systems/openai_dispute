> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# OpenAI dispute evidence package v1.6.3 — everything substantive edition

**Release date:** 2026-09-20  
**Package profile:** see `../00_PACKAGE_PROFILE.md`  
**Status:** final local package; not submitted  
**Opening claim:** **US$356.62, presumed due unless OpenAI disproves a portion request by request**

## Read first

1. `EXECUTIVE_CASE_SUMMARY.md`
2. `REQUEST_TO_OPENAI.md`
3. `CLAIM_STATUS_AND_LIMITS.md`
4. `../02_CURRENT_ANALYSES/50_UNIFIED_CREDIT_DEPLETION_CASE_THESIS_v0.6.md`
5. `../02_CURRENT_ANALYSES/51_CURRENT_CLAIM_LEDGER_v1.6.2.csv`
6. `../02_CURRENT_ANALYSES/55_REBUTTABLE_LINE_ITEM_DEMAND_SCHEDULE_v1.6.2.md`
7. `../02_CURRENT_ANALYSES/56_REBUTTABLE_ALLOCATION_TEMPLATE_v1.6.2.csv`

## Demand posture

The package requests reimbursement or account credit of:

- US$164.99 for Event A invoice INVOICE_0003;
- US$162.51 for Event A invoice INVOICE_0004; and
- US$29.12 for the Event B reported balance decline.

The total **US$356.62 is presumed due**. OpenAI may reduce it only by identifying the affected request or transaction component and proving that it was correctly attributed, knowingly authorized, correctly priced and correctly settled. A global denial or statement that the client transmitted `service_tier=priority` earns no reduction by itself.

## Evidence boundary

The settlement presumption is a procedural position, not a claim that final historical damages are already independently proven. Evidence status remains separate:

- the two Event A reload transactions are authenticated provider-message facts;
- the Event B endpoints are contemporaneous first-party reports, not provider ledger rows;
- current-rate calculations are compatibility tests, not historical debit reconstructions; and
- account, funding-pool, intended-task and tier-authorization records remain provider-controlled.

## Corrected economic interpretation

The current-rate scenario maps known-model usage inside the Event B submission interval to 651.3204 credits, or 89.47% of the nominal 728-credit reported decline. This shows quantitative compatibility with ordinary Fast charging under current assumptions. It does not rank that explanation above unauthorized tier, wrong attribution or historical-rate discrepancies.

## Data minimization

v1.6.2 removes the broad Stage-2 telemetry tables and historical integrated HTML from the external package. It distributes only event-specific rows, corrected derived outputs and aggregate analyses needed for review. The broader evidence remains preserved internally in v1.6.1 and the source archives.

## Integrity

`MANIFEST.csv` and `SHA256SUMS.txt` cover every release file except the manifest files themselves. Run `05_VERIFICATION/verify_release_v1.6.2.py` from the package root. Tier Guard remains excluded and preserved separately.
