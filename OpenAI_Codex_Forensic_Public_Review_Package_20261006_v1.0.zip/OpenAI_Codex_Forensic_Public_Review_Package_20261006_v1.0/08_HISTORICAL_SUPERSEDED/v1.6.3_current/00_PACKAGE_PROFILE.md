> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Package profile — everything substantive

## Purpose

This package preserves the complete current v1.6.2 core plus all substantively relevant safe evidence and analytical history available for the dispute.

## Additional contents

- Broad Stage-2 safe telemetry tables.
- Complaint summary and source-rollout inventory.
- Historical integrated HTML report.
- Exact v1.6.1 query scripts as run and portable query copies.
- Superseded v1.6.1 controlling analyses.
- Later anomaly, financial, hostile-review and demand-strategy analyses.
- A full substantive-evidence inventory.

## Trust boundary

This package exposes extensive internal task IDs, timestamps, models, reasoning levels, tool-use patterns, hashed identity hints and source-path metadata. Give it only to a trusted reviewer with a legitimate need for broad context.

The confidential 7.3 GB raw snapshot and Tier Guard remain outside this package. They are preserved and source-bound but require separate authorization because they contain unrelated confidential and credentials-adjacent material.

## Controlling versus historical

Only the current files under `00_START_HERE`, `02_CURRENT_ANALYSES` and `04_REVIEW` control. Material under `08_HISTORICAL_SUPERSEDED` is preserved for correction history and must not override current classifications.

Start with `00_START_HERE/README_FIRST.md`, then read `07_SUBSTANTIVE_EVIDENCE/README.md` and `08_HISTORICAL_SUPERSEDED/README.md`.
