> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Request to OpenAI — v1.6.2

Please preserve the affected request, identity, tier, billing, reload and routing records.

## Requested resolution

We request reimbursement or account credit of **US$356.62**. The full amount is presumed due unless OpenAI disproves a portion request by request. Any reduction must identify the specific historical debit and prove that it was correctly attributed, knowingly authorized, correctly priced and correctly settled.

## 1. Minimum dispositive ledger

For each request or transaction component used to reduce the claim, provide:

- request, response, turn, client and root/thread IDs;
- UTC submission, completion and settlement timestamps;
- stable pseudonymous account, workspace, auth-principal and funding-pool IDs;
- model, reasoning, input, cached-input, output and reasoning tokens;
- requested and resolved service tier;
- the writer, prior value and user/admin/config action authorizing the tier;
- historical rate-card version, multiplier and included-plan offset; and
- debit, currency and balance before/after.

## 2. Routing closure

For the older-root `Go` and status-question inputs, map each client ID to the desktop composer, Remote, queue, automation, recovery or internal event and the visible selected task. Root attachment alone does not establish what the owner saw or intended.

## 3. Mechanism investigation

Provide the account/auth binding for the seven-model and eight-model catalog fetches, the ETags, cache-identity decision, token-revocation event, canonical thread projection and all 21 guardian/retry rows.

## Reduction rule

Aggregate assurances, screenshots or a statement that the client transmitted `service_tier=priority` do not establish informed tier authorization, intended task targeting, correct funding attribution or correct debit. Any portion not disproved with the requested row-level evidence remains due.
