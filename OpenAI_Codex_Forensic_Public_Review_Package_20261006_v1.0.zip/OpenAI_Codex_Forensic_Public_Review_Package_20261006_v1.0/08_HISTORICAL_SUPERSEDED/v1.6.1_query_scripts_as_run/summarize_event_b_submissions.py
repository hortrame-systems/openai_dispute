#!/usr/bin/env python3
from __future__ import annotations

import datetime as dt
import hashlib
import json
import pathlib
import re
import sqlite3


LOGS = pathlib.Path(r"<PRIVATE_PATH>")
START = int(dt.datetime(2026, 9, 16, 0, 50, tzinfo=dt.timezone.utc).timestamp())
END = int(dt.datetime(2026, 9, 16, 1, 10, tzinfo=dt.timezone.utc).timestamp())
INTERESTING = {
    "ID_0176": "older_root",
    "ID_1052": "root_b",
    "ID_1403": "root_c",
    "ID_1488": "auto_review_child",
}


def digest(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


connection = sqlite3.connect(f"file:{LOGS.as_posix()}?mode=ro&immutable=1", uri=True)
connection.row_factory = sqlite3.Row
connection.execute("PRAGMA query_only=ON")
rows = connection.execute(
    "SELECT ts, ts_nanos, level, target, module_path, file, line, thread_id, process_uuid, feedback_log_body "
    "FROM logs WHERE ts BETWEEN ? AND ? AND module_path='codex_core::session::handlers' "
    "AND feedback_log_body LIKE '%Submission sub=Submission%' ORDER BY ts, ts_nanos",
    (START, END),
).fetchall()
summaries = []
for row in rows:
    body = row["feedback_log_body"] or ""
    submission = re.search(r'Submission \{ id: "([^"]+)"', body)
    operation = re.search(r'op: ([A-Za-z0-9_]+)', body)
    client = re.search(r'client_id: Some\("([^"]+)"\)', body)
    mode = re.search(r'mode: ([A-Za-z0-9_]+)', body)
    cwd = re.search(r'legacy_fallback_cwd: AbsolutePathBuf\("([^"]+)"\)', body)
    text_match = re.search(r'Text \{ text: "((?:\\.|[^"\\])*)"', body)
    text = ""
    if text_match:
        try:
            text = json.loads('"' + text_match.group(1) + '"')
        except json.JSONDecodeError:
            text = text_match.group(1)
    lower = body.lower()
    summaries.append(
        {
            "timestamp_utc": dt.datetime.fromtimestamp(row["ts"], tz=dt.timezone.utc).isoformat(),
            "ts_nanos": row["ts_nanos"],
            "thread_id": row["thread_id"],
            "thread_label": INTERESTING.get(row["thread_id"], "other"),
            "submission_id": submission.group(1) if submission else None,
            "operation": operation.group(1) if operation else None,
            "submission_mode": mode.group(1) if mode else None,
            "client_id": client.group(1) if client else None,
            "cwd": cwd.group(1).replace("\\\\", "\\") if cwd else None,
            "priority_override_occurrences": body.count('service_tier: Some(Some("priority"))'),
            "service_tier_none_occurrences": body.count("service_tier: None"),
            "input_bytes": len(text.encode("utf-8")),
            "input_sha256": digest(text),
            "short_input": text.rstrip("\r\n") if len(text) <= 100 else None,
            "process_uuid": row["process_uuid"],
            "has_remote_marker": "remotecontrol" in lower or "remote_control" in lower or "remote control" in lower,
            "has_automation_marker": "automation" in lower or "heartbeat" in lower,
            "has_queue_marker": "queued" in lower or "queue" in lower,
            "has_retry_marker": "retry" in lower,
            "body_bytes": len(body.encode("utf-8")),
            "body_sha256": digest(body),
        }
    )
connection.close()
print(json.dumps(summaries, indent=2, sort_keys=True))
