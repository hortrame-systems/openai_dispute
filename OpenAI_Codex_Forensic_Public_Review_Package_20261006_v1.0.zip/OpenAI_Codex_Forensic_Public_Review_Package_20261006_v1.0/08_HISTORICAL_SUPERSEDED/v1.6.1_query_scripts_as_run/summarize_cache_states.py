#!/usr/bin/env python3
from __future__ import annotations

import datetime as dt
import json
import pathlib
import re
import sqlite3


LOGS = pathlib.Path(r"<PRIVATE_PATH>")
START = int(dt.datetime(2026, 9, 16, 0, 40, tzinfo=dt.timezone.utc).timestamp())
END = int(dt.datetime(2026, 9, 16, 1, 30, tzinfo=dt.timezone.utc).timestamp())


connection = sqlite3.connect(f"file:{LOGS.as_posix()}?mode=ro&immutable=1", uri=True)
connection.row_factory = sqlite3.Row
connection.execute("PRAGMA query_only=ON")
rows = connection.execute(
    "SELECT ts, ts_nanos, thread_id, target, level, feedback_log_body FROM logs "
    "WHERE ts BETWEEN ? AND ? AND (target LIKE 'codex_models_manager%' OR lower(feedback_log_body) LIKE '%token_revoked%') "
    "ORDER BY ts, ts_nanos",
    (START, END),
).fetchall()
connection.close()

states: dict[str, dict[str, object]] = {}
last_fetched_by_thread: dict[str, str] = {}
revocations = []
for row in rows:
    body = row["feedback_log_body"] or ""
    stamp = dt.datetime.fromtimestamp(row["ts"], tz=dt.timezone.utc).isoformat()
    fetched = re.search(r"fetched_at=([^\n]+? UTC)", body)
    if fetched:
        fetched_at = fetched.group(1)
        last_fetched_by_thread[row["thread_id"] or "<none>"] = fetched_at
        state = states.setdefault(fetched_at, {"first_observed_utc": stamp, "last_observed_utc": stamp, "threads": set(), "models_counts": set(), "etags": set()})
        state["last_observed_utc"] = stamp
        state["threads"].add(row["thread_id"] or "<none>")
    applied = re.search(r"cache entry applied models_count=(\d+) etag=Some\(\"((?:\\.|[^\"])*)\"\)", body)
    if applied:
        fetched_at = last_fetched_by_thread.get(row["thread_id"] or "<none>", "<unknown>")
        state = states.setdefault(fetched_at, {"first_observed_utc": stamp, "last_observed_utc": stamp, "threads": set(), "models_counts": set(), "etags": set()})
        state["last_observed_utc"] = stamp
        state["threads"].add(row["thread_id"] or "<none>")
        state["models_counts"].add(int(applied.group(1)))
        state["etags"].add(bytes(applied.group(2), "utf-8").decode("unicode_escape"))
    if "token_revoked" in body.lower():
        revocations.append({"timestamp_utc": stamp, "target": row["target"], "level": row["level"]})

serializable = []
for fetched_at, state in sorted(states.items()):
    serializable.append(
        {
            "fetched_at": fetched_at,
            "first_observed_utc": state["first_observed_utc"],
            "last_observed_utc": state["last_observed_utc"],
            "threads": sorted(state["threads"]),
            "models_counts": sorted(state["models_counts"]),
            "etags": sorted(state["etags"]),
        }
    )
print(json.dumps({"cache_states": serializable, "token_revocation_events": revocations}, indent=2, sort_keys=True))
