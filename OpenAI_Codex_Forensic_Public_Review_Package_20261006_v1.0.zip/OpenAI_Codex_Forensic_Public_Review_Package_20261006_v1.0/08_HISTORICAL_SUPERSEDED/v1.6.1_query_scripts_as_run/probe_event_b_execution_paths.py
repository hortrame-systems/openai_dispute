#!/usr/bin/env python3
from __future__ import annotations

import datetime as dt
import ast
import hashlib
import json
import pathlib
import re
import sqlite3
import urllib.parse


RAW = pathlib.Path(r"<PRIVATE_PATH>")
EVENT_START = dt.datetime(2026, 9, 16, 0, 45, tzinfo=dt.timezone.utc)
EVENT_END = dt.datetime(2026, 9, 16, 1, 15, tzinfo=dt.timezone.utc)
ROOTS = {
    "older_root": "ID_0176",
    "root_b": "ID_1052",
    "root_c": "ID_1403",
    "auto_review_child": "ID_1488",
}
KEYWORDS = (
    "automation",
    "heartbeat",
    "queue",
    "queued",
    "remote",
    "dispatch",
    "resume",
    "restore",
    "recover",
    "retry",
    "turn/start",
    "turn/started",
    "turn/completed",
    "websocket",
)


def ro(path: pathlib.Path) -> sqlite3.Connection:
    connection = sqlite3.connect(f"file:{path.resolve().as_posix()}?mode=ro&immutable=1", uri=True)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only=ON")
    return connection


def digest(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def iso(value: int | None) -> str | None:
    if value is None:
        return None
    seconds = value / 1000 if value > 10_000_000_000 else value
    return dt.datetime.fromtimestamp(seconds, tz=dt.timezone.utc).isoformat()


def strings(value: object) -> list[str]:
    found: list[str] = []
    if isinstance(value, str):
        found.append(value)
    elif isinstance(value, dict):
        for nested in value.values():
            found.extend(strings(nested))
    elif isinstance(value, list):
        for nested in value:
            found.extend(strings(nested))
    return found


def shape(value: object) -> object:
    if isinstance(value, dict):
        return {key: shape(nested) for key, nested in value.items()}
    if isinstance(value, list):
        return [shape(nested) for nested in value[:3]] + (["<more>"] if len(value) > 3 else [])
    if isinstance(value, str):
        return {"string_bytes": len(value.encode("utf-8")), "sha256": digest(value)}
    return type(value).__name__


def simple_toml(path: pathlib.Path) -> dict[str, object]:
    parsed: dict[str, object] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        match = re.match(r"^([A-Za-z0-9_]+)\s*=\s*(.+)$", line)
        if not match:
            continue
        key, raw = match.groups()
        try:
            parsed[key] = ast.literal_eval(raw)
        except (SyntaxError, ValueError):
            parsed[key] = raw
    return parsed


automations = []
for path in sorted((RAW / "automations").glob("*/automation.toml")):
    data = simple_toml(path)
    prompt = data.get("prompt", "")
    automations.append(
        {
            "slug": path.parent.name,
            "name": data.get("name"),
            "status": data.get("status"),
            "rrule": data.get("rrule"),
            "target_thread_id": data.get("target_thread_id"),
            "created_at": iso(data.get("created_at")),
            "updated_at": iso(data.get("updated_at")),
            "prompt_bytes": len(prompt.encode("utf-8")),
            "prompt_sha256": digest(prompt),
            "_prompt": prompt,
        }
    )

result: dict[str, object] = {
    "event_window_utc": [EVENT_START.isoformat(), EVENT_END.isoformat()],
    "automations_targeting_event_roots": [
        {key: value for key, value in automation.items() if not key.startswith("_")}
        for automation in automations
        if automation["target_thread_id"] in ROOTS.values()
    ],
}

state = ro(RAW / "state_5.sqlite")
thread_rows = []
for row in state.execute(
    "SELECT id, created_at_ms, updated_at_ms, source, cli_version, has_user_event, archived, "
    "agent_nickname, model, reasoning_effort, thread_source, originator, tokens_used, first_user_message "
    "FROM threads WHERE id IN ({}) ORDER BY created_at_ms".format(",".join("?" for _ in ROOTS)),
    tuple(ROOTS.values()),
):
    item = dict(row)
    first = item.pop("first_user_message") or ""
    item["created_at_utc"] = iso(item.pop("created_at_ms"))
    item["updated_at_utc"] = iso(item.pop("updated_at_ms"))
    item["first_user_message_bytes"] = len(first.encode("utf-8"))
    item["first_user_message_sha256"] = digest(first)
    thread_rows.append(item)
result["thread_metadata"] = thread_rows

edges = [dict(row) for row in state.execute(
    "SELECT parent_thread_id, child_thread_id, status FROM thread_spawn_edges "
    "WHERE child_thread_id IN ({0}) ORDER BY parent_thread_id, child_thread_id".format(
        ",".join("?" for _ in ROOTS)
    ),
    tuple(ROOTS.values()),
)]
result["spawn_edges"] = edges

enrollments = []
for row in state.execute(
    "SELECT websocket_url, account_id, app_server_client_name, server_id, environment_id, server_name, updated_at, remote_control_enabled "
    "FROM remote_control_enrollments ORDER BY updated_at"
):
    item = dict(row)
    parsed = urllib.parse.urlparse(item.pop("websocket_url"))
    item["websocket_endpoint"] = f"{parsed.scheme}://{parsed.hostname or '<none>'}"
    item["account_id_sha256_prefix"] = digest(item.pop("account_id"))[:16]
    item["server_id_sha256_prefix"] = digest(item.pop("server_id"))[:16]
    item["environment_id_sha256_prefix"] = digest(item.pop("environment_id"))[:16]
    item["updated_at_utc"] = iso(item.pop("updated_at"))
    enrollments.append(item)
result["remote_control_enrollments_redacted"] = enrollments
state.close()

queue = ro(RAW / "queue_1.sqlite")
result["queued_thread_revisions"] = [dict(row) for row in queue.execute(
    "SELECT revision, thread_id FROM queued_thread_revisions ORDER BY revision"
)]
queued_items = []
for row in queue.execute("SELECT id, thread_id, payload_json, queue_order, created_at_ms, updated_at_ms FROM queued_items ORDER BY queue_order"):
    item = dict(row)
    payload_text = item.pop("payload_json")
    try:
        payload = json.loads(payload_text)
    except json.JSONDecodeError:
        payload = payload_text
    candidates = strings(payload)
    matches = []
    for automation in automations:
        prompt = automation["_prompt"]
        if prompt and any(candidate == prompt or prompt in candidate or candidate in prompt for candidate in candidates if len(candidate) > 40):
            matches.append(automation["slug"])
    item["created_at_utc"] = iso(item.pop("created_at_ms"))
    item["updated_at_utc"] = iso(item.pop("updated_at_ms"))
    item["payload_bytes"] = len(payload_text.encode("utf-8"))
    item["payload_sha256"] = digest(payload_text)
    item["payload_shape"] = shape(payload)
    item["automation_prompt_matches"] = matches
    queued_items.append(item)
result["queued_items"] = queued_items
queue.close()

history = ro(RAW / "thread_history_1.sqlite")
start_s = int(EVENT_START.timestamp())
end_s = int(EVENT_END.timestamp())
turns = []
for row in history.execute(
    "SELECT thread_id, turn_id, rollout_ordinal, status, error_json, started_at, completed_at, duration_ms, "
    "first_user_item_id, final_agent_item_id FROM thread_turns "
    "WHERE thread_id IN ({}) AND started_at BETWEEN ? AND ? ORDER BY started_at".format(",".join("?" for _ in ROOTS)),
    tuple(ROOTS.values()) + (start_s, end_s),
):
    item = dict(row)
    item["started_at_utc"] = iso(item.pop("started_at"))
    item["completed_at_utc"] = iso(item.pop("completed_at"))
    error = item.pop("error_json")
    item["has_error"] = bool(error)
    user_item = None
    if item["first_user_item_id"]:
        user_item = history.execute(
            "SELECT item_type, item_json, created_at_ms, rollout_ordinal FROM thread_items "
            "WHERE thread_id=? AND turn_id=? AND item_id=?",
            (item["thread_id"], item["turn_id"], item["first_user_item_id"]),
        ).fetchone()
    if user_item:
        raw = user_item["item_json"]
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            parsed = raw
        candidates = strings(parsed)
        matches = []
        for automation in automations:
            prompt = automation["_prompt"]
            if prompt and any(candidate == prompt or prompt in candidate for candidate in candidates):
                matches.append(automation["slug"])
        item["first_user_item"] = {
            "item_type": user_item["item_type"],
            "created_at_utc": iso(user_item["created_at_ms"]),
            "rollout_ordinal": user_item["rollout_ordinal"],
            "json_bytes": len(raw.encode("utf-8")),
            "json_sha256": digest(raw),
            "shape": shape(parsed),
            "automation_prompt_matches": matches,
            "long_string_fingerprints": sorted(
                ({"bytes": len(value.encode("utf-8")), "sha256": digest(value)} for value in candidates if len(value) > 40),
                key=lambda entry: (entry["bytes"], entry["sha256"]),
                reverse=True,
            )[:8],
        }
    turns.append(item)
result["event_turns"] = turns
history.close()

logs = ro(RAW / "logs_2.sqlite")
log_rows = []
for row in logs.execute(
    "SELECT ts, ts_nanos, level, target, feedback_log_body, module_path, file, line, thread_id, process_uuid "
    "FROM logs WHERE ts BETWEEN ? AND ? AND (thread_id IN ({}) OR lower(feedback_log_body) LIKE '%automation%' "
    "OR lower(feedback_log_body) LIKE '%queue%' OR lower(feedback_log_body) LIKE '%remote%' "
    "OR lower(feedback_log_body) LIKE '%turn/start%' OR lower(feedback_log_body) LIKE '%resume%' "
    "OR lower(feedback_log_body) LIKE '%retry%') ORDER BY ts, ts_nanos".format(",".join("?" for _ in ROOTS)),
    (start_s, end_s) + tuple(ROOTS.values()),
):
    item = dict(row)
    body = item.pop("feedback_log_body") or ""
    item["timestamp_utc"] = iso(item.pop("ts"))
    matched = sorted({keyword for keyword in KEYWORDS if keyword in body.lower() or keyword in (item.get("target") or "").lower()})
    item["matched_keywords"] = matched
    item["body_bytes"] = len(body.encode("utf-8"))
    item["body_sha256"] = digest(body)
    log_rows.append(item)
result["event_log_structural_hit_count"] = len(log_rows)
by_thread: dict[str, int] = {}
by_target: dict[str, int] = {}
by_keyword: dict[str, int] = {}
by_level: dict[str, int] = {}
for row in log_rows:
    thread = row.get("thread_id") or "<none>"
    target = row.get("target") or "<none>"
    level = row.get("level") or "<none>"
    by_thread[thread] = by_thread.get(thread, 0) + 1
    by_target[target] = by_target.get(target, 0) + 1
    by_level[level] = by_level.get(level, 0) + 1
    for keyword in row["matched_keywords"]:
        by_keyword[keyword] = by_keyword.get(keyword, 0) + 1
result["event_log_summary"] = {
    "by_thread": dict(sorted(by_thread.items(), key=lambda item: (-item[1], item[0]))),
    "by_target_top20": dict(sorted(by_target.items(), key=lambda item: (-item[1], item[0]))[:20]),
    "by_keyword": dict(sorted(by_keyword.items(), key=lambda item: (-item[1], item[0]))),
    "by_level": dict(sorted(by_level.items(), key=lambda item: (-item[1], item[0]))),
}
logs.close()

for automation in automations:
    automation.pop("_prompt", None)

print(json.dumps(result, indent=2, sort_keys=True))
