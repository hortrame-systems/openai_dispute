> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Claimant-selected opening settlement request v1.6.7

**Epistemic type:** NORM / ACTION  
**Not:** evidence, forensic inference, damages calculation or adversarial-review output

HORTRAME chooses to open settlement discussions at **US$356.62**, comprising:

- US$164.99 associated with Event A invoice INVOICE_0003;
- US$162.51 associated with Event A invoice INVOICE_0004; and
- US$29.12 associated with the first-party-reported Event B balance decline.

This amount covers the full disputed components. The forensic record does not independently establish that any or all of the amount was improperly charged, and it does not establish that zero is the correct resolution. The request is a claimant-selected negotiation position.

The adversarial review neither derives nor validates US$356.62. Provider-favorable compatibility evidence, unresolved provider currency, authorization, attribution, historical pricing and settlement remain relevant to reconciliation and negotiation.

Any decision to maintain, reduce, settle or withdraw this request remains a claimant-authority decision informed by—rather than produced by—the evidentiary review.
