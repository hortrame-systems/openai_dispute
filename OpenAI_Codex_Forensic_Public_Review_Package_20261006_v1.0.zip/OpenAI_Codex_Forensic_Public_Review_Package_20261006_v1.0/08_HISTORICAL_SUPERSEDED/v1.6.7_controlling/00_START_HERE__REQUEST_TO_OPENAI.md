> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Request to OpenAI — v1.6.7

## Requested settlement

We request full reimbursement or account credit for:

- Event A invoice INVOICE_0003: `US$164.99`;
- Event A invoice INVOICE_0004: `US$162.51`; and
- Event B reported balance decline: `US$29.12`.

The resulting claimant-selected opening settlement request is **US$356.62**. It is separately classified under `03_CLAIMANT_POSITION` as a NORM/ACTION object, not an evidential estimate or adversarial-review output. Please confirm the provider-authoritative currency and ledger treatment for every component.

This negotiation request does not purport to impose an independent legal or contractual burden rule.

## Balanced evidentiary context

The package expressly records two material provider-favorable alternatives:

- under current rates and a separate historical 25-credits-per-US-dollar observation, known-model activity is 89.47% compatible with the reported Event B magnitude; and
- a post-event local configuration snapshot contains `service_tier="priority"`, although its first-write time, writer and Event-B effectiveness are unresolved.

Neither alternative proves historical billing correctness or knowing authorization. They are included because they materially affect causal discrimination.

## Minimum dispositive ledger

For each proposed reduction, identify:

1. request, response, turn, client and root/thread IDs;
2. UTC submission, completion, retry and settlement timestamps;
3. account, workspace, auth-principal and funding-pool IDs;
4. submitting surface and visible selected task;
5. requested/resolved tier and the writer, prior value and authorization event;
6. model, reasoning and exact token fields;
7. historical rate card, purchase price, discount, multiplier and currency; and
8. debit, balance before/after, unused-credit state and later adjustment/refund.

Stable opaque or pseudonymized identifiers are acceptable where they preserve equivalent row-level linkage. An attributable provider attestation may replace a sensitive field if it states the field tested, method, result and responsible team. Aggregate assurance or an unlinked summary is not equivalent to reconciliation.

## Current authorization testimony

The owner states they never knowingly enabled or authorized Fast/Priority by command, UI, saved setting, workspace/admin setting, automation or any other method during the affected period. A client request containing `service_tier=priority` establishes transmitted state, not informed authorization.

## Exact-runtime mechanism question

The public source for `rust-v0.154.0-alpha.6.2` explicitly notes that provider identity still needed to be added to model-cache eligibility to prevent another provider's fresh cache from being reused. Please reconcile the Event B token revocation and catalog/ETag transition against account/auth identity and cache eligibility.

Please also reconcile the historical configuration/tier-resolution chain against the post-event `service_tier="priority"` snapshot so its writer, first-write time and effective interval can be distinguished from cache/catalog and other pathways.

## Response standard

A global statement that usage was valid does not resolve the identified components. Please cite the specific historical rows supporting each proposed reduction so the parties can reconcile the remaining dispute precisely.
