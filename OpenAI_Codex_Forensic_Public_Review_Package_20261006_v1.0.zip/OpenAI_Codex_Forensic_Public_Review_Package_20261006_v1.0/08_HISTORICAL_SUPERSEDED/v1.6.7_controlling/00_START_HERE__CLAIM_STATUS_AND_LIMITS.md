> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Claim status and limits — v1.6.7

The controlling classification is `../02_CURRENT_ANALYSES/51_CURRENT_CLAIM_LEDGER_v1.6.7.csv`.

## Established

- Two provider-reported Event A reload transactions: `$164.99` and `$162.51`.
- Their added-credit quantities: 5,125 and 5,048 credits.
- Priority chronology and five acute transmitted Priority overrides.
- Six paired persisted-segment arithmetic.
- Twenty-one guardian submissions: one represented in the six persisted segments and twenty additional.
- Explicit inputs attached to the older root.
- Auth/catalog and thread-projection observations.
- Exact-runtime public cache-isolation weakness.
- A post-event live configuration snapshot modified at `2026-09-16T14:31:42.964316Z` contains `service_tier="priority"`; its earlier existence, writer and Event-B effectiveness are not established.

## First-party testimony

The owner states they absolutely never knowingly authorized Fast/Priority through a command, UI toggle, saved setting, workspace/admin setting, automation or other method during Aug. 30–Sep. 15. This is scoped testimony, not telemetry.

The owner also states that the relevant bank-account transactions are in USD. Event B messages independently preserve first-party `US$` endpoint representations. Neither establishes provider-authoritative accounting currency.

## Conditional calculations

- `US$29.12` Event B decline from first-party USD balance reports.
- 651.3204-credit current-rate compatibility scenario.
- 89.47% magnitude compatibility under current rates and a separate historical 25-credits-per-US-dollar observation.

The v1.6.4 estimate of 0.235–0.724 million transient guardian input tokens is suspended because its calibration differenced turn-level counters across separate turns. No replacement guardian-token range is asserted in v1.6.7.

## Separate claimant action

HORTRAME selects US$356.62 as its opening negotiation request. This is a NORM/ACTION object under `../03_CLAIMANT_POSITION`, not an evidential estimate, adversarial-review output, independently binding rule or proof of final damages.

## Not established

- Provider-authoritative accounting currency for Event A or Event B.
- One common provider-ledger currency across all components.
- Final historical refund amount.
- Historical credit purchase price, discount, contract or conversion.
- The tier-setting writer or authorization event.
- Intended visible task for older-root inputs.
- Request-level funding identity, debit and settlement.
- Turn/request-aware guardian token magnitude, cache treatment and debit.
- A fixed approximately 5,000-credit automatic reload target.
- Whether the post-event `service_tier="priority"` configuration existed or was effective during Event B, who or what wrote it, and whether it reflected knowing owner authorization.
- The legal identity relationships and negotiation/reimbursement authority among HORTRAME, the account holder and the payer.
