> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Executive case summary — v1.6.7

## Forensic finding

The package supports a targeted provider-side reconciliation of Priority-tier authorization, routing, account/funding attribution, historical pricing and debit settlement. It does **not** establish exact improper loss, final damages, wrong-account billing, knowing Fast/Priority authorization, or incident causation by the public cache defect.

## Event B: established local core

- six paired persisted segments with 29,225,371 final cumulative input tokens;
- 21 guardian submissions: one represented in the six segments and 20 additional;
- explicit client inputs attached to the older root, with visible/intended surface unresolved;
- five acute new-turn requests carrying `service_tier=priority`;
- a `token_revoked` failure followed by a seven-to-eight-model catalog and ETag transition;
- inconsistent thread projections; and
- first-party testimony that Fast/Priority was never knowingly authorized.

The exact `rust-v0.154.0-alpha.6.2` public source contains a provider-isolation TODO in model-cache eligibility and a cache entry without provider/auth identity. This is mechanism evidence requiring reconciliation, not incident causation.

## Strongest competing Event B explanations

**Local configuration pathway.** A live configuration snapshot modified at `2026-09-16T14:31:42.964316Z`, approximately 13 hours 24 minutes after the final Event B balance endpoint, contains `service_tier="priority"`. It does not establish its first-write time, writer, Event-B effectiveness or knowing authorization.

**Ordinary-charging magnitude compatibility.** Under current rates and a separate historical 25-credits-per-US-dollar observation, known-model usage maps to approximately US$26.05 against the first-party-reported US$29.12 decline: **89.47% compatibility**. Cross-time pricing, guardian costs, authorization, attribution and the historical provider ledger remain unresolved. This is substantial provider-favorable evidence, not proof of correct historical billing.

The defective v1.6.4 guardian token-range estimator remains withdrawn.

## Event A: narrower evidentiary strength

Event A is a rapid-depletion/reload episode requiring reconciliation, not an established anomaly. The authentication summary records two provider notices for 5,125 and 5,048 credits, and the owner attests that corresponding bank-account transactions were US$164.99 and US$162.51. Complete raw MIME and bank records are not distributed.

The package cannot reconstruct historical token mix, valid consumption, debit sequence, unused-credit state, provider-ledger currency or improper loss for Event A.

## Information needed to discriminate among explanations

The present record cannot resolve request identity, account/funding identity, intended target, tier authorization, historical price/currency, settlement and guardian/retry treatment without provider-side records. HORTRAME requests those records. Stable opaque identifiers or attributable provider attestation are acceptable where they preserve equivalent row-level linkage.

## Separate claimant action

HORTRAME's **US$356.62** opening settlement request is a claimant-selected negotiation position under `03_CLAIMANT_POSITION`. It is not an evidential estimate or adversarial-review output.
