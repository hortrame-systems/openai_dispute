> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# OpenAI dispute package v1.6.7 — everything substantive

**Release date:** 2026-09-22  
**Status:** final local trusted-review package; not submitted

## Scope

This profile contains the complete current v1.6.7 case and deliberately restores broad safe telemetry, complaint/source inventory, historical HTML, exact historical scripts and superseded analytical history.

The current controlling materials are:

1. `REQUEST_TO_OPENAI.md`
2. `EXECUTIVE_CASE_SUMMARY.md`
3. `CLAIM_STATUS_AND_LIMITS.md`
4. `../02_CURRENT_ANALYSES/51_CURRENT_CLAIM_LEDGER_v1.6.7.csv`
5. `../02_CURRENT_ANALYSES/61_EVIDENCE_CLASSIFICATION_AND_DISCLOSURE_MAP_v0.1.md`
6. `../03_CLAIMANT_POSITION/OPENING_SETTLEMENT_REQUEST_v1.6.7.md`

Everything under `08_HISTORICAL_SUPERSEDED` is non-controlling correction history.

v1.6.7 removes audience-conditioned settlement protection from the review layer, elevates the post-event local Priority configuration, foregrounds the 89.47% provider-favorable compatibility alternative, narrows Event A, maps claimant authority and classifies every claim by evidence/disclosure type.

## Separate claimant action

HORTRAME selects **US$356.62** as an opening negotiation request. It is isolated from the forensic review and is not an evidential estimate or independently established damages.

## Privacy

This package is for trusted review only. Broad telemetry is included because the owner requested the everything-substantive standard. Account-level host and project identifiers in the broad local thread catalog are pseudonymized, but extensive operational metadata remains.

## Verification

Run:

`python 05_VERIFICATION/verify_everything_substantive_v1.6.7.py`

A PASS establishes declared package, included-evidence and current-path checks, not semantic entailment or independent validation of every forensic conclusion.
