> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Unified credit-depletion case thesis v1.0

## Core question

Were affected requests attached to intended work, charged to the correct funding identity, knowingly authorized for Fast/Priority, and priced and settled under the applicable historical terms and currency?

## Event A

The included authentication summary records two provider notices reporting `$164.99` and `$162.51` and 5,125 plus 5,048 added credits. The owner separately attests that the corresponding bank-account transaction currency is USD. The package does not contain the bank statement or complete raw MIME, and neither source establishes provider-authoritative accounting currency, valid consumption or final improper loss.

## Event B

Local records establish six persisted segments, 21 guardian submissions (one represented in the six and 20 additional), explicit older-root client submissions, five acute Priority request fields, auth/catalog churn and projection inconsistencies. The records do not establish which visible composer or device submitted those inputs, which task the owner intended, deliberate switching, unintended targeting or funding attribution.

A live configuration snapshot modified about 13 hours 24 minutes after the last Event B balance endpoint contains `service_tier="priority"`. It is a material local alternative pathway. The snapshot does not establish its first-write time, writer, Event-B effectiveness or knowing owner authorization.

The v1.6.4 guardian token-range estimate is withdrawn because it subtracted turn-level counters across distinct turns within a thread. The request count survives; guardian token magnitude does not.

The owner now expressly attests that Fast/Priority was never knowingly authorized through any named mechanism during the affected period. That testimony is not telemetry but directly frames the authorization dispute.

## Exact-runtime mechanism evidence

The public source at `rust-v0.154.0-alpha.6.2` contains a TODO to include provider identity in cache eligibility so another provider's fresh model cache is not reused. The cache entry lacks provider/auth identity. A later OpenAI fix says identity switching could reuse a prior catalog and default service tier.

This materially supports investigation of catalog/tier provenance. It does not prove that the weakness caused this incident.

## Economic interpretation

Current-rate arithmetic shows that ordinary Fast charging is compatible with much of the first-party-represented Event B US$ decline under a separate 25-credits-per-US-dollar historical-interface assumption. Event A's notices imply a materially different displayed-dollar conversion. Historical contract, provider currency, pricing and settlement remain decisive.

The strongest provider-favorable magnitude alternative is explicit: known-model activity maps to approximately US$26.05 against the reported US$29.12 decline—89.47% compatibility—under current rates and the cross-time 25-credits-per-US-dollar assumption. This is substantial counterevidence to a simple excessive-magnitude theory, but it does not prove historical billing correctness, authorization, attribution or provider currency.

The clustering of 5,125, 5,048 and 5,004.18 credits is compatible with an approximately 5,000-credit reload target, but a purchase option and clustered magnitudes do not establish a fixed automatic target. That explanation remains a provider-configuration-dependent hypothesis.

## Non-derivation of settlement amount

This forensic thesis does not produce a settlement number. The claimant-selected US$356.62 request is isolated under `03_CLAIMANT_POSITION` as a NORM/ACTION object. The review neither derives nor validates that amount.

The present record cannot determine authoritative currency, terms, debits or settlement without provider-side evidence. HORTRAME requests those records; necessity for resolving the inference does not itself create authority over the provider.

## Surviving proposition

The preserved record supports a specific billing and authorization dispute that client-side evidence cannot close. OpenAI's request-level account, tier-provenance, historical-price, currency, debit and settlement records are the discriminating evidence.
