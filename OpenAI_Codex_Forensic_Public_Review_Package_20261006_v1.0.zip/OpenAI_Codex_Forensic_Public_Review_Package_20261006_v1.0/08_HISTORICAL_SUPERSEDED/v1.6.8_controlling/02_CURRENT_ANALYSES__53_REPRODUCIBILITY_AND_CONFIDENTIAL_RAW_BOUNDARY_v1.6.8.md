> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Reproducibility and confidential-raw boundary v1.6.8

## Reproducible from distributed evidence

- Package membership, bytes and hashes.
- Six persisted-segment arithmetic and event-specific row membership.
- Current claim-ledger, claim-source path bindings and credit-component-allocation structure.
- Event A credit arithmetic: 5,125 + 5,048 = 10,173.
- Provisional component arithmetic: 10,173 + 5,004.180745 = PRIVATE_REMEDIATION_AMOUNT_WITHHELD credits.
- Conditional Fast sensitivity: 14,284.954247 − (14,284.954247 / 2.5) = 8,570.9725482 credits.
- Scenario overlap rules preventing the September 15 bucket, full export and conditional premium from being added together.
- Every structured component evidence reference resolves to a current package path.
- The post-event `service_tier="priority"` row and its recorded file modification time.
- Exact public-source URLs and current official documentation references.

## Inspectable but source-extraction dependent

- Sanitized submission, guardian, auth/catalog, retry, queue and thread-projection findings.
- Raw email authentication summary without full MIME.
- First-party attestations.
- The 99.985% Fast-labelled export observation, whose examined source is external to the distributable package.
- Historical transaction screenshots containing individual credit purchases; exact credit quantities are not distributed.

Portable scripts are included, but rerunning raw derivations requires controlled access to the confidential snapshot. A verifier PASS establishes package/included-evidence integrity and mechanical reference resolution. It does not establish semantic entailment, independence or final correctness of every conclusion.

## Provider-controlled

- Historical plan/seat entitlement and included allowances.
- Manual-purchase and auto-reload quantities, balances, expiry and funding-pool linkage.
- Account/funding assignment.
- Tier authorization provenance.
- Request-level credit debit, remaining balance and adjustment settlement.

Neither a directory title nor the existence of a coverage matrix establishes independent review.

`61_EVIDENCE_CLASSIFICATION_AND_DISCLOSURE_MAP_v0.1.md` defines the evidence/disclosure classes applied claim by claim in `CLAIM_SOURCE_COVERAGE.csv`.
