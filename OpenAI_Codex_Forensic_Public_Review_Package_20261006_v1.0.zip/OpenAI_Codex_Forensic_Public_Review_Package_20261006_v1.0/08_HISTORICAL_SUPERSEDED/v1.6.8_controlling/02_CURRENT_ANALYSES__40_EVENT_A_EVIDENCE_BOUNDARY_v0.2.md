> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Event A evidence boundary correction v0.2

**Date:** 2026-09-18  
**Status:** current supporting correction to `17_CREDIT_DEPLETION_SPEED_PRIMARY_ANALYSIS_v0.1.md`

Event A (Aug 30–Sep 1) is a **rapid-depletion/reload episode requiring reconciliation, with coarse activity controls**. It is not economically workload-normalized, and the present record does not establish abnormal or improper loss.

## Established chronology

- first observed local Priority: 2026-08-30 07:43:43.328 EDT;
- first large automatic reload: approximately 5,125 displayed credits / $164.99;
- second large automatic reload: approximately 5,048 displayed credits / $162.51, roughly two hours later;
- stored manual reset used roughly ten minutes later;
- billing dispute opened contemporaneously within minutes of the second reload.

The exact request→debit sequence is absent locally. The package therefore does not claim that exactly 5,125 credits were debited to zero within two hours.

## Coarse activity controls

Aug 29, before observed Priority:

- 1,049 task starts;
- 2,284 message records;
- 299,437,591 rollout bytes.

Aug 31, mixed Default/Priority:

- 1,274 task starts;
- 3,477 message records;
- 876,017,789 rollout bytes.

Aug 31 / Aug 29 ratios:

- task starts ≈ 1.21×;
- message records ≈ 1.52×;
- rollout bytes ≈ 2.93×.

The largest pre-Priority two-hour task-start burst on Aug 29 was 381 tasks. The largest post-onset Aug 30–31 two-hour burst in the current safe extraction was 277 tasks.

These observations contradict only the simplest explanation that the observed timing resulted from the user suddenly initiating orders-of-magnitude more tasks per unit time.

They do **not** normalize token volume, cached context, context size, model mix, reasoning effort, hidden/provider-side work, or billed units.

## Missing economic denominator

The current `token_usage_events.csv` begins Sep 4. The present distributable safe extraction therefore cannot directly compare Aug 29 and Aug 31 token/context volume.

Promoted wording:

> Event A is a contemporaneous rapid-depletion/reload episode whose simplest task-count explanation is insufficient on current local proxies. Economic normalization and improper loss remain unresolved pending historical token/context/request accounting.
