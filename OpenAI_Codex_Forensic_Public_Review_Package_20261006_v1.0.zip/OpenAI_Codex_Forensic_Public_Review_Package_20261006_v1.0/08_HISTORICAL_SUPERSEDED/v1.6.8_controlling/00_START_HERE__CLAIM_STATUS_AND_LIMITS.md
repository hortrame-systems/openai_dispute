> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Claim status and limits — v1.6.8

The controlling classification is `../02_CURRENT_ANALYSES/51_CURRENT_CLAIM_LEDGER_v1.6.8.csv`.

## Established

- Two provider-reported Event A reload quantities: 5,125 and 5,048 credits—10,173 total.
- Priority chronology and five acute transmitted Priority overrides.
- Six paired persisted-segment arithmetic.
- Twenty-one guardian submissions: one represented in the six persisted segments and twenty additional.
- Explicit inputs attached to the older root.
- Auth/catalog and thread-projection observations.
- Exact-runtime public cache-isolation weakness.
- A post-event live configuration snapshot modified at `2026-09-16T14:31:42.964316Z` contains `service_tier="priority"`; its earlier existence, writer and Event-B effectiveness are not established.
- The examined workspace export reconstructs 14,287.106991 purchased-credit debits, including 14,284.954247 Fast-labelled credits and a 5,004.180745 September 15 bucket. The raw export is external to the distributable package.

## First-party testimony

The owner states they absolutely never knowingly authorized Fast/Priority through a command, UI toggle, saved setting, workspace/admin setting, automation or other method during Aug. 30–Sep. 15. This is scoped testimony, not telemetry.

The owner also states that the relevant bank-account transactions are in USD. Event B messages independently preserve first-party `US$` endpoint representations. Neither establishes provider-authoritative accounting currency.

The owner states that the personal account was US$200/20x, the affected Work accounts were US$125/10x, individual credits were also purchased, and the remedy should be paid in credits. The local record corroborates `ChatGPT Pro 20x` and repeated US$125 Work budget reports; it does not independently prove Work `10x` or the exact included allowances.

## Conditional calculations

- `US$29.12` Event B decline from first-party USD balance reports.
- 651.3204-credit current-rate compatibility scenario.
- 89.47% magnitude compatibility under current rates and a separate historical 25-credits-per-US-dollar observation.
- 8,570.9725482-credit Fast-premium sensitivity if 14,284.954247 Fast-labelled credits used a historical 2.5x multiplier. This overlaps the workspace export and is not additive to the September 15 bucket.

The v1.6.4 estimate of 0.235–0.724 million transient guardian input tokens is suspended because its calibration differenced turn-level counters across separate turns. No replacement guardian-token range is asserted in v1.6.8.

## Separate claimant action

The US$356.62 request is superseded. HORTRAME selects **PRIVATE_REMEDIATION_AMOUNT_WITHHELD credits** as a provisional full-component opening request under `../03_CLAIMANT_POSITION`. This is NORM/ACTION, not the exact final credits owed or adversarial-review output.

## Not established

- Provider-authoritative accounting currency for Event A or Event B.
- One common provider-ledger currency across all components.
- Exact final credits owed.
- Historical credit purchase price, discount, contract or conversion.
- The tier-setting writer or authorization event.
- Intended visible task for older-root inputs.
- Request-level funding identity, debit and settlement.
- Turn/request-aware guardian token magnitude, cache treatment and debit.
- A fixed approximately 5,000-credit automatic reload target.
- Whether the post-event `service_tier="priority"` configuration existed or was effective during Event B, who or what wrote it, and whether it reflected knowing owner authorization.
- The legal identity relationships and negotiation/reimbursement authority among HORTRAME, the account holder and the payer.
- Historical personal/Work included allowances, Work `10x` provider terms, complete manual-purchase credit quantities, remaining balances and expiry.
