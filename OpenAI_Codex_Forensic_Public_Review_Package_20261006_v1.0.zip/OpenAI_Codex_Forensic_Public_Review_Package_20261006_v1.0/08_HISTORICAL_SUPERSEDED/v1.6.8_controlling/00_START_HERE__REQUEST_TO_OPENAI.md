> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Request to OpenAI — v1.6.8

## Requested credit remedy

We withdraw the US$356.62 dollar-denominated request. We request restoration of **PRIVATE_REMEDIATION_AMOUNT_WITHHELD credits** as the provisional full-component opening position:

- Event A invoice INVOICE_0003: 5,125 credits;
- Event A invoice INVOICE_0004: 5,048 credits; and
- September 15 purchased-credit export bucket: 5,004.180745 credits.

The quantities are documented. Their status as improper loss is not established. This is a claimant-selected NORM/ACTION, not the exact final credits owed or adversarial-review output.

Please apply the final remedy in credits to the affected funding pools or, if consolidation is necessary, to an owner-designated account without reducing included allowance or imposing a shorter expiry.

Individual manual credit purchases are not converted from dollars or added to the provisional total. Please identify their purchased quantities, funding pools, debits, remaining balances, expiry and adjustments so any stranded or improperly consumed credits can be added without double-counting usage already present in the export.

## Balanced evidentiary context

The package expressly records two material provider-favorable alternatives:

- under current rates and a separate historical 25-credits-per-US-dollar observation, 651.3204 known-model credits are 89.47% compatible with a nominal 728-credit balance decline; and
- a post-event local configuration snapshot contains `service_tier="priority"`, although its first-write time, writer and Event-B effectiveness are unresolved.

Neither alternative proves historical billing correctness or knowing authorization. They are included because they materially affect causal discrimination.

## Minimum dispositive ledger

For each proposed reduction, identify:

1. request, response, turn, client and root/thread IDs;
2. UTC submission, completion, retry and settlement timestamps;
3. account, workspace, auth-principal and funding-pool IDs;
4. submitting surface and visible selected task;
5. requested/resolved tier and the writer, prior value and authorization event;
6. model, reasoning and exact token fields;
7. historical plan/seat entitlement, included allowance, reset/manual-reset grants and expiry;
8. each manual purchase and auto-reload's credit quantity, funding pool, pre/post balance and remaining balance;
9. historical rate card, multiplier stacking and purchased-versus-included funding treatment; and
10. debit, balance before/after, unused/stranded-credit state and later credit adjustment/refund.

Stable opaque or pseudonymized identifiers are acceptable where they preserve equivalent row-level linkage. An attributable provider attestation may replace a sensitive field if it states the field tested, method, result and responsible team. Aggregate assurance or an unlinked summary is not equivalent to reconciliation.

## Current authorization testimony

The owner states they never knowingly enabled or authorized Fast/Priority by command, UI, saved setting, workspace/admin setting, automation or any other method during the affected period. A client request containing `service_tier=priority` establishes transmitted state, not informed authorization.

## Exact-runtime mechanism question

The public source for `rust-v0.154.0-alpha.6.2` explicitly notes that provider identity still needed to be added to model-cache eligibility to prevent another provider's fresh cache from being reused. Please reconcile the Event B token revocation and catalog/ETag transition against account/auth identity and cache eligibility.

Please also reconcile the historical configuration/tier-resolution chain against the post-event `service_tier="priority"` snapshot so its writer, first-write time and effective interval can be distinguished from cache/catalog and other pathways.

## Response standard

A global statement that usage was valid does not resolve the identified components. Please cite the specific historical rows supporting each proposed reduction so the parties can reconcile the remaining dispute precisely.

The exact final credit remedy is: invalid or misattributed debits + unauthorized tier-premium excess + unused/stranded purchased-credit balance − prior credit adjustments or refunds.
