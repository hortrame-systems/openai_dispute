#!/usr/bin/env python3
from __future__ import annotations

import csv
import datetime as dt
import importlib.util
import json
import pathlib
import sys


ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True


def load_module(path: pathlib.Path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


fixture = json.loads((ROOT / "03_CORRECTED_DERIVED_EVIDENCE/GUARDIAN_COUNTER_BOUNDARY_REGRESSION.json").read_text(encoding="utf-8"))
estimator = load_module(ROOT / "05_VERIFICATION/portable_raw_queries/estimate_guardian_transient_tokens.py")
audit = estimator.audit_rows(fixture["records"])
assert audit["status"] == "SUSPENDED_PENDING_TURN_AWARE_RECALIBRATION"
assert audit["current_estimate"] is None
for key, value in fixture["expected"].items():
    assert audit["demonstrated_counterexample"][key] == value

summary = (ROOT / "00_START_HERE/EXECUTIVE_CASE_SUMMARY.md").read_text(encoding="utf-8")
assert "one represented in the six segments and 20 additional" in summary
assert "21 transient guardian submissions outside" not in summary
assert "89.47% compatibility" in summary
assert "2026-09-16T14:31:42.964316Z" in summary
assert "rapid-depletion/reload episode" in summary
assert "PRIVATE_REMEDIATION_AMOUNT_WITHHELD" in summary
assert "8,570.9725482" in summary
assert "US$356.62 opening settlement request" not in summary

diagnostic = json.loads((ROOT / "03_CORRECTED_DERIVED_EVIDENCE/EVENT_B_GUARDIAN_TRANSIENT_INPUT_DIAGNOSTIC.json").read_text(encoding="utf-8"))
assert diagnostic["status"] == "SUSPENDED_PENDING_TURN_AWARE_RECALIBRATION"
assert diagnostic["current_estimate"] is None

balance = json.loads((ROOT / "03_CORRECTED_DERIVED_EVIDENCE/EVENT_B_BALANCE_WINDOW_CURRENT_RATE_SENSITIVITY.json").read_text(encoding="utf-8"))
assert balance["reported_balance_observation"] == {
    "amount": 29.12,
    "first_party_currency_representation": "USD",
    "first_party_notation": "US$",
    "provider_authoritative_currency": "UNDERDETERMINED",
    "source_class": "CONTEMPORANEOUS_FIRST_PARTY_REPORT",
}
assert "reported_balance_decline_usd" not in balance
assert balance["conditional_historical_conversion"]["conversion_currency"] == "USD"

with (ROOT / "02_CURRENT_ANALYSES/51_CURRENT_CLAIM_LEDGER_v1.6.8.csv").open(newline="", encoding="utf-8-sig") as stream:
    claims = {row["claim_id"]: row for row in csv.DictReader(stream)}
assert len(claims) == 39
assert claims["CL168-09"]["status"] == "SUSPENDED_DEFECTIVE_ESTIMATOR"
for phrase in ["America/Toronto", "GPT-5.6 Sol", "GPT-6 Astra", "known-tier"]:
    assert phrase in claims["CL168-04"]["claim"]
assert claims["CL168-28"]["status"] == "HYPOTHESIS_REQUIRING_PROVIDER_CONFIGURATION"
assert claims["CL168-31"]["status"] == "SUPERSEDED_WRONG_REMEDY_METRIC"
assert claims["CL168-32"]["status"] == "FIRST_PARTY_USD_SUPPORTED_PROVIDER_CURRENCY_UNDERDETERMINED"
assert claims["CL168-36"]["status"] == "ESTABLISHED_POST_EVENT_LOCAL_CONFIG_SNAPSHOT"
assert claims["CL168-37"]["status"] == "MIXED_LOCAL_RECORD_AND_FIRST_PARTY_PLAN_TESTIMONY"
assert claims["CL168-38"]["status"] == "CLAIMANT_SELECTED_PROVISIONAL_CREDIT_ACTION"
assert claims["CL168-39"]["status"] == "CONDITIONAL_EXTERNAL_EXPORT_FAST_PREMIUM_SENSITIVITY"

cohort = json.loads((ROOT / "03_CORRECTED_DERIVED_EVIDENCE/PRIORITY_COHORT_RECOMPUTATION.json").read_text(encoding="utf-8"))
assert cohort["counts"]["priority_total"] == 1441
assert cohort["counts"]["known_tier_total"] == 1444

settings = ROOT / "07_SUBSTANTIVE_EVIDENCE/stage2safe/thread_settings_events.csv"
if settings.is_file():
    start = dt.datetime.fromisoformat("2026-09-02T04:00:00+00:00")
    end = dt.datetime.fromisoformat("2026-09-16T04:00:00+00:00")
    models = set(cohort["included_models"])
    counts = {"priority": 0, "default": 0, "missing": 0}
    with settings.open(newline="", encoding="utf-8-sig") as stream:
        for row in csv.DictReader(stream):
            stamp = dt.datetime.fromisoformat(row["timestamp"].replace("Z", "+00:00"))
            if not start <= stamp < end or row.get("model") not in models:
                continue
            tier = row.get("service_tier") or "missing"
            counts[tier] = counts.get(tier, 0) + 1
    assert counts == {"priority": 1441, "default": 3, "missing": 7}

for relative in [
    "00_START_HERE/EXECUTIVE_CASE_SUMMARY.md",
    "02_CURRENT_ANALYSES/50_UNIFIED_CREDIT_DEPLETION_CASE_THESIS_v1.1.md",
    "02_CURRENT_ANALYSES/52_PROVIDER_RECORD_REQUEST_v1.6.8.md",
]:
    text = (ROOT / relative).read_text(encoding="utf-8").lower()
    assert "genuine user-initiated" not in text
    assert "genuine user initiated" not in text

auth_summary = ROOT / "01_FROZEN_REFERENCES/PROVIDER_EMAIL_AUTHENTICATION_SUMMARY_20260917.md"
assert auth_summary.is_file()
assert "DKIM: pass" in auth_summary.read_text(encoding="utf-8")

component_path = ROOT / "02_CURRENT_ANALYSES/56_CREDIT_COMPONENT_ALLOCATION_TEMPLATE_v1.6.8.csv"
with component_path.open(newline="", encoding="utf-8-sig") as stream:
    components = list(csv.DictReader(stream))
assert len(components) == 3
for component in components:
    assert component["credit_quantity"] in {"5125", "5048", "5004.180745"}
    assert component["remaining_credit_claim"] == component["credit_quantity"]
    assert (ROOT / component["evidence_reference"]).is_file()

with (ROOT / "07_EXTERNAL_REVIEW_MATERIALS/CLAIM_SOURCE_COVERAGE.csv").open(newline="", encoding="utf-8-sig") as stream:
    coverage = list(csv.DictReader(stream))
assert len(coverage) == 39
allowed_classes = {
    "PACKAGE_REPRODUCIBLE",
    "ESTABLISHED_FROM_AUTHENTICATED_EXTERNAL_SOURCE_NOT_DISTRIBUTED",
    "ESTABLISHED_FROM_EXAMINED_EXTERNAL_SOURCE_NOT_DISTRIBUTED",
    "EXTERNAL_SOURCE_INVENTORY_BOUND",
    "FIRST_PARTY_TESTIMONY",
    "PUBLIC_SOURCE_EVIDENCE",
    "CONDITIONAL_INFERENCE",
    "PROVIDER_CONTROLLED_CLOSURE",
    "NORMATIVE_ACTION",
    "CORRECTION_RECORD",
}
for row in coverage:
    paths = [item for item in row["source_paths"].split(";") if item]
    assert paths
    for relative in paths:
        assert not relative.startswith("08_HISTORICAL_SUPERSEDED/")
        assert (ROOT / relative).is_file(), (row["claim_id"], relative)
    classes = {item for item in row["evidence_class"].split(";") if item}
    assert classes and classes.issubset(allowed_classes), (row["claim_id"], classes)

review = (ROOT / "04_REVIEW/ADVERSARIAL_REVIEW_RESPONSE_v1.6.8.md").read_text(encoding="utf-8")
assert "review neither derives nor validates" in review.lower()
assert "exact final credits owed" in review.lower()
assert "PRIVATE_REMEDIATION_AMOUNT_WITHHELD" in review
assert "8,570.9725482" in review

request = (ROOT / "02_CURRENT_ANALYSES/52_PROVIDER_RECORD_REQUEST_v1.6.8.md").read_text(encoding="utf-8")
assert "Stable opaque or pseudonymized identifiers" in request
assert "Aggregate assurance" in request
assert "US$356.62 request is withdrawn" in request

config_rows = list(csv.DictReader((ROOT / "03_MINIMIZED_SAFE_EVIDENCE/SELECTED_CONFIG_KEYS.CSV").open(newline="", encoding="utf-8-sig")))
tier_rows = [row for row in config_rows if row["key"] == "service_tier"]
assert len(tier_rows) == 1
assert "priority" in tier_rows[0]["value"]
assert tier_rows[0]["file_mtime_utc"] == "2026-09-16T14:31:42.964316+00:00"

event_a = (ROOT / "02_CURRENT_ANALYSES/40_EVENT_A_EVIDENCE_BOUNDARY_v0.2.md").read_text(encoding="utf-8")
assert "billing/depletion anomaly" not in event_a
assert "rapid-depletion/reload episode" in event_a

thesis = (ROOT / "02_CURRENT_ANALYSES/50_UNIFIED_CREDIT_DEPLETION_CASE_THESIS_v1.1.md").read_text(encoding="utf-8")
guardian = (ROOT / "02_CURRENT_ANALYSES/47_EVENT_B_SUBMISSION_AND_GUARDIAN_COMPLETENESS_CORRECTION_v0.3.md").read_text(encoding="utf-8")
assert "The provider must" not in thesis
assert "OpenAI must" not in guardian

assert (ROOT / "03_CLAIMANT_POSITION/OPENING_CREDIT_REMEDY_REQUEST_v1.6.8.md").is_file()
assert (ROOT / "02_CURRENT_ANALYSES/60_CLAIMANT_STANDING_AND_AUTHORITY_MAP_v0.1.md").is_file()
assert (ROOT / "02_CURRENT_ANALYSES/61_EVIDENCE_CLASSIFICATION_AND_DISCLOSURE_MAP_v0.1.md").is_file()
assert (ROOT / "02_CURRENT_ANALYSES/62_PLAN_SURFACE_AND_CREDIT_REMEDY_BOUNDARY_v0.1.md").is_file()

remedy = json.loads((ROOT / "03_CORRECTED_DERIVED_EVIDENCE/CREDIT_REMEDY_ARITHMETIC_v1.6.8.json").read_text(encoding="utf-8"))
assert remedy["event_a"]["reload_credits_total"] == 10173
assert remedy["workspace_export"]["purchased_credits_total"] == 14287.106991
assert remedy["workspace_export"]["sep15_bucket_credits"] == 5004.180745
assert remedy["conditional_fast_sensitivity"]["conditional_excess_credits"] == 8570.9725482
assert remedy["conditional_fast_sensitivity"]["additive_to_sep15_or_full_export"] is False
assert remedy["claimant_selected_provisional_request"]["credits"] == PRIVATE_REMEDIATION_AMOUNT_WITHHELD
assert remedy["claimant_selected_provisional_request"]["exact_proven_improper_loss"] is False
assert remedy["manual_individual_purchases"]["credit_quantity"] is None
assert remedy["manual_individual_purchases"]["dollar_conversion_permitted"] is False
assert remedy["workspace_export"]["raw_export_embedded"] is False
assert remedy["workspace_export"]["source_class"] == "EXAMINED_EXTERNAL_EXPORT_NOT_DISTRIBUTED_IN_EXTERNAL_REVIEW_PACKAGE"

frozen_report = ROOT / remedy["workspace_export"]["everything_profile_reference"]
if frozen_report.is_file():
    frozen_text = frozen_report.read_text(encoding="utf-8", errors="ignore")
    assert '"purchased_credits": 14287.106991' in frozen_text
    assert "14,284.954247" in frozen_text

print("PASS: v1.6.8 credit-remedy metric, overlap and plan-evidence corrections")
