> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Correction disposition v1.6.8

## Closed from the 2026-10-01 remedy-metric correction

- Superseded the US$356.62 opening request; dollars remain transaction evidence, not the remedy unit.
- Separated subscription/seat allowance, manual credit purchases, automatic reload funding and purchased-credit debits.
- Added plan-surface testimony and its local corroboration/verification limits.
- Added exact credit arithmetic and overlap controls.
- Selected a provisional PRIVATE_REMEDIATION_AMOUNT_WITHHELD-credit claimant request without calling it the exact final credits owed.
- Preserved the 8,570.9725482-credit Fast-premium sensitivity as conditional and non-additive.
- Refused to convert the US$164.17 residual manual-purchase funding into credits without purchase/balance evidence.

## Earlier corrections retained

- Removed the review-layer commitment to preserve the owner's selected settlement stance.
- Isolated claimant-selected NORM/ACTION from review output.
- Retained CL168-36 for the post-event local `service_tier="priority"` configuration snapshot.
- Foregrounded the 89.47% provider-favorable Event B magnitude compatibility.
- Reclassified Event A as a rapid-depletion/reload episode requiring reconciliation, not an established anomaly.
- Replaced unsupported provider-compulsion language with statements of evidentiary need and explicit requests.
- Added a claimant/account-holder/payer/authority map with unresolved roles left unresolved.
- Added claim-level evidence/disclosure classes.

- Restored `PROVIDER_EMAIL_AUTHENTICATION_SUMMARY_20260917.md` and bound it through package manifest and hash inventories.
- Preserved two currency registers: first-party USD representation/attestation and provider-authoritative accounting currency.
- Reclassified the approximately 5,000-credit fixed-target explanation as a provider-configuration-dependent hypothesis.
- Replaced unsupported “independently checked” wording with “rechecked in a separate pass.”
- Added deterministic current-path checks for every component evidence reference and every claim-source binding.
- Kept semantic support as a review judgment; verifier PASS does not claim entailment or independence.
- Added privacy-preserving reconciliation through stable opaque IDs or attributable provider attestation while rejecting unlinked aggregate assurance.

- Guardian cohort overlap remains explicit: 21 total, one represented and 20 additional.
- The defective guardian token-range estimate remains suspended.
- The 1,441/1,444 Priority statistic retains its Toronto-day, model and known-tier denominator boundaries.
- Client submissions are not relabelled as proven user-initiated turns.
- Exact-runtime cache evidence remains bounded as a mechanism/provenance question, not incident causation.

## Claimant action separated

The claimant selects a provisional PRIVATE_REMEDIATION_AMOUNT_WITHHELD-credit opening request under `03_CLAIMANT_POSITION`. The forensic review neither derives nor validates it. Exact final credits owed remain undetermined.

## Remaining dependencies

Historical plan entitlements, manual-purchase quantities, remaining balances, expiry, authorization provenance, configuration history, funding identity, credit debits/adjustments and exact final remedy remain provider-dependent. Negotiation and reimbursement authority remain procedurally unresolved in the distributable package.
