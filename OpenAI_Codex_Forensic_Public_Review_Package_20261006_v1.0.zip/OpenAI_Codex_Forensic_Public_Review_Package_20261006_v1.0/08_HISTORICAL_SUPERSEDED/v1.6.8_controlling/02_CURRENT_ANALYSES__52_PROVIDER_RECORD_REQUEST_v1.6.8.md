> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Provider record request v1.6.8

## Plan, purchase and credit-balance confirmation

For every affected personal and Work account/seat, provide the historical plan label, included allowance and accounting unit, reset/manual-reset grants, expiry, funding pool and effective dates. Confirm or correct the owner's US$200/20x personal and US$125/10x Work descriptions.

For each manual credit purchase and automatic reload, provide credit quantity, purchase/transaction identity, funding pool, balance before/after, remaining balance, expiry and later adjustment/refund. This includes invoices INVOICE_0003 and INVOICE_0004 and every individual purchase represented in the transaction history.

Reconcile the 14,287.106991 purchased-credit export total, 14,284.954247 Fast-labelled credits and 5,004.180745 September 15 bucket to accounts, purchases, requests and credit balances.

## Request-level reconciliation

For each debit proposed as valid, provide:

1. request, response, turn, client and root/thread IDs;
2. UTC submission, completion, retry and settlement timestamps;
3. account, workspace, auth-principal and funding-pool IDs;
4. submitting surface and visible selected task;
5. requested/resolved tier and tier-setting writer, prior value and authorization event;
6. model, reasoning and token fields;
7. historical plan/seat entitlement, included allowance, reset/manual-reset grants and expiry;
8. manual-purchase/auto-reload credit quantity, purchase identity, funding pool and remaining balance;
9. historical rate card, discount and multiplier stacking; and
10. debit, balance before/after, unused/stranded-credit state and later credit adjustment/refund.

## Privacy-preserving equivalence

Raw internal identifiers are not required where disclosure would expose sensitive systems or third-party data. Stable opaque or pseudonymized identifiers are acceptable if they preserve one-to-one and parent/child linkage across the requested rows. An attributable provider attestation is also acceptable for a field that cannot be disclosed if it states the field tested, method, result and responsible team and permits the parties to reconcile the same request, account/funding, tier-authorization and debit relationships.

Aggregate assurance, unverifiable redaction or an unlinked summary is not equivalent to row-level reconciliation.

## Fast/Priority authorization

The owner expressly denies ever knowingly authorizing Fast/Priority through a command, UI toggle, saved setting, workspace/admin setting, automation or any other method during Aug. 30–Sep. 15. Please identify any contrary authorization event rather than relying only on the transmitted tier field.

## Exact-runtime cache investigation

Reconcile the Event B `token_revoked` and catalog/ETag transition against provider/auth identity. Address the public `rust-v0.154.0-alpha.6.2` cache-eligibility TODO and identity-less file-cache entry, and state whether that code path affected these requests.

## Local configuration provenance

The package records a post-event live configuration modified at `2026-09-16T14:31:42.964316Z` with `service_tier="priority"`. Please provide the historical configuration/tier-resolution audit needed to identify its first-write time, writer, effective interval and relationship—if any—to Event B.

## Routing and guardian closure

Map older-root client IDs to authoritative submitting surfaces and visible task state. Provide completion, tier, tokens, deduplication and debit treatment for all 21 guardian submissions and the retry.

## Reconciliation posture

The US$356.62 request is withdrawn. A provisional PRIVATE_REMEDIATION_AMOUNT_WITHHELD-credit request is recorded separately under `03_CLAIMANT_POSITION` as claimant-selected NORM/ACTION. The exact final credit remedy remains provider-ledger dependent. This request does not assert a legal or contractual power to compel disclosure.
