> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Executive case summary — v1.6.8

## Forensic finding

The package supports a targeted provider-side reconciliation of Priority-tier authorization, routing, account/funding attribution, historical plan entitlements and credit debits. It does **not** establish the exact final credits owed, wrong-account billing, knowing Fast/Priority authorization, or incident causation by the public cache defect.

Dollar aggregation is withdrawn as the remedy metric. The affected personal and Work surfaces had different reported plan economics, and manual purchases, auto-reloads, included allowance and purchased-credit debits are distinct.

## Event B: established local core

- six paired persisted segments with 29,225,371 final cumulative input tokens;
- 21 guardian submissions: one represented in the six segments and 20 additional;
- explicit client inputs attached to the older root, with visible/intended surface unresolved;
- five acute new-turn requests carrying `service_tier=priority`;
- a `token_revoked` failure followed by a seven-to-eight-model catalog and ETag transition;
- inconsistent thread projections; and
- first-party testimony that Fast/Priority was never knowingly authorized.

The exact `rust-v0.154.0-alpha.6.2` public source contains a provider-isolation TODO in model-cache eligibility and a cache entry without provider/auth identity. This is mechanism evidence requiring reconciliation, not incident causation.

## Strongest competing Event B explanations

**Local configuration pathway.** A live configuration snapshot modified at `2026-09-16T14:31:42.964316Z`, approximately 13 hours 24 minutes after the final Event B balance endpoint, contains `service_tier="priority"`. It does not establish its first-write time, writer, Event-B effectiveness or knowing authorization.

**Ordinary-charging magnitude compatibility.** Under current rates and a separate historical 25-credits-per-US-dollar observation, known-model usage maps to 651.3204 credits against a nominal 728-credit balance decline: **89.47% compatibility**. Cross-time conversion, guardian costs, authorization, attribution and the historical provider ledger remain unresolved. This is substantial provider-favorable evidence, not proof of correct historical billing.

The defective v1.6.4 guardian token-range estimator remains withdrawn.

## Event A: narrower evidentiary strength

Event A is a rapid-depletion/reload episode requiring reconciliation, not an established anomaly. The authentication summary records two provider notices for 5,125 and 5,048 credits—10,173 credits total. This is exact funding quantity, not proof that all 10,173 credits were improperly consumed.

The package cannot reconstruct historical token mix, valid consumption, debit sequence, unused-credit state, provider-ledger currency or improper loss for Event A.

## Plan and purchased-credit boundary

- The personal surface is locally recorded as `ChatGPT Pro 20x`; the owner confirms a US$200/20x arrangement.
- The owner reports US$125/10x Work arrangements; local records corroborate repeated US$125 weekly-budget reports but do not independently prove `10x` or included allowances.
- The examined workspace export reconstructs 14,287.106991 purchased-credit debits, including a 5,004.180745 September 15 bucket.
- Individual manual purchases occurred, but their exact credit quantities and remaining balances are not in the distributable record. Dollar residuals are not converted into credits.

## Information needed to discriminate among explanations

The present record cannot resolve request identity, account/funding identity, intended target, tier authorization, historical entitlement/multiplier, purchased versus included funding, remaining balance, settlement and guardian/retry treatment without provider-side records. HORTRAME requests those records. Stable opaque identifiers or attributable provider attestation are acceptable where they preserve equivalent row-level linkage.

## Separate claimant action

HORTRAME withdraws the US$356.62 request and selects a provisional **PRIVATE_REMEDIATION_AMOUNT_WITHHELD-credit** full-component opening request: 10,173 Event A reload credits plus the 5,004.180745 September 15 export bucket. It is a claimant NORM/ACTION, not the exact final credits owed or adversarial-review output.

The separate 8,570.9725482-credit Fast-premium sensitivity is conditional, overlaps the workspace export and is not added.
