> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# OpenAI dispute package v1.6.8 — everything substantive

**Release date:** 2026-10-01  
**Status:** final local trusted-review package; not submitted

## Scope

This profile contains the complete current v1.6.8 case and deliberately restores broad safe telemetry, complaint/source inventory, historical HTML, exact historical scripts and superseded analytical history.

The current controlling materials are:

1. `REQUEST_TO_OPENAI.md`
2. `EXECUTIVE_CASE_SUMMARY.md`
3. `CLAIM_STATUS_AND_LIMITS.md`
4. `../02_CURRENT_ANALYSES/51_CURRENT_CLAIM_LEDGER_v1.6.8.csv`
5. `../02_CURRENT_ANALYSES/61_EVIDENCE_CLASSIFICATION_AND_DISCLOSURE_MAP_v0.1.md`
6. `../02_CURRENT_ANALYSES/62_PLAN_SURFACE_AND_CREDIT_REMEDY_BOUNDARY_v0.1.md`
7. `../03_CLAIMANT_POSITION/OPENING_CREDIT_REMEDY_REQUEST_v1.6.8.md`

Everything under `08_HISTORICAL_SUPERSEDED` is non-controlling correction history.

v1.6.8 replaces the dollar remedy with a credit-denominated structure, separates purchase funding from usage debits, records plan evidence limits, prevents overlapping credit scenarios from being added and leaves the exact final remedy provider-ledger dependent.

## Separate claimant action

HORTRAME selects **PRIVATE_REMEDIATION_AMOUNT_WITHHELD credits** as a provisional opening request. It is isolated from the forensic review and is not the exact final credits owed.

## Privacy

This package is for trusted review only. Broad telemetry is included because the owner requested the everything-substantive standard. Account-level host and project identifiers in the broad local thread catalog are pseudonymized, but extensive operational metadata remains.

## Verification

Run:

`python 05_VERIFICATION/verify_everything_substantive_v1.6.8.py`

A PASS establishes declared package, included-evidence and current-path checks, not semantic entailment or independent validation of every forensic conclusion.
