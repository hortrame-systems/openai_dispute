# Historical source boundary

All files in this directory record predecessor analyses and corrections. Old demands, estimates and causal statements are not controlling. They remain as adverse/correction history at their recorded scopes. References inside flattened historical files may name controlled original package members rather than current executable paths.
