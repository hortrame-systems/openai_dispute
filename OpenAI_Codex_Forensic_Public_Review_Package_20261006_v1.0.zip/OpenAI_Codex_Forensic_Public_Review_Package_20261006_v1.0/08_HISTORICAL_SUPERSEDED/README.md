> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Historical and superseded material

Nothing in this directory controls v1.6.9.

It preserves earlier releases, query sources and analytical corrections, including unsupported numerical probabilities, deliberate-switching overreach, prior guardian speculation, silent USD typing and unilateral “presumed due” language.

Use current files under `00_START_HERE`, `02_CURRENT_ANALYSES` and `04_REVIEW`. Use portable scripts under `05_VERIFICATION/portable_raw_queries` for any new controlled reproduction.
