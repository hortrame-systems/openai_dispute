> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Correction disposition v1.6.1

v1.6.1 is a complete standalone corrected release. It is not an addendum and does not require v1.6.0 to interpret it.

## Corrections integrated

- Older-root initiation is narrowed from wholly unresolved to established client input with unresolved submitting surface/thread target.
- Six-segment completeness is narrowed to six paired persisted segments; 21 transient guardian submissions are reported separately.
- Client Priority overrides are reported explicitly.
- The acute `token_revoked` and seven-to-eight-model catalog/ETag transition are added.
- Local thread-projection inconsistencies, remote/queue/automation alternatives and one retry are classified.
- Current-rate and exact balance-window sensitivities are added with explicit historical limits.
- Ordinary charging becomes the leading explanation for the reported decline magnitude; no overbilling amount is claimed.
- Provider requests now target authorization, surface routing, account/funding-pool attribution, guardian debits and canonical thread state.

## Findings preserved

- first observed Priority chronology;
- transition timing and no-exact-`/fast` result;
- six persisted-segment arithmetic;
- Event A economic-normalization limit;
- first-party balance evidence classification;
- public mechanism/failure-class corroboration;
- confidential raw boundary.

## Supersession

The v1.6.0 release remains immutable historical evidence and is archived after this package passes all release checks. v1.6.1 is the only release marked sendable, subject to owner review. External submission is not performed by this build.
