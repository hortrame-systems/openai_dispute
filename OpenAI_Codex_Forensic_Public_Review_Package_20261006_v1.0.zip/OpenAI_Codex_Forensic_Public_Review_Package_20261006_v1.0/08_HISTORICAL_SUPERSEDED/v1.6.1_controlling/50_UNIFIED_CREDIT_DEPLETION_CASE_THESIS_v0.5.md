> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Unified credit-depletion case thesis v0.5

**Date:** 2026-09-20  
**Status:** CURRENT CONTROLLING  
**Supersedes:** thesis v0.4 in the v1.6.0 release

## Corrected core question

Were the observed requests charged according to the applicable historical rules and to the correct account/funding pool, and was the client Priority state authorized and routed as the user intended?

The local evidence now makes ordinary debit arithmetic plausible. It does not establish authorization, account attribution or visible-thread targeting.

## Event A

The first observed local Priority state remains Aug. 30 at 07:43:43 EDT. Two large automatic reloads occur roughly two hours apart Aug. 31, followed by use of a stored manual reset and a contemporaneous billing dispute.

Task starts rise only 1.21× from Aug. 29 to Aug. 31, but rollout bytes rise 2.93× and most classified Aug. 31 task starts are Priority. A current-multiplier sensitivity produces a 5.37×–6.30× combined proxy. Event A is therefore not normalized economically, and ordinary workload/tier intensity remains a serious competing explanation.

The repeated approximately 5,000-credit magnitude may also follow mechanically from a fixed reload target or pack size. Provider reload configuration and settlement records are required.

## Event B — persisted segments and transient reviews

The six paired persisted segments report 29,225,371 final cumulative input tokens and 26,386,511 post-initial input tokens. Those calculations remain exact for their declared scope.

The union window also contains 21 transient guardian submissions. Only one is represented as a paired persisted segment. A diagnostic calibration estimates approximately 0.235–0.724 million additional guardian input tokens, but this is not measured usage and has no local debit mapping.

The six-segment set is therefore a persisted-segment reconstruction, not complete request accounting.

## Older-root correction

The two older-root turns were admitted by explicit client inputs: `Go` and `Is anything running? Be brief and tell me what`. The first was steered with a token-budget warning.

The remaining question is why these genuine inputs targeted the older root and which surface submitted them. Ordinary rapid task switching and cross-thread/UI routing divergence both remain viable.

## Priority and identity boundary

Five new acute root turns explicitly carry Priority in their client request. At event onset, a model-catalog refresh failed with `token_revoked`, followed by a seven-to-eight-model ETag transition reused across every acute root.

This establishes client Priority state plus auth/catalog churn. It does not establish that the wrong catalog, account or funding pool was used.

## Economic correction

Under today's official rates, five known-model persisted segments correspond to approximately 1,876.50 credits. More importantly, known-model usage inside the exact US$33.72→US$4.60 interval corresponds to 651.32 current-rate credits, or 89.47% of the 728 nominal credits represented by the reported decline at the historical purchase conversion.

Ordinary token charging is therefore the leading explanation for the reported decline magnitude. The economic dispute should not claim a proven excessive debit.

## Surviving unresolved questions

1. What set and authorized the client Priority state?
2. Which account/workspace/auth identity and funding pool served each request across the catalog transition?
3. Which surface and intended visible task produced each older-root client submission?
4. Which transient guardian/retry requests were billed and at what rate?
5. Which historical auto-reload, balance-settlement and included-allowance rules applied?

## Falsifiable disposition

- If provider records bind every request to the intended account/thread, authorized Priority state and correct historical debit rule, the economic anomaly is explained.
- If arithmetic is correct but Priority, account/funding-pool or routing authorization is wrong, the remedy concerns unauthorized or misattributed usage rather than rate calculation.
- If request/debit records do not reconcile, the discrepancy should be quantified and corrected.
- If the necessary records cannot be produced, the surviving finding is an auditability limitation.

## Public-facing statement

> Local records show high-context Priority work whose current-rate cost is broadly consistent with the reported Sep. 15 balance decline. They also show 21 transient review calls outside the six persisted segments, an auth/catalog transition, explicit client Priority overrides and genuine inputs attached to an older logical root. The evidence does not establish excessive debit arithmetic. OpenAI records are required to determine whether the Priority state, visible-thread target, account identity and funding pool were authorized and correctly attributed.
