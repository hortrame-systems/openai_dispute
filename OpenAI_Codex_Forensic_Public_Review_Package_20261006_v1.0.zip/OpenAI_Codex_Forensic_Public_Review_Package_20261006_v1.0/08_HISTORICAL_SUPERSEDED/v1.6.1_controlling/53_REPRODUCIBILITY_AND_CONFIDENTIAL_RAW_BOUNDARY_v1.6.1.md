> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Reproducibility and confidential-raw boundary v1.6.1

## Independently reproducible inside this package

- the six paired persisted-segment calculations from included safe tables;
- final-package hashes and manifest membership;
- the current-rate calculations from included persisted-segment metrics;
- deterministic consistency checks across the corrected claim ledger and derived JSON outputs.

## Controlled-access raw derivations

New submission, guardian, auth/catalog, queue, remote-enrollment, retry and thread-projection findings are derived from the authorized read-only Sep. 16 raw snapshot.

The package includes:

- sanitized derived JSON outputs;
- the exact query scripts;
- SHA-256 bindings for `logs_2.sqlite`, `state_5.sqlite`, `queue_1.sqlite` and `models_cache.json`; and
- the existing raw-rollout inventory digest.

The raw SQLite databases and rollout corpus are excluded because they contain confidential prompts, local paths, credentials-adjacent state and unrelated company material.

## Important limits

- A source hash proves which bytes were queried; it does not prove the client's log projection captured every provider request.
- Current official prices are a sensitivity input, not historical provider ledger evidence.
- Serialized guardian-log calibration is diagnostic, not token measurement.
- Desktop renderer/UI logs sufficient to prove the visible selected task are not present in the supplied snapshot.

## Read-only guarantee

All SQLite access uses URI `mode=ro&immutable=1` plus `PRAGMA query_only=ON`. No file in the supplied raw snapshot is modified.
