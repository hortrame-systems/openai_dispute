> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Event B current-rate and balance sensitivity v0.1

**Date:** 2026-09-20  
**Status:** CURRENT DIAGNOSTIC — not a historical charge reconstruction

## Purpose

Test whether ordinary token economics can plausibly explain the reported balance movement before alleging incorrect debit arithmetic.

Current official OpenAI documentation gives these standard ChatGPT/Codex credit rates per million tokens:

- GPT-6 Astra: 250 input, 25 cached input, 1,250 output credits;
- GPT-5.6 Sol: 100 input, 10 cached input, 500 output credits.

Current Fast mode applies a 2.5× multiplier to both models. These are current references verified 2026-09-20, not silently backdated Sep. 15 rules:

- http<PRIVATE_PATH>
- http<PRIVATE_PATH>

## Full persisted-segment sensitivity

Applying those current rates to the five known-model persisted segments yields approximately **1,876.50 credits**:

- Astra: 1,241.12 credits;
- Sol: 635.39 credits.

The persisted `codex-auto-review` segment and 20 additional transient guardian submissions remain unpriced.

## Exact reported-balance interval

The contemporaneous first-party reports are:

- US$33.72 at 01:00:18.979 UTC;
- US$4.60 at 01:07:29.072 UTC;
- reported decline: US$29.12.

The historical purchase UI reported 5,000 credits for US$200, a nominal 25 credits per US dollar. Under that nominal conversion, US$29.12 corresponds to **728 credits**.

For the same timestamp interval, applying the current rate card to the included known-model response-accounting increments gives:

- **651.3204 credits**;
- nominally US$26.0528 at 25 credits per US dollar;
- **89.47%** of the 728-credit reported decline.

The remaining nominal difference is 76.6796 credits / US$3.0672 before pricing:

- nine transient guardian submissions in that interval;
- historical versus current rate differences;
- included-plan versus purchased-credit allocation;
- balance display/settlement latency; or
- provider-only adjustments.

## Interpretation

This sensitivity makes ordinary charging the leading explanation for the **magnitude** of the US$33.72→US$4.60 decline. It does not resolve whether Priority was authorized, the correct account/funding pool was charged, every request was properly attributed, or the balance reports were ledger-exact.

Arithmetic plausibility and authorization correctness are separate questions.

## Event A sensitivity

Aug. 31 had 1.21× Aug. 29 task starts but 2.93× rollout bytes and 55.7% explicitly Priority task starts. Applying today's 2.5× multiplier only as a sensitivity factor gives a combined rollout-byte/tier proxy of roughly **5.37×–6.30×** Aug. 29.

Rollout bytes are not tokens and current pricing is not historical. This only shows why task-count normalization cannot rule out ordinary workload economics.

## Evidence

- `03_CORRECTED_DERIVED_EVIDENCE/EVENT_B_CURRENT_RATE_SENSITIVITY.json`
- `03_CORRECTED_DERIVED_EVIDENCE/EVENT_B_BALANCE_WINDOW_CURRENT_RATE_SENSITIVITY.json`
- `03_CORRECTED_DERIVED_EVIDENCE/EVENT_A_WEIGHTED_PROXY_SENSITIVITY.json`
