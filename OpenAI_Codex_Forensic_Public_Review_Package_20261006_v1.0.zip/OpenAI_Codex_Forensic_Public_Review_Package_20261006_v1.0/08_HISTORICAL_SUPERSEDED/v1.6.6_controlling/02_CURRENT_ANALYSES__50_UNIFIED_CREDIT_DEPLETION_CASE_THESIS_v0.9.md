> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Unified credit-depletion case thesis v0.9

## Core question

Were affected requests attached to intended work, charged to the correct funding identity, knowingly authorized for Fast/Priority, and priced and settled under the applicable historical terms and currency?

## Event A

The included authentication summary records two provider notices reporting `$164.99` and `$162.51` and 5,125 plus 5,048 added credits. The owner separately attests that the corresponding bank-account transaction currency is USD. The package does not contain the bank statement or complete raw MIME, and neither source establishes provider-authoritative accounting currency, valid consumption or final improper loss.

## Event B

Local records establish six persisted segments, 21 guardian submissions (one represented in the six and 20 additional), explicit older-root client submissions, five acute Priority request fields, auth/catalog churn and projection inconsistencies. The records do not establish which visible composer or device submitted those inputs, which task the owner intended, deliberate switching, unintended targeting or funding attribution.

The v1.6.4 guardian token-range estimate is withdrawn because it subtracted turn-level counters across distinct turns within a thread. The request count survives; guardian token magnitude does not.

The owner now expressly attests that Fast/Priority was never knowingly authorized through any named mechanism during the affected period. That testimony is not telemetry but directly frames the authorization dispute.

## Exact-runtime mechanism evidence

The public source at `rust-v0.154.0-alpha.6.2` contains a TODO to include provider identity in cache eligibility so another provider's fresh model cache is not reused. The cache entry lacks provider/auth identity. A later OpenAI fix says identity switching could reuse a prior catalog and default service tier.

This materially supports investigation of catalog/tier provenance. It does not prove that the weakness caused this incident.

## Economic interpretation

Current-rate arithmetic shows that ordinary Fast charging is compatible with much of the first-party-represented Event B US$ decline under a separate 25-credits-per-US-dollar historical-interface assumption. Event A's notices imply a materially different displayed-dollar conversion. Historical contract, provider currency, pricing and settlement remain decisive.

The clustering of 5,125, 5,048 and 5,004.18 credits is compatible with an approximately 5,000-credit reload target, but a purchase option and clustered magnitudes do not establish a fixed automatic target. That explanation remains a provider-configuration-dependent hypothesis.

## Settlement posture

HORTRAME opens at **US$356.62**: the two Event A components whose bank-account USD currency is owner-attested, plus the Event B decline contemporaneously represented as US dollars. This is a normative settlement position with a first-party USD basis, not proof of one provider-authoritative ledger currency, exact historical loss or final damages. HORTRAME will evaluate any proposed reduction against identified request-level evidence.

The provider must still identify the authoritative currency, terms, debits and settlement for each component. The first-party USD basis is not silently converted into provider-side accounting fact.

## Surviving proposition

The preserved record supports a specific billing and authorization dispute that client-side evidence cannot close. OpenAI's request-level account, tier-provenance, historical-price, currency, debit and settlement records are the discriminating evidence.
