#!/usr/bin/env python3
from __future__ import annotations

import csv
import datetime as dt
import importlib.util
import json
import pathlib
import sys


ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True


def load_module(path: pathlib.Path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


fixture = json.loads((ROOT / "03_CORRECTED_DERIVED_EVIDENCE/GUARDIAN_COUNTER_BOUNDARY_REGRESSION.json").read_text(encoding="utf-8"))
estimator = load_module(ROOT / "05_VERIFICATION/portable_raw_queries/estimate_guardian_transient_tokens.py")
audit = estimator.audit_rows(fixture["records"])
assert audit["status"] == "SUSPENDED_PENDING_TURN_AWARE_RECALIBRATION"
assert audit["current_estimate"] is None
for key, value in fixture["expected"].items():
    assert audit["demonstrated_counterexample"][key] == value

summary = (ROOT / "00_START_HERE/EXECUTIVE_CASE_SUMMARY.md").read_text(encoding="utf-8")
assert "one is represented in the six persisted segments and 20 are additional" in summary
assert "21 transient guardian submissions outside" not in summary

diagnostic = json.loads((ROOT / "03_CORRECTED_DERIVED_EVIDENCE/EVENT_B_GUARDIAN_TRANSIENT_INPUT_DIAGNOSTIC.json").read_text(encoding="utf-8"))
assert diagnostic["status"] == "SUSPENDED_PENDING_TURN_AWARE_RECALIBRATION"
assert diagnostic["current_estimate"] is None

balance = json.loads((ROOT / "03_CORRECTED_DERIVED_EVIDENCE/EVENT_B_BALANCE_WINDOW_CURRENT_RATE_SENSITIVITY.json").read_text(encoding="utf-8"))
assert balance["reported_balance_observation"] == {
    "amount": 29.12,
    "first_party_currency_representation": "USD",
    "first_party_notation": "US$",
    "provider_authoritative_currency": "UNDERDETERMINED",
    "source_class": "CONTEMPORANEOUS_FIRST_PARTY_REPORT",
}
assert "reported_balance_decline_usd" not in balance
assert balance["conditional_historical_conversion"]["conversion_currency"] == "USD"

with (ROOT / "02_CURRENT_ANALYSES/51_CURRENT_CLAIM_LEDGER_v1.6.6.csv").open(newline="", encoding="utf-8-sig") as stream:
    claims = {row["claim_id"]: row for row in csv.DictReader(stream)}
assert claims["CL166-09"]["status"] == "SUSPENDED_DEFECTIVE_ESTIMATOR"
for phrase in ["America/Toronto", "GPT-5.6 Sol", "GPT-6 Astra", "known-tier"]:
    assert phrase in claims["CL166-04"]["claim"]
assert claims["CL166-28"]["status"] == "HYPOTHESIS_REQUIRING_PROVIDER_CONFIGURATION"
assert claims["CL166-31"]["status"] == "NORMATIVE_SETTLEMENT_POSITION_WITH_FIRST_PARTY_USD_BASIS"
assert claims["CL166-32"]["status"] == "FIRST_PARTY_USD_SUPPORTED_PROVIDER_CURRENCY_UNDERDETERMINED"

cohort = json.loads((ROOT / "03_CORRECTED_DERIVED_EVIDENCE/PRIORITY_COHORT_RECOMPUTATION.json").read_text(encoding="utf-8"))
assert cohort["counts"]["priority_total"] == 1441
assert cohort["counts"]["known_tier_total"] == 1444

settings = ROOT / "07_SUBSTANTIVE_EVIDENCE/stage2safe/thread_settings_events.csv"
if settings.is_file():
    start = dt.datetime.fromisoformat("2026-09-02T04:00:00+00:00")
    end = dt.datetime.fromisoformat("2026-09-16T04:00:00+00:00")
    models = set(cohort["included_models"])
    counts = {"priority": 0, "default": 0, "missing": 0}
    with settings.open(newline="", encoding="utf-8-sig") as stream:
        for row in csv.DictReader(stream):
            stamp = dt.datetime.fromisoformat(row["timestamp"].replace("Z", "+00:00"))
            if not start <= stamp < end or row.get("model") not in models:
                continue
            tier = row.get("service_tier") or "missing"
            counts[tier] = counts.get(tier, 0) + 1
    assert counts == {"priority": 1441, "default": 3, "missing": 7}

for relative in [
    "00_START_HERE/EXECUTIVE_CASE_SUMMARY.md",
    "02_CURRENT_ANALYSES/50_UNIFIED_CREDIT_DEPLETION_CASE_THESIS_v0.9.md",
    "02_CURRENT_ANALYSES/52_PROVIDER_RECORD_REQUEST_v1.6.6.md",
]:
    text = (ROOT / relative).read_text(encoding="utf-8").lower()
    assert "genuine user-initiated" not in text
    assert "genuine user initiated" not in text

auth_summary = ROOT / "01_FROZEN_REFERENCES/PROVIDER_EMAIL_AUTHENTICATION_SUMMARY_20260917.md"
assert auth_summary.is_file()
assert "DKIM: pass" in auth_summary.read_text(encoding="utf-8")

component_path = ROOT / "02_CURRENT_ANALYSES/56_COMPONENT_ALLOCATION_TEMPLATE_v1.6.6.csv"
with component_path.open(newline="", encoding="utf-8-sig") as stream:
    components = list(csv.DictReader(stream))
assert len(components) == 3
for component in components:
    assert component["first_party_currency_representation"] == "USD"
    assert component["provider_authoritative_currency"] == "UNDERDETERMINED"
    assert (ROOT / component["evidence_reference"]).is_file()
    assert (ROOT / component["currency_evidence_reference"]).is_file()

with (ROOT / "07_EXTERNAL_REVIEW_MATERIALS/CLAIM_SOURCE_COVERAGE.csv").open(newline="", encoding="utf-8-sig") as stream:
    coverage = list(csv.DictReader(stream))
assert len(coverage) == 35
for row in coverage:
    paths = [item for item in row["source_paths"].split(";") if item]
    assert paths
    for relative in paths:
        assert not relative.startswith("08_HISTORICAL_SUPERSEDED/")
        assert (ROOT / relative).is_file(), (row["claim_id"], relative)

review = (ROOT / "04_REVIEW/ADVERSARIAL_REVIEW_RESPONSE_v1.6.6.md").read_text(encoding="utf-8")
assert "rechecked in a separate pass" in review
assert "independently checked" not in review

request = (ROOT / "02_CURRENT_ANALYSES/52_PROVIDER_RECORD_REQUEST_v1.6.6.md").read_text(encoding="utf-8")
assert "Stable opaque or pseudonymized identifiers" in request
assert "Aggregate assurance" in request

print("PASS: v1.6.6 anti-sycophancy and referential-integrity corrections")
