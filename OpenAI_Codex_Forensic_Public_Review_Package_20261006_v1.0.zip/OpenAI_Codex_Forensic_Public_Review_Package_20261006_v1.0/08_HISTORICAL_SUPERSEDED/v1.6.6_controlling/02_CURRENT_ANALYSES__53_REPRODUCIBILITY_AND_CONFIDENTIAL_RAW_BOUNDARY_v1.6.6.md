> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Reproducibility and confidential-raw boundary v1.6.6

## Reproducible from distributed evidence

- Package membership, bytes and hashes.
- Six persisted-segment arithmetic and event-specific row membership.
- Current claim-ledger, claim-source path bindings and component-allocation structure.
- Event A displayed-amount arithmetic and implied 31.0626 credits per displayed dollar symbol.
- US$356.62 opening-position arithmetic from separately typed first-party USD evidence.
- Every structured component evidence reference resolves to a current package path.
- Exact public-source URLs and current official documentation references.

## Inspectable but source-extraction dependent

- Sanitized submission, guardian, auth/catalog, retry, queue and thread-projection findings.
- Raw email authentication summary without full MIME.
- First-party attestations.

Portable scripts are included, but rerunning raw derivations requires controlled access to the confidential snapshot. A verifier PASS establishes package/included-evidence integrity and mechanical reference resolution. It does not establish semantic entailment, independence or final correctness of every conclusion.

## Provider-controlled

- Historical currency and contract terms.
- Account/funding assignment.
- Tier authorization provenance.
- Request-level debit and settlement.

Neither a directory title nor the existence of a coverage matrix establishes independent review.
