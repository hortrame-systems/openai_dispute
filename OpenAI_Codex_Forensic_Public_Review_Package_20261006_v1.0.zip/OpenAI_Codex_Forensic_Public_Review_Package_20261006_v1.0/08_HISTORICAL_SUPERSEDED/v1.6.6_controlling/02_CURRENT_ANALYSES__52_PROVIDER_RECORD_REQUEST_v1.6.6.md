> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Provider record request v1.6.6

## Transaction and currency confirmation

For invoices INVOICE_0003 and INVOICE_0004, provide the ISO currency code, transaction amount, settlement amount, payment-instrument currency, taxes/fees, exchange treatment, credit quantity, purchase price/discount and unused-credit state.

For Event B, provide the provider-authoritative currency and accounting unit corresponding to the owner's contemporaneous first-party `US$33.72`, `US$29.48` and `US$4.60` reports.

## Request-level reconciliation

For each debit proposed as valid, provide:

1. request, response, turn, client and root/thread IDs;
2. UTC submission, completion, retry and settlement timestamps;
3. account, workspace, auth-principal and funding-pool IDs;
4. submitting surface and visible selected task;
5. requested/resolved tier and tier-setting writer, prior value and authorization event;
6. model, reasoning and token fields;
7. historical rate card, purchase price, discount, multiplier and currency; and
8. debit, balance before/after, unused-credit state and later adjustment/refund.

## Privacy-preserving equivalence

Raw internal identifiers are not required where disclosure would expose sensitive systems or third-party data. Stable opaque or pseudonymized identifiers are acceptable if they preserve one-to-one and parent/child linkage across the requested rows. An attributable provider attestation is also acceptable for a field that cannot be disclosed if it states the field tested, method, result and responsible team and permits the parties to reconcile the same request, account/funding, tier-authorization and debit relationships.

Aggregate assurance, unverifiable redaction or an unlinked summary is not equivalent to row-level reconciliation.

## Fast/Priority authorization

The owner expressly denies ever knowingly authorizing Fast/Priority through a command, UI toggle, saved setting, workspace/admin setting, automation or any other method during Aug. 30–Sep. 15. Please identify any contrary authorization event rather than relying only on the transmitted tier field.

## Exact-runtime cache investigation

Reconcile the Event B `token_revoked` and catalog/ETag transition against provider/auth identity. Address the public `rust-v0.154.0-alpha.6.2` cache-eligibility TODO and identity-less file-cache entry, and state whether that code path affected these requests.

## Routing and guardian closure

Map older-root client IDs to authoritative submitting surfaces and visible task state. Provide completion, tier, tokens, deduplication and debit treatment for all 21 guardian submissions and the retry.

## Reconciliation posture

HORTRAME maintains the US$356.62 three-component opening settlement demand unless specific historical rows support a reduction. This is a first-party-supported settlement position, not independently established damages or an asserted legal or contractual burden rule.
