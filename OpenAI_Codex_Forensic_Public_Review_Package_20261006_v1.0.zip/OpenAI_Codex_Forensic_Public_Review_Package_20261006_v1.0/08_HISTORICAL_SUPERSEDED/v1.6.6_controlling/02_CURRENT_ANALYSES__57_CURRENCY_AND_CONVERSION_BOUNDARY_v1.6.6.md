> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Currency and credit-conversion boundary v1.6.6

## Event A

The provider-email summary records:

- `$164.99` for 5,125 credits; and
- `$162.51` for 5,048 credits.

Aggregate implied conversion:

`(5,125 + 5,048) / (164.99 + 162.51) = 31.062595... credits per displayed dollar symbol`

The owner separately states that the corresponding bank-account transactions are in USD. The bank statement is not embedded, and the provider-authoritative accounting currency remains underdetermined.

## Event B sensitivity

A different historical purchase-interface observation reported 5,000 credits for US$200, or 25 credits per US dollar. The Event B endpoints were themselves represented contemporaneously as `US$33.72` and `US$4.60`; their first-party represented decline is US$29.12. The 25-credits-per-US-dollar observation remains a separate cross-time conversion assumption.

The Event A implied conversion is approximately 24.25% higher than 25 credits per dollar. Account, plan, discount, region, currency, tax and historical terms may differ.

## Rule

Do not apply one observation's conversion to another event as historical fact. Do not turn first-party USD evidence into provider-authoritative currency. The arithmetic `164.99 + 162.51 + 29.12 = 356.62` supports the **US$356.62 normative opening settlement position** because each component has an explicit first-party USD basis. It does not establish one provider-ledger currency or final damages.

Official current OpenAI documentation says credit purchase prices and discounts depend on plan/agreement and actual charges must be confirmed against invoices and contractual terms.
