> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Correction disposition v1.6.6

## Closed from the v1.6.5 adversarial review

- Restored `PROVIDER_EMAIL_AUTHENTICATION_SUMMARY_20260917.md` and bound it through package manifest and hash inventories.
- Preserved two currency registers: first-party USD representation/attestation and provider-authoritative accounting currency.
- Reclassified the approximately 5,000-credit fixed-target explanation as a provider-configuration-dependent hypothesis.
- Replaced unsupported “independently checked” wording with “rechecked in a separate pass.”
- Added deterministic current-path checks for every component evidence reference and every claim-source binding.
- Kept semantic support as a review judgment; verifier PASS does not claim entailment or independence.
- Added privacy-preserving reconciliation through stable opaque IDs or attributable provider attestation while rejecting unlinked aggregate assurance.

## Earlier v1.6.5 corrections retained

- Guardian cohort overlap remains explicit: 21 total, one represented and 20 additional.
- The defective guardian token-range estimate remains suspended.
- The 1,441/1,444 Priority statistic retains its Toronto-day, model and known-tier denominator boundaries.
- Client submissions are not relabelled as proven user-initiated turns.
- Exact-runtime cache evidence remains bounded as a mechanism/provenance question, not incident causation.

## Strategy preserved

HORTRAME opens at US$356.62 on a first-party-supported settlement basis and requests request-level support for every proposed reduction. The package does not present that position as independently established damages or a binding legal/contractual burden rule.

## Remaining dependencies

Provider-authoritative currency, historical price, authorization provenance, funding identity, debit/settlement, fixed auto-reload configuration and final reimbursable amount remain provider-dependent.
