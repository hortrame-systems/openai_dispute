> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# OpenAI dispute package v1.6.6 — everything substantive

**Release date:** 2026-09-22  
**Status:** final local trusted-review package; not submitted

## Scope

This profile contains the complete current v1.6.6 case and deliberately restores broad safe telemetry, complaint/source inventory, historical HTML, exact historical scripts and superseded analytical history.

The current controlling materials are:

1. `REQUEST_TO_OPENAI.md`
2. `EXECUTIVE_CASE_SUMMARY.md`
3. `CLAIM_STATUS_AND_LIMITS.md`
4. `../02_CURRENT_ANALYSES/51_CURRENT_CLAIM_LEDGER_v1.6.6.csv`
5. `../02_CURRENT_ANALYSES/55_REBUTTABLE_LINE_ITEM_DEMAND_SCHEDULE_v1.6.6.md`
6. `../02_CURRENT_ANALYSES/57_CURRENCY_AND_CONVERSION_BOUNDARY_v1.6.6.md`

Everything under `08_HISTORICAL_SUPERSEDED` is non-controlling correction history.

v1.6.6 retains the v1.6.5 corrections and additionally restores the missing Event-A authentication reference, preserves first-party USD evidence separately from provider currency, demotes the fixed-target claim, narrows review-provenance wording, validates current references and permits privacy-preserving provider reconciliation.

## Settlement components

HORTRAME opens at **US$356.62** on separately typed first-party USD evidence. The package does not label that amount as one provider-ledger currency finding or independently established damages.

## Privacy

This package is for trusted review only. Broad telemetry is included because the owner requested the everything-substantive standard. Account-level host and project identifiers in the broad local thread catalog are pseudonymized, but extensive operational metadata remains.

## Verification

Run:

`python 05_VERIFICATION/verify_everything_substantive_v1.6.6.py`

A PASS establishes declared package, included-evidence and current-path checks, not semantic entailment or independent validation of every forensic conclusion.
