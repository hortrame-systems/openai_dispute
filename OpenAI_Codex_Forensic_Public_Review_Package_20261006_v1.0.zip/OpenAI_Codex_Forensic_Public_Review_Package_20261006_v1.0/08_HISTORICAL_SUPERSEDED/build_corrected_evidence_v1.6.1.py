#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import pathlib
import re
import sqlite3
import subprocess
import sys


PACKAGED_ANALYSIS = pathlib.Path(__file__).resolve().parent / "query_scripts"
ANALYSIS = PACKAGED_ANALYSIS if PACKAGED_ANALYSIS.is_dir() else pathlib.Path(r"<PRIVATE_PATH>")
RAW = pathlib.Path(r"<PRIVATE_PATH>")
SCRIPT_OUTPUTS = {
    "probe_event_b_execution_paths.py": "EVENT_B_EXECUTION_PATHS.json",
    "summarize_event_b_submissions.py": "EVENT_B_SUBMISSIONS.json",
    "quantify_hidden_guardian_work.py": "EVENT_B_GUARDIAN_SCOPE.json",
    "summarize_cache_states.py": "EVENT_B_AUTH_CATALOG_TIMELINE.json",
    "estimate_current_rate_card.py": "EVENT_B_CURRENT_RATE_SENSITIVITY.json",
    "reconcile_balance_window_current_rates.py": "EVENT_B_BALANCE_WINDOW_CURRENT_RATE_SENSITIVITY.json",
    "estimate_event_a_weighted_proxy.py": "EVENT_A_WEIGHTED_PROXY_SENSITIVITY.json",
    "estimate_guardian_transient_tokens.py": "EVENT_B_GUARDIAN_TRANSIENT_INPUT_DIAGNOSTIC.json",
}
SOURCE_FILES = {
    "logs_2.sqlite": RAW / "logs_2.sqlite",
    "state_5.sqlite": RAW / "state_5.sqlite",
    "queue_1.sqlite": RAW / "queue_1.sqlite",
    "models_cache.json": RAW / "models_cache.json",
}


def digest(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def run_json(script: pathlib.Path) -> str:
    completed = subprocess.run([sys.executable, str(script)], text=True, capture_output=True, check=False)
    if completed.returncode:
        raise SystemExit(f"{script.name} faile<PRIVATE_PATH>")
    parsed = json.loads(completed.stdout)
    return json.dumps(parsed, indent=2, sort_keys=True) + "\n"


def retry_summary() -> dict[str, object]:
    start = int(dt.datetime(2026, 9, 16, 0, 56, 11, tzinfo=dt.timezone.utc).timestamp())
    end = int(dt.datetime(2026, 9, 16, 1, 7, 48, tzinfo=dt.timezone.utc).timestamp())
    connection = sqlite3.connect(f"file:{(RAW / 'logs_2.sqlite').as_posix()}?mode=ro&immutable=1", uri=True)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only=ON")
    rows = connection.execute(
        "SELECT ts, ts_nanos, thread_id, feedback_log_body FROM logs WHERE ts BETWEEN ? AND ? "
        "AND target='codex_core::responses_retry' ORDER BY ts, ts_nanos",
        (start, end),
    ).fetchall()
    connection.close()
    events = []
    for row in rows:
        body = row["feedback_log_body"] or ""
        turn = re.search(r"turn_id=([0-9a-f-]+)", body)
        retry = re.search(r"retrying sampling request \((\d+)/(\d+) in (\d+)ms\)", body)
        events.append(
            {
                "timestamp_utc": dt.datetime.fromtimestamp(row["ts"], tz=dt.timezone.utc).replace(microsecond=row["ts_nanos"] // 1000).isoformat(),
                "thread_id": row["thread_id"],
                "turn_id": turn.group(1) if turn else None,
                "attempt": int(retry.group(1)) if retry else None,
                "max_retries": int(retry.group(2)) if retry else None,
                "delay_ms": int(retry.group(3)) if retry else None,
                "reason": "stream_disconnected_before_completion" if "stream disconnected before completion" in body else "other",
                "body_sha256": hashlib.sha256(body.encode("utf-8")).hexdigest(),
            }
        )
    return {
        "window_utc": ["2026-09-16T00:56:11Z", "2026-09-16T01:07:48Z"],
        "retry_events": events,
        "count": len(events),
        "boundary": "A retry establishes an additional sampling attempt, not a duplicate provider debit. Request/debit deduplication is provider-controlled.",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", required=True, type=pathlib.Path)
    args = parser.parse_args()
    output = args.output_dir.resolve()
    if output.exists() and any(output.iterdir()):
        raise SystemExit(f"refusing non-empty output directory: {output}")
    output.mkdir(parents=True, exist_ok=True)
    for script_name, output_name in SCRIPT_OUTPUTS.items():
        (output / output_name).write_text(run_json(ANALYSIS / script_name), encoding="utf-8", newline="\n")
    (output / "EVENT_B_RETRY_SUMMARY.json").write_text(
        json.dumps(retry_summary(), indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n"
    )
    binding = {
        "raw_snapshot_label": "snapshot_20260916-100353/raw_codex",
        "raw_rollout_inventory_digest": "34c6c9c3a0246ecaa6a96fea53a0f0f96216cd0dda3392894fbfb9d5e83bc263",
        "read_only_mode": True,
        "sources": {
            label: {"relative_path": path.relative_to(RAW).as_posix(), "bytes": path.stat().st_size, "sha256": digest(path)}
            for label, path in SOURCE_FILES.items()
        },
        "query_scripts": {
            script_name: {"sha256": digest(ANALYSIS / script_name)} for script_name in SCRIPT_OUTPUTS
        },
    }
    (output / "SOURCE_BINDING.json").write_text(
        json.dumps(binding, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n"
    )
    print(json.dumps({"output_dir": str(output), "files": len(list(output.iterdir()))}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
