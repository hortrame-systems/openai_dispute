> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Claim status and limits — v1.6.4

The controlling classification is `../02_CURRENT_ANALYSES/51_CURRENT_CLAIM_LEDGER_v1.6.4.csv`.

## Established

- Two provider-reported Event A reload transactions: `$164.99` and `$162.51`.
- Their added-credit quantities: 5,125 and 5,048 credits.
- Priority chronology and five acute transmitted Priority overrides.
- Six paired persisted-segment arithmetic.
- Twenty-one transient guardian submissions.
- Explicit inputs attached to the older root.
- Auth/catalog and thread-projection observations.
- Exact-runtime public cache-isolation weakness.

## First-party testimony

The owner states they absolutely never knowingly authorized Fast/Priority through a command, UI toggle, saved setting, workspace/admin setting, automation or other method during Aug. 30–Sep. 15. This is scoped testimony, not telemetry.

## Conditional calculations

- `$29.12` Event B decline from first-party balance reports.
- 651.3204-credit current-rate compatibility scenario.
- Conditional Fast-premium and common-currency totals.

## Settlement position

HORTRAME requests the full three displayed components and will evaluate any proposed reduction against request-level reconciliation. This is advocacy and negotiation posture, not an independently binding rule or proof of final damages.

## Not established

- Event A or Event B transaction/display currency.
- One common currency across all components.
- Final historical refund amount.
- Historical credit purchase price, discount, contract or conversion.
- The tier-setting writer or authorization event.
- Intended visible task for older-root inputs.
- Request-level funding identity, debit and settlement.
