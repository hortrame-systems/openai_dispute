#!/usr/bin/env python3
from __future__ import annotations

import csv
import datetime as dt
import json
import pathlib
import os


PACKAGE_ROOT = pathlib.Path(os.environ["OPENAI_DISPUTE_PACKAGE_ROOT"])
SAFE = pathlib.Path(os.environ["OPENAI_DISPUTE_SAFE_ROOT"])
INVENTORY = PACKAGE_ROOT / "02_CURRENT_ANALYSES/36_EVENT_B_LOCAL_TASK_SEGMENT_INVENTORY_2056_2108_v0.1.csv"
TOKENS = SAFE / "token_usage_events.csv"
STANDARD = {
    "gpt-6-astra": {"input": 250.0, "cached": 25.0, "output": 1250.0},
    "gpt-5.6-sol": {"input": 100.0, "cached": 10.0, "output": 500.0},
}
FAST_MULTIPLIER = 2.5
NOMINAL_HISTORICAL_CREDITS_PER_USD = 25.0


def stamp(value: str) -> dt.datetime:
    return dt.datetime.fromisoformat(value.replace("Z", "+00:00"))


WINDOWS = [
    ("pre_topup_proxy", stamp("2026-09-16T00:56:11.652Z"), stamp("2026-09-16T00:57:18Z")),
    ("topup_to_33_72_report", stamp("2026-09-16T00:57:18Z"), stamp("2026-09-16T01:00:18.979Z")),
    ("33_72_to_4_60_report", stamp("2026-09-16T01:00:18.979Z"), stamp("2026-09-16T01:07:29.072Z")),
    ("after_4_60_to_union_end", stamp("2026-09-16T01:07:29.072Z"), stamp("2026-09-16T01:07:47.632Z")),
]


with INVENTORY.open(newline="", encoding="utf-8-sig") as stream:
    segments = list(csv.DictReader(stream))
with TOKENS.open(newline="", encoding="utf-8-sig") as stream:
    all_tokens = list(csv.DictReader(stream))

events = []
for segment in segments:
    model = segment["effective_model"]
    rates = STANDARD.get(model)
    start, end = stamp(segment["start_utc"]), stamp(segment["end_utc"])
    rows = [
        row
        for row in all_tokens
        if row["source_file"] == segment["start_source_file"] and start <= stamp(row["timestamp"]) <= end
    ]
    rows.sort(key=lambda row: stamp(row["timestamp"]))
    previous = {"input": 0, "cached": 0, "output": 0}
    for row in rows:
        current = {
            "input": int(row["turn_input_tokens"]),
            "cached": int(row["turn_cached_input_tokens"]),
            "output": int(row["turn_output_tokens"]),
        }
        delta = {
            key: current[key] - previous[key] if current[key] >= previous[key] else current[key]
            for key in current
        }
        previous = current
        noncached = delta["input"] - delta["cached"]
        if rates:
            multiplier = FAST_MULTIPLIER if segment["effective_service_tier"] == "priority" else 1.0
            credits = (
                noncached / 1_000_000 * rates["input"] * multiplier
                + delta["cached"] / 1_000_000 * rates["cached"] * multiplier
                + delta["output"] / 1_000_000 * rates["output"] * multiplier
            )
        else:
            credits = None
        events.append(
            {
                "timestamp": stamp(row["timestamp"]),
                "segment": int(segment["segment_no"]),
                "model": model,
                "tokens": {**delta, "noncached": noncached},
                "current_rate_credits": credits,
            }
        )

window_results = []
for name, start, end in WINDOWS:
    included = [event for event in events if start < event["timestamp"] <= end]
    known = [event for event in included if event["current_rate_credits"] is not None]
    credits = sum(event["current_rate_credits"] for event in known)
    window_results.append(
        {
            "name": name,
            "start_utc_exclusive": start.isoformat(),
            "end_utc_inclusive": end.isoformat(),
            "known_model_usage_updates": len(known),
            "unpriced_updates": len(included) - len(known),
            "current_rate_credits": credits,
            "nominal_usd_at_25_credits_per_usd": credits / NOMINAL_HISTORICAL_CREDITS_PER_USD,
            "tokens": {
                key: sum(event["tokens"][key] for event in known)
                for key in ("input", "cached", "noncached", "output")
            },
        }
    )

print(
    json.dumps(
        {
            "windows": window_results,
            "reported_balance_decline_usd": 29.12,
            "reported_balance_decline_nominal_credits_at_25_per_usd": 29.12 * NOMINAL_HISTORICAL_CREDITS_PER_USD,
            "boundary": "Response-accounting timestamps are local client records, the $50 time is inferred from the user's 'three minutes ago' statement, balances are first-party reports, current rates are not the Sep. 15 historical ledger, and transient guardian requests are excluded. This is a sensitivity analysis, not charge reconstruction.",
        },
        indent=2,
        sort_keys=True,
    )
)
