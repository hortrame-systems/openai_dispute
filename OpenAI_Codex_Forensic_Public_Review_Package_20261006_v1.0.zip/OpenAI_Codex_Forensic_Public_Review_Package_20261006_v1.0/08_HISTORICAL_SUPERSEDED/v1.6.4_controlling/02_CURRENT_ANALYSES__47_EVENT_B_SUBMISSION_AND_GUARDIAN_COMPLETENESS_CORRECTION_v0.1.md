> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Event B submission and guardian-completeness correction v0.1

**Date:** 2026-09-20  
**Status:** CURRENT SUPPORTING  
**Corrects:** the v1.5.6 formulation of wholly unresolved older-root initiation and complete six-segment local workload

## Corrected submission finding

The two acute turns on older root `ID_0176` were preceded by explicit client submissions:

- 00:56:33.095 UTC — `Go`;
- 01:01:53.053 UTC — `Is anything running? Be brief and tell me what`.

The first active turn was also steered at 00:56:42.755 UTC with `We're on a very limited token budget`.

Each submission has a client ID in the local session-handler log. The two new-turn submissions carry `service_tier=priority` in the client request. Neither input matches the prompts of the two automations targeting the root; those automations were marked paused roughly ten hours earlier.

Therefore the corrected unresolved question is:

> Which visible, remote, queued or restored surface submitted these genuine inputs, and why did that surface target the older logical root?

The local record establishes client submissions. It does not identify the visible composer, device or intended task.

## Corrected workload boundary

The six paired persisted task segments remain exactly reproducible:

- 56 response-accounting updates;
- 50 post-initial continuations;
- 26,386,511 post-initial input tokens;
- 26,350,976 cached post-initial input tokens; and
- 29,225,371 input tokens when summing six task-final cumulative counters.

However, the same union window also contains 21 transient `codex-auto-review`/guardian submissions across three review threads:

- ten associated with the ROOT_B;
- ten associated with the ROOT_C; and
- one associated with the older root.

Only the older-root guardian call appears as a paired persisted segment in the six-segment table. One Astra-associated guardian request disconnected before completion and was retried once.

The correct description is therefore:

> complete accounting for six paired persisted task segments, not complete local or provider request accounting.

## Diagnostic guardian bound

A calibration using 764 uniquely timestamped persisted guardian records estimates approximately 0.235–0.724 million transient guardian input tokens for the 21 calls, with a median-ratio estimate of 0.475 million. This is a diagnostic estimate derived from serialized Rust log size, not measured usage. Cache treatment, output tokens, model rate and purchased-credit debit remain unknown.

The estimate suggests guardian traffic is an important completeness correction but is unlikely to dominate the roughly 29.225 million persisted-segment input total.

## Evidence

- `03_CORRECTED_DERIVED_EVIDENCE/EVENT_B_SUBMISSIONS.json`
- `03_CORRECTED_DERIVED_EVIDENCE/EVENT_B_GUARDIAN_SCOPE.json`
- `03_CORRECTED_DERIVED_EVIDENCE/EVENT_B_GUARDIAN_TRANSIENT_INPUT_DIAGNOSTIC.json`
- `03_CORRECTED_DERIVED_EVIDENCE/EVENT_B_RETRY_SUMMARY.json`

## Provider closure

OpenAI must map each submission and guardian request to its surface, account/workspace/auth identity, effective tier, request IDs, tokens and purchased-credit debit. Local thread metadata cannot supply those mappings.
