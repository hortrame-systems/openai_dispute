> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Event B current-rate compatibility sensitivity v0.3

**Status:** diagnostic compatibility test; not a historical charge or currency reconstruction

Current official OpenAI documentation lists the present credit rates and Fast multipliers used in this sensitivity. It also says credit purchase prices depend on plan/agreement and actual charges must be confirmed against invoices and contractual terms.

Current sources:

- http<PRIVATE_PATH>
- http<PRIVATE_PATH>
- http<PRIVATE_PATH>

Known-model response-accounting increments from the `$33.72` submission to the `$4.60` submission correspond under current rates to 651.3204 credits.

A separate historical interface observation reported 5,000 credits for US$200, or 25 credits per US dollar. Under that separate conversion only, 651.3204 credits are nominally US$26.0528 and the displayed 29.12 decline is nominally 728 credits, yielding 89.47% compatibility.

The Event A notices instead imply approximately 31.0626 credits per displayed dollar symbol in aggregate. The package does not treat those conversion observations as interchangeable.

Nine guardian submissions occurred in the interval. Their debit is unknown.

The result establishes magnitude compatibility under stated assumptions. It does not establish transaction currency, historical pricing, authorization, account attribution, probability or final refund.
