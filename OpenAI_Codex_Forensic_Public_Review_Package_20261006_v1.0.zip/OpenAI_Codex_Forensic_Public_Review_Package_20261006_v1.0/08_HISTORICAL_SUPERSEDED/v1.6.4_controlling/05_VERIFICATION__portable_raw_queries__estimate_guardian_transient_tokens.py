#!/usr/bin/env python3
from __future__ import annotations

import csv
import datetime as dt
import json
import pathlib
import os
import sqlite3
import statistics


RAW = pathlib.Path(os.environ["OPENAI_DISPUTE_RAW_ROOT"])
SAFE = pathlib.Path(os.environ["OPENAI_DISPUTE_SAFE_ROOT"])
UNION_START = dt.datetime(2026, 9, 16, 0, 56, 11, 652000, tzinfo=dt.timezone.utc)
UNION_END = dt.datetime(2026, 9, 16, 1, 7, 47, 632000, tzinfo=dt.timezone.utc)


def ro(path: pathlib.Path) -> sqlite3.Connection:
    connection = sqlite3.connect(f"file:{path.as_posix()}?mode=ro&immutable=1", uri=True)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only=ON")
    return connection


def parse_iso(value: str) -> dt.datetime:
    return dt.datetime.fromisoformat(value.replace("Z", "+00:00"))


def percentile(values: list[float], fraction: float) -> float:
    ordered = sorted(values)
    if not ordered:
        return 0.0
    position = (len(ordered) - 1) * fraction
    lower = int(position)
    upper = min(lower + 1, len(ordered) - 1)
    weight = position - lower
    return ordered[lower] * (1 - weight) + ordered[upper] * weight


state = ro(RAW / "state_5.sqlite")
guardian_ids = {row[0] for row in state.execute("SELECT id FROM threads WHERE model='codex-auto-review'")}
state.close()

logs = ro(RAW / "logs_2.sqlite")
submissions: dict[str, list[dict[str, object]]] = {}
for row in logs.execute(
    "SELECT ts, ts_nanos, thread_id, feedback_log_body FROM logs WHERE module_path='codex_core::session::handlers' "
    "AND feedback_log_body LIKE '%Submission sub=Submission%' AND feedback_log_body LIKE '%op: TurnInput%' ORDER BY ts, ts_nanos"
):
    if row["thread_id"] not in guardian_ids:
        continue
    stamp = dt.datetime.fromtimestamp(row["ts"], tz=dt.timezone.utc).replace(microsecond=row["ts_nanos"] // 1000)
    body = row["feedback_log_body"] or ""
    submissions.setdefault(row["thread_id"], []).append({"timestamp": stamp, "body_bytes": len(body.encode("utf-8"))})
logs.close()

with (SAFE / "token_usage_events.csv").open(newline="", encoding="utf-8-sig") as stream:
    token_rows = [row for row in csv.DictReader(stream) if row["thread_id"] in guardian_ids]

timestamp_groups: dict[tuple[str, str], list[dict[str, str]]] = {}
for row in token_rows:
    timestamp_groups.setdefault((row["thread_id"], row["timestamp"]), []).append(row)

pairs = []
for (thread_id, timestamp), rows in timestamp_groups.items():
    if len(rows) != 1:
        continue
    token_time = parse_iso(timestamp)
    candidates = []
    for submission in submissions.get(thread_id, []):
        delta = (token_time - submission["timestamp"]).total_seconds()
        if 0 <= delta <= 30:
            candidates.append((delta, submission))
    if not candidates:
        continue
    _, submission = min(candidates, key=lambda item: item[0])
    row = rows[0]
    body_bytes = int(submission["body_bytes"])
    input_tokens = int(row["turn_input_tokens"])
    cached_tokens = int(row["turn_cached_input_tokens"])
    pairs.append(
        {
            "thread_id": thread_id,
            "token_timestamp": timestamp,
            "body_bytes": body_bytes,
            "input_tokens": input_tokens,
            "cached_tokens": cached_tokens,
            "input_tokens_per_body_byte": input_tokens / body_bytes,
            "cached_share": cached_tokens / input_tokens if input_tokens else 0.0,
        }
    )

pairs.sort(key=lambda pair: (pair["thread_id"], pair["token_timestamp"]))
previous_by_thread: dict[str, tuple[int, int]] = {}
for pair in pairs:
    previous_input, previous_cached = previous_by_thread.get(pair["thread_id"], (0, 0))
    current_input = int(pair["input_tokens"])
    current_cached = int(pair["cached_tokens"])
    delta_input = current_input - previous_input if current_input >= previous_input else current_input
    delta_cached = current_cached - previous_cached if current_cached >= previous_cached else current_cached
    pair["incremental_input_tokens"] = delta_input
    pair["incremental_cached_tokens"] = delta_cached
    pair["incremental_tokens_per_body_byte"] = delta_input / int(pair["body_bytes"])
    pair["incremental_cached_share"] = delta_cached / delta_input if delta_input else 0.0
    previous_by_thread[pair["thread_id"]] = (current_input, current_cached)

ratios = [pair["incremental_tokens_per_body_byte"] for pair in pairs if pair["incremental_input_tokens"] > 0]

event_submissions = []
for thread_id, rows in submissions.items():
    for submission in rows:
        if UNION_START <= submission["timestamp"] <= UNION_END:
            event_submissions.append({"thread_id": thread_id, **submission})
event_bytes = sum(int(row["body_bytes"]) for row in event_submissions)
diagnostic_windows = [
    ("topup_to_33_72_report", dt.datetime(2026, 9, 16, 0, 57, 18, tzinfo=dt.timezone.utc), dt.datetime(2026, 9, 16, 1, 0, 18, 979000, tzinfo=dt.timezone.utc)),
    ("33_72_to_4_60_report", dt.datetime(2026, 9, 16, 1, 0, 18, 979000, tzinfo=dt.timezone.utc), dt.datetime(2026, 9, 16, 1, 7, 29, 72000, tzinfo=dt.timezone.utc)),
]
window_estimates = []
for name, start, end in diagnostic_windows:
    selected = [row for row in event_submissions if start < row["timestamp"] <= end]
    selected_bytes = sum(int(row["body_bytes"]) for row in selected)
    window_estimates.append(
        {
            "name": name,
            "submissions": len(selected),
            "serialized_log_bytes": selected_bytes,
            "estimated_input_tokens_median_ratio": selected_bytes * statistics.median(ratios) if ratios else None,
            "estimated_input_tokens_p10_ratio": selected_bytes * percentile(ratios, 0.10),
            "estimated_input_tokens_p90_ratio": selected_bytes * percentile(ratios, 0.90),
        }
    )

summary = {
    "calibration_pairs": len(pairs),
    "incremental_input_tokens_per_serialized_log_byte": {
        "p10": percentile(ratios, 0.10),
        "median": statistics.median(ratios) if ratios else None,
        "p90": percentile(ratios, 0.90),
    },
    "event_transient_guardian_submissions": len(event_submissions),
    "event_serialized_log_bytes": event_bytes,
    "window_estimates": window_estimates,
    "estimated_input_tokens": {
        "p10_ratio": event_bytes * percentile(ratios, 0.10),
        "median_ratio": event_bytes * statistics.median(ratios) if ratios else None,
        "p90_ratio": event_bytes * percentile(ratios, 0.90),
    },
    "boundary": "This is a diagnostic estimate calibrated on uniquely timestamped persisted guardian rows. Serialized Rust debug-log bytes are not a tokenizer input, and cache/debit treatment of transient requests remains provider-controlled. Do not promote these estimates as measured usage.",
    "calibration_incremental_input_tokens": sum(pair["incremental_input_tokens"] for pair in pairs),
}
print(json.dumps(summary, indent=2, sort_keys=True, default=str))
