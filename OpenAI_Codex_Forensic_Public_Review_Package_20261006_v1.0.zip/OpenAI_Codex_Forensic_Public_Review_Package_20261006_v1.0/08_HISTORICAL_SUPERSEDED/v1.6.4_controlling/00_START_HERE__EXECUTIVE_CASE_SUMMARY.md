> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Executive case summary — v1.6.4

## Opening settlement demand

HORTRAME requests full reimbursement or account credit for three components:

| Component | Provider/displayed amount | Currency status |
| --- | ---: | --- |
| Event A invoice INVOICE_0003 | `$164.99` | UNDERDETERMINED |
| Event A invoice INVOICE_0004 | `$162.51` | UNDERDETERMINED |
| Event B reported balance decline | `$29.12` | UNDERDETERMINED; first-party report |

If OpenAI confirms that all three amounts share one currency, their arithmetic total is **356.62 in that confirmed currency**. The package does not presently label that total `US$356.62` or combine different currencies as fact.

HORTRAME maintains the full three-component opening demand unless OpenAI supplies request-level evidence supporting a specific reduction. That is a settlement position, not a claim that a unilateral burden rule binds OpenAI.

## Event A

Two authenticated OpenAI reload notices establish the transactions and credit quantities. They do not establish the transaction currency, valid consumption, request-to-debit sequence, unused-credit state or final improper loss.

The two reload notices imply approximately 31.0626 credits per displayed dollar symbol in aggregate. Event B's compatibility test uses a separate historical observation of 25 credits per US dollar. The package does not merge those conversions.

## Event B

The local record establishes:

- six paired persisted segments with 29,225,371 final cumulative input tokens;
- 21 transient guardian submissions outside that six-segment accounting;
- explicit client inputs attached to the older root, with visible/intended surface unresolved;
- five acute new-turn requests carrying `service_tier=priority`;
- a `token_revoked` failure followed by a seven-to-eight-model catalog and ETag transition;
- inconsistent thread projections; and
- current first-party testimony that Fast/Priority was never knowingly authorized.

The exact `rust-v0.154.0-alpha.6.2` public source also contains a provider-isolation TODO in model-cache eligibility and a cache entry without provider/auth identity. This strengthens the provenance investigation but does not prove the defect caused Event B.

## Economic compatibility

Under current rates and a separate 25-credits-per-US-dollar historical observation, known-model usage is compatible with much of the reported Event B decline. This is a sensitivity, not a historical charge, transaction-currency or probability finding.

## Requested resolution

OpenAI should reconcile every proposed reduction through request identity, account/funding identity, intended target, tier authorization, usage, historical price/currency, settlement and guardian/retry treatment. Aggregate assurance or the transmitted Priority field alone does not resolve the dispute.
