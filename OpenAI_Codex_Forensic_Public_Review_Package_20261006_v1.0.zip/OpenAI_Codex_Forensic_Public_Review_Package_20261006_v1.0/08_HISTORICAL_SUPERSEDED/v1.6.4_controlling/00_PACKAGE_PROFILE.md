> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Package profile — everything substantive, trusted-review edition

This package contains the full current v1.6.4 case plus broad safe telemetry, complaint/source inventory, historical integrated report, exact historical scripts, portable scripts and superseded analytical history.

It intentionally restores material excluded from the external-review package. Current files under `00_START_HERE`, `02_CURRENT_ANALYSES` and `04_REVIEW` control; historical files do not.

Stable ChatGPT host/user and project identifiers in the broad local thread catalog are replaced with deterministic package-local pseudonyms. Extensive task/thread IDs, timing, model, reasoning and tool-use metadata remain. Give this package only to a trusted reviewer.

Run `05_VERIFICATION/verify_everything_substantive_v1.6.4.py`.

The confidential raw snapshot and Tier Guard remain separately preserved.
