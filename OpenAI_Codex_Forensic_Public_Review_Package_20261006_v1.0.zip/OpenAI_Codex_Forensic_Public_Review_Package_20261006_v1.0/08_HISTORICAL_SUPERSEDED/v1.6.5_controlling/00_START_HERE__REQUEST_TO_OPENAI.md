> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Request to OpenAI — v1.6.5

## Requested settlement

We request full reimbursement or account credit for:

- Event A invoice INVOICE_0003: `$164.99` in its confirmed transaction currency;
- Event A invoice INVOICE_0004: `$162.51` in its confirmed transaction currency; and
- Event B reported balance decline: `$29.12` in the balance display's confirmed currency.

If all three share one currency, the arithmetic total is 356.62 in that currency. Please confirm the currency before applying a combined total.

We maintain the full componentized opening demand unless specific request-level evidence supports a reduction. This is our settlement position; it does not purport to impose an independent legal or contractual burden rule.

## Minimum dispositive ledger

For each proposed reduction, identify:

1. request, response, turn, client and root/thread IDs;
2. UTC submission, completion, retry and settlement timestamps;
3. account, workspace, auth-principal and funding-pool IDs;
4. submitting surface and visible selected task;
5. requested/resolved tier and the writer, prior value and authorization event;
6. model, reasoning and exact token fields;
7. historical rate card, purchase price, discount, multiplier and currency; and
8. debit, balance before/after, unused-credit state and later adjustment/refund.

## Current authorization testimony

The owner states they never knowingly enabled or authorized Fast/Priority by command, UI, saved setting, workspace/admin setting, automation or any other method during the affected period. A client request containing `service_tier=priority` establishes transmitted state, not informed authorization.

## Exact-runtime mechanism question

The public source for `rust-v0.154.0-alpha.6.2` explicitly notes that provider identity still needed to be added to model-cache eligibility to prevent another provider's fresh cache from being reused. Please reconcile the Event B token revocation and catalog/ETag transition against account/auth identity and cache eligibility.

## Response standard

A global statement that usage was valid does not resolve the identified components. Please cite the specific historical rows supporting each proposed reduction so the parties can reconcile the remaining dispute precisely.
