> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Reproducibility and confidential-raw boundary v1.6.5

## Reproducible from distributed evidence

- Package membership, bytes and hashes.
- Six persisted-segment arithmetic and event-specific row membership.
- Current claim-ledger and component-allocation structure.
- Event A displayed-amount arithmetic and implied 31.0626 credits per displayed dollar symbol.
- Conditional 356.62 total only when one common currency is confirmed.
- Exact public-source URLs and current official documentation references.

## Inspectable but source-extraction dependent

- Sanitized submission, guardian, auth/catalog, retry, queue and thread-projection findings.
- Raw email authentication summary without full MIME.
- First-party attestations.

Portable scripts are included, but rerunning raw derivations requires controlled access to the confidential snapshot. A verifier PASS is package/included-evidence integrity, not independent validation of every conclusion.

## Provider-controlled

- Historical currency and contract terms.
- Account/funding assignment.
- Tier authorization provenance.
- Request-level debit and settlement.

Neither a directory title nor the existence of a coverage matrix establishes independent review.
