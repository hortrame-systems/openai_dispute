> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Adversarial review response v1.6.5

## Disposition

The 2026-09-21 v1.6.4 review was independently checked under the anti-sycophancy protocol. Its guardian counter-boundary defect, guardian-cohort overlap, machine-readable currency overtyping and Priority-denominator omission reproduce. The six persisted-segment totals and 651.3204-credit sensitivity survive within their stated boundaries.

The review itself is corrected where it calls the older-root inputs “genuine user-initiated turns.” The evidence establishes genuine client submissions; visible composer, device, intended task and authorization remain unresolved. Neither claimant-favorable nor provider-favorable wording controls evidence classification.

## Strategic adaptation

The correction does not abandon the owner's requested stance. HORTRAME still demands every affected displayed component and does not volunteer a reduction based on its own sensitivities. The language now accurately describes that position as settlement advocacy maintained pending specific reconciliation, rather than an objectively binding burden rule.

## Accepted favorable findings

- Archive integrity survives.
- Request-level reconciliation remains warranted.
- Exact-runtime cache evidence is stronger than generic mechanism plausibility.
- The six-segment and 651.3204-credit calculations remain reproducible within scope.
- Versioning and correction discipline remain strong.

## Consequential corrections

- CL165-09 suspends the v1.6.4 guardian token range and dependent dominance inference.
- The executive summary states 21 guardian submissions total, one represented and 20 additional.
- Currency observations and USD assumptions use separate machine fields.
- CL165-04 names the exact Toronto-day, model and known-tier cohort.
- Regression tests bind each correction, including the review's user-initiation overclaim.

## Boundaries

- No proof of final historical damages.
- No proof that the cache weakness caused the incident.
- No independent reviewer disposition merely from a directory or matrix.
- No cross-currency sum until currency is confirmed.
