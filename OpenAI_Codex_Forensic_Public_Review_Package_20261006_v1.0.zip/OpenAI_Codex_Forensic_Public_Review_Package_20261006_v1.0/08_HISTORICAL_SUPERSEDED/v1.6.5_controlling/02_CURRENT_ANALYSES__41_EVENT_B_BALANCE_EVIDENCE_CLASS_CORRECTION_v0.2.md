> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Event B balance evidence-class and currency correction v0.2

The values `$33.72`, `$29.48` and `$4.60` are preserved in contemporaneous user-authored messages. They are first-party observations, not provider ledger entries.

Relevant timestamps:

- 01:00:18.979 UTC — `$33.72` reported remaining;
- 01:01:16.727 UTC — `$29.48` reported remaining; and
- 01:07:30.134 UTC — `$4.60` reported remaining.

Conditional arithmetic:

- displayed decline: **29.12**;
- elapsed persisted-message interval: **431.155 seconds**; and
- displayed symbol: `$`; authoritative currency code absent.

Correct classification:

**CONTEMPORANEOUS FIRST-PARTY BALANCE REPORT — CURRENCY UNDERDETERMINED**

Do not promote the endpoints into provider ledger rows, authoritative currency, historical rate or proof of a particular request-level debit.
