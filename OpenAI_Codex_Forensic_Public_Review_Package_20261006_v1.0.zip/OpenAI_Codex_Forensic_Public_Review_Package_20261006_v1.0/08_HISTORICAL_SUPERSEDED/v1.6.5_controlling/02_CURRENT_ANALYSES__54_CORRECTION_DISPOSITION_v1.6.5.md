> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Correction disposition v1.6.5

## Closed from the 2026-09-21 adversarial review

- Currency is UNDERDETERMINED rather than silently typed as USD.
- No common-currency sum controls until OpenAI confirms one currency.
- Negotiation posture no longer masquerades as independent authority.
- Current scoped Fast/Priority non-authorization testimony is included.
- Exact `rust-v0.154.0-alpha.6.2` cache evidence is promoted with causal limits.
- Package-profile README and verifier instructions are distinct.
- External-review materials no longer imply completed independent validation.
- Broad stable ChatGPT host/project identifiers are pseudonymized in the trusted-review package.
- Current OpenAI pricing/credit guidance is bound as current only.
- Guardian cohort overlap is explicit: 21 total, one represented and 20 additional.
- The defective guardian token-range estimate and dependent “unlikely to dominate” conclusion are suspended.
- Machine-readable balance output preserves the observed amount/symbol separately from assumed USD conversion.
- The 1,441/1,444 statistic declares Toronto-day boundaries, Sol/Astra allowlist, known-tier denominator and missing-tier exclusions.
- Client submissions are not relabelled as proven user-initiated turns.

## Strategy preserved

HORTRAME still opens with every affected displayed component at face value and requests request-level support for any reduction. The correction changes typing and authority claims, not the settlement objective.

## Remaining dependencies

Transaction currency, historical price, authorization provenance, funding identity, debit/settlement and final reimbursable amount remain provider-dependent.
