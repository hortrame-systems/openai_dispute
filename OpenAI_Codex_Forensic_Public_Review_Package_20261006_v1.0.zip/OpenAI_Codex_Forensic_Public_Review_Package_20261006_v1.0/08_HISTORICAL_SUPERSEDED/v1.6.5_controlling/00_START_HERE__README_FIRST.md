> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# OpenAI dispute package v1.6.5 — everything substantive

**Release date:** 2026-09-21  
**Status:** final local trusted-review package; not submitted

## Scope

This profile contains the complete current v1.6.5 case and deliberately restores broad safe telemetry, complaint/source inventory, historical HTML, exact historical scripts and superseded analytical history.

The current controlling materials are:

1. `REQUEST_TO_OPENAI.md`
2. `EXECUTIVE_CASE_SUMMARY.md`
3. `CLAIM_STATUS_AND_LIMITS.md`
4. `../02_CURRENT_ANALYSES/51_CURRENT_CLAIM_LEDGER_v1.6.5.csv`
5. `../02_CURRENT_ANALYSES/55_REBUTTABLE_LINE_ITEM_DEMAND_SCHEDULE_v1.6.5.md`
6. `../02_CURRENT_ANALYSES/57_CURRENCY_AND_CONVERSION_BOUNDARY_v1.6.5.md`

Everything under `08_HISTORICAL_SUPERSEDED` is non-controlling correction history.

v1.6.5 withdraws the defective v1.6.4 guardian token range, corrects the guardian cohort overlap, separates observed currency from assumed USD conversion, declares the exact Priority-statistic denominator and avoids inferring user initiation from client submissions.

## Settlement components

HORTRAME maintains claims for `$164.99`, `$162.51` and `$29.12` in their authoritative currencies once confirmed. The conditional same-currency total is 356.62. No current file labels the combined amount `US$356.62` as established fact.

## Privacy

This package is for trusted review only. Broad telemetry is included because the owner requested the everything-substantive standard. Account-level host and project identifiers in the broad local thread catalog are pseudonymized, but extensive operational metadata remains.

## Verification

Run:

`python 05_VERIFICATION/verify_everything_substantive_v1.6.5.py`

A PASS establishes declared package and included-evidence checks, not independent validation of every forensic conclusion.
