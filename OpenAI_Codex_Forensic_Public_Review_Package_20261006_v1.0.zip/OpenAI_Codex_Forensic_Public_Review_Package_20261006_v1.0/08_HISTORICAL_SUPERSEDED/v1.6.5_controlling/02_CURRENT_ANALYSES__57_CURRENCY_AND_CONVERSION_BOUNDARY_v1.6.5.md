> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Currency and credit-conversion boundary v1.6.5

## Event A

The provider-email summary records:

- `$164.99` for 5,125 credits; and
- `$162.51` for 5,048 credits.

Aggregate implied conversion:

`(5,125 + 5,048) / (164.99 + 162.51) = 31.062595... credits per displayed dollar symbol`

The summary does not establish the ISO currency code.

## Event B sensitivity

A different historical purchase-interface observation reported 5,000 credits for US$200, or 25 credits per US dollar. That observation underlies the Event B current-rate sensitivity only.

The Event A implied conversion is approximately 24.25% higher than 25 credits per dollar. Account, plan, discount, region, currency, tax and historical terms may differ.

## Rule

Do not apply one observation's conversion to another event as historical fact. Do not sum displayed `$` amounts across events until OpenAI confirms their currency. If one common currency is confirmed, 164.99 + 162.51 + 29.12 = 356.62 in that currency.

Official current OpenAI documentation says credit purchase prices and discounts depend on plan/agreement and actual charges must be confirmed against invoices and contractual terms.
