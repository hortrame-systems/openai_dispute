> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Financial scenario matrix — OpenAI dispute

**Date:** 2026-09-20  
**Status:** decision support; not a provider ledger, refund determination or legal opinion

## Bottom line

- **Refund proven today:** US$0.00.
- **Sep. 15 amount directly at issue in the exact endpoint interval:** US$29.12.
- **Known usage explained under current-rate sensitivity:** US$26.05 / 89.47%.
- **Residual before guardian pricing:** US$3.07.
- **Potential unauthorized-Fast premium for that known usage:** approximately US$15.63, if Standard—not Fast—should have applied and the current 2.5× relationship is used.
- **Event A cash exposure requiring provider reconciliation:** US$327.50 across the two reported reload transactions.
- **Combined narrow reconciliation scope:** US$356.62 (Event A transactions plus the Sep. 15 US$29.12 interval). This is an audit scope, not a refund claim.

## Scenario table

| Scenario | Amount | Status | Meaning |
| --- | ---: | --- | --- |
| Refund already proven | **US$0.00** | NOT ESTABLISHED | No provider debit ledger currently proves an incorrect or unauthorized dollar amount. |
| Sep. 15 reported endpoint decline | **US$29.12** | ESTABLISHED AS FIRST-PARTY REPORT | US$33.72→US$4.60; not a provider ledger entry. |
| Nominal credits represented by US$29.12 | **728 credits** | DETERMINISTIC CONDITIONAL | Uses historical purchase UI conversion of 25 credits/US$. |
| Known persisted usage in that interval at current rates | **651.3204 credits / US$26.05** | CURRENT-RATE COUNTERFACTUAL | Explains 89.47% of the reported decline before guardian pricing. Not a historical charge reconstruction. |
| Residual after known persisted usage | **76.6796 credits / US$3.07** | UNRESOLVED RESIDUAL | Compatible with guardian calls, historical-rate differences, funding-pool allocation or display/settlement timing; not evidence of overbilling. |
| Standard-mode equivalent of known usage | **260.5282 credits / US$10.42** | CONDITIONAL | Divides the current Fast cost by 2.5. Applies only if the work should have been Standard. |
| Fast premium on known usage | **390.7922 credits / US$15.63** | CONDITIONAL DAMAGES SCENARIO | The extra 60% of a 2.5× Fast charge. Best bounded Sep. 15 premium scenario if Fast was unauthorized. |
| Full Sep. 15 interval refund | **US$29.12** | UNSUPPORTED / DISMISSED AS PRESENT CLAIM | Ordinary charging plausibly explains nearly all of it; request only if provider records show the work/account/tier was unauthorized. |
| Second older-root task inside endpoint interval | **US$1.26** | CURRENT-RATE COUNTERFACTUAL | Maximum known-model amount directly associated with the second older-root persisted task in that interval. Misrouting still unproven. |
| Both older-root persisted tasks across the full acute window | **US$9.39** | CURRENT-RATE COUNTERFACTUAL | Potential routing-attribution exposure if both targets were unintended; explicit user inputs weaken a full unauthorized-use claim. |
| Nine transient guardian calls in endpoint interval | **approximately US$0.04–US$3.07 input-only sensitivity** | HIGHLY CONDITIONAL | Uses diagnostic token range and Sol Standard-cached to Sol Fast-noncached extremes. Internal model rate, cache share and output are unknown. |
| Event A two reported reload transactions | **US$327.50** | ESTABLISHED CASH-EXPOSURE CHRONOLOGY | US$164.99 + US$162.51. The request→debit sequence and valid consumption remain unknown. |
| Full Event A refund | **US$327.50** | UNSUPPORTED / DISMISSED AS PRESENT CLAIM | No token denominator or provider ledger establishes that both reloads were erroneous. |
| Event A Standard-equivalent scenario | **US$131.00** | MATHEMATICAL SCENARIO ONLY | Forty percent of US$327.50 if every relevant charge were Fast under a 2.5× relationship. Historical applicability is unproven. |
| Event A Fast-premium ceiling | **US$196.50** | HIGHLY SPECULATIVE CEILING | Sixty percent of US$327.50 if all consumption was valid except an unauthorized 2.5× Fast tier. Do not demand this amount without the historical ledger. |
| Narrow combined reconciliation scope | **US$356.62** | AUDIT SCOPE, NOT REFUND | US$327.50 Event A transactions + US$29.12 Event B endpoint decline. |
| Sep. 19 provider/card currency pair | **US$229.95 vs CAD$330.38** | PENDING SOURCE EVIDENCE | Ratio 1.4367 CAD/US$. Foreign exchange could explain the full difference, making recoverable error US$0; screenshot bytes and settlement details are absent. |
| Treating 229.95 and 330.38 as the same currency | **100.43 difference** | DISMISSED | The records describe different currency contexts; subtracting them directly is not valid evidence of overcharge. |

## What is financially strongest

The strongest defensible monetary theory is **not** “refund everything.” It is:

> If OpenAI confirms that Priority/Fast was not authorized, refund the Fast premium request by request. If OpenAI confirms that requests were routed to the wrong task/account/funding pool, refund those specific debits in full. Otherwise, the Sep. 15 amount appears broadly consistent with ordinary token charging.

For the exact Sep. 15 endpoint interval, the current-rate Fast-premium scenario is approximately **US$15.63**. That is a scenario ceiling for the known persisted usage, not a presently established entitlement.

Event A has the larger cash exposure, but no defensible refund figure until OpenAI supplies historical tokens, tier, account, rate, reload and settlement records.

## Official current references

- OpenAI ChatGPT/Codex pricing: http<PRIVATE_PATH>
- OpenAI Fast-mode credit multiplier: http<PRIVATE_PATH>

Current official rules are used only for sensitivity analysis. They do not establish the Sep. 15 or Aug. 31 historical contract/rate card.
