> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Rebuttable line-item demand schedule — OpenAI dispute

**Date:** 2026-09-20  
**Status:** negotiation and reconciliation draft; applies a rebuttable presumption that the full amount is due, without treating the presumption itself as historical proof

## Opening position

Request **US$356.62 in reimbursement or account credit, presumed due**, subject only to request-level reductions proven by OpenAI:

| Disputed exposure | Opening amount | Present evidence class |
| --- | ---: | --- |
| Event A auto-reload invoice INVOICE_0003 | **US$164.99** | Authenticated provider email summary; underlying request/debit sequence absent |
| Event A auto-reload invoice INVOICE_0004 | **US$162.51** | Authenticated provider email summary; underlying request/debit sequence absent |
| Event B reported balance decline | **US$29.12** | Contemporaneous first-party endpoint reports; provider ledger confirmation absent |
| **Opening reconciliation demand** | **US$356.62** | Full narrow exposure presumed due; rebuttable request by request |

The opening position is:

> The full US$356.62 is presumed due. OpenAI exclusively controls the records capable of disproving all or part of that amount. Any reduction must therefore be earned request by request with evidence that the specific amount was correctly attributed, knowingly authorized, correctly priced and correctly settled. Any portion OpenAI does not so disprove remains due.

## Reduction rule

OpenAI receives **no reduction** for a conclusion, aggregate assurance, screenshot, unsupported classification or statement that “the client requested Priority.”

A reduction is earned only for a specifically identified debit row or transaction component that is reconciled through all applicable gates below.

| Gate | OpenAI must show | Failure effect |
| --- | --- | --- |
| G1 — Request identity | Stable request, response, turn, client and root/thread IDs with UTC timestamps | The amount cannot be tied to known work; no reduction |
| G2 — Account and funding identity | Stable pseudonymous account, workspace, auth principal and funding-pool IDs | Wrong or missing attribution leaves the full row disputed |
| G3 — Intended submission target | Desktop composer, Remote, queue, automation or internal-workflow event mapped to the visible selected task and client ID | Root attachment alone does not establish intended targeting |
| G4 — Tier authorization | The actor/writer, prior value, timestamp and deliberate user/admin/config action that authorized Fast/Priority | A client-sent `service_tier=priority` field alone is insufficient |
| G5 — Usage | Model, reasoning, input, cached-input, output and reasoning tokens for the completed request | Unmeasured or aggregate usage cannot justify the individual debit |
| G6 — Historical price | Applicable historical rate-card version, multiplier and included-plan offset | Frozen reference rates or present policy cannot silently validate historical charging |
| G7 — Debit and settlement | Debit, currency, balance before/after, settlement timestamp and purchased-credit allocation | Arithmetic cannot be reconciled; no reduction |
| G8 — Retry/guardian treatment | Parentage, completion, deduplication and separate debit status | Duplicate or orphaned amounts remain disputed |

## How reductions work

### Fully validated request

If OpenAI proves every applicable gate for one request, subtract that request's **actual historical debit** from the opening demand.

### Valid work, but Fast/Priority authorization not proven

If OpenAI proves the account, intended target, usage, historical rate and settlement but cannot prove Fast/Priority authorization:

- subtract only the proven Standard-mode portion;
- retain the proven Fast premium in the demand; and
- include any secondary purchased-credit effect caused by prematurely exhausting an included allowance only if the ledger quantifies it.

The current-rate US$15.63 Event B premium and US$196.50 Event A premium are sensitivity references, not automatic reductions or final amounts. OpenAI must supply the historical premium request by request.

### Tier valid, but account or target invalid

If the tier and arithmetic were correct but the wrong account, workspace, funding pool or intended task was charged, retain the **full debit** for that request.

### Guardian or retry row

If OpenAI proves a guardian request completed, was authorized as part of intended work, was not duplicated, and was charged correctly, subtract its actual debit. Proving retry deduplication removes only the duplicate-retry theory; it does not validate unrelated requests.

### Event A reload transactions

For each reload, OpenAI must show:

1. the historical reload threshold, target and cap;
2. the balance immediately before and after the reload;
3. every request that consumed the purchased credits;
4. which account/workspace/funding pool consumed them;
5. tier authorization and historical debit for each request; and
6. remaining unused purchased credits or later adjustments/refunds.

The invoice's existence proves the transaction, not the validity of every consumption row that triggered or exhausted it.

## Preventing double counting

The theories overlap. Do not subtract the US$15.63 Fast-premium sensitivity and the US$9.39 older-root sensitivity as though they were independent charges.

For example, if OpenAI proves that the older-root turns were intentionally targeted, the reduction is **not automatically US$9.39**. US$9.39 is a current-rate counterfactual across the broader acute window. OpenAI must provide the actual historical debit for those request IDs. Only that proved amount can reduce the demand, and only after the other applicable gates also pass.

Maintain a request-level allocation table:

| Provider request ID | Presumed-due amount | G1 | G2 | G3 | G4 | G5 | G6 | G7 | G8 | OpenAI-proven non-reimbursable portion | Remaining presumed due |
| --- | ---: | --- | --- | --- | --- | --- | --- | --- | --- | ---: | ---: |
| Pending provider production | Pending | — | — | — | — | — | — | — | — | US$0 | Pending |

The sum of `OpenAI-proven non-reimbursable portion` is the only permitted reduction from US$356.62. Every adjustment must cite the produced row that supports it.

## Response language

> We request reimbursement or account credit of US$356.62, representing the two affected Event A reload transactions and the reported Event B balance decline. The full amount is presumed due unless OpenAI disproves a portion request by request. Because OpenAI exclusively controls the request-level identity, tier-provenance, usage, historical-rate, funding-pool and settlement records, any proposed reduction must identify the specific request or transaction component and supply the corresponding reconciliation fields. Aggregate assurances or a statement that the client sent `service_tier=priority` do not establish informed tier authorization, intended task targeting, correct account attribution or correct debit. We will reduce the amount only by an actual historical debit that OpenAI proves was correctly attributed, knowingly authorized, correctly priced and correctly settled. Any portion not so disproved remains due.

## Decision state

- **Opening claim:** US$356.62, presumed due.
- **Rebuttal burden:** OpenAI must disprove each claimed component with request-level evidence.
- **Reduction method:** actual provider debit rows only; no global dismissal and no deductions based solely on local current-rate estimates.
- **Release effect:** this schedule is communication-layer strategy and is not yet integrated into the external evidence package.
