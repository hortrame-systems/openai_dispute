> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# OpenAI/Codex anomaly mechanism exploration v0.1

**Date:** 2026-09-20  
**Status:** diagnostic analysis; not incorporated into the frozen v1.6.0 release  
**Scope:** Priority/Fast onset, credit depletion and reloads, multiple logical roots, routing/account state, balance reports, and the post-master currency lead

## Executive conclusion

The strongest explanation is a **joint mechanism**, not a single fault:

1. the client was explicitly sending `service_tier=priority` on each new acute root turn;
2. the work had unusually large repeated contexts, with 29.225 million final cumulative input tokens across the six persisted segments;
3. at least 21 additional transient `codex-auto-review`/guardian submissions occurred inside the same acute union window, while only one appeared in the six-segment table;
4. a ChatGPT Codex model-catalog transition from seven to eight models and a new ETag occurred immediately after a `token_revoked` refresh failure;
5. genuine short user inputs were submitted to three roots in rapid succession, including the two older-root turns; and
6. purchased-credit, included-plan, account/workspace and settlement records remain provider-controlled.

This joint model can explain a large fraction of the apparent economic anomaly **without requiring incorrect debit arithmetic**. The remaining high-value dispute questions become narrower:

- Why did the client begin and continue sending Priority/Fast?
- Which account/workspace and funding pool was attached to each request during the auth/catalog transition?
- Why were genuine inputs attached to the older root: deliberate task switching, queue/remote submission, or routing desynchronization?
- Were transient guardian calls and the one retry charged, and under which model/tier?

## New established local facts

### 1. The older-root turns were not promptless background work

The raw rollout and local session-handler logs show explicit `TurnInput` operations with client IDs:

| UTC | Root | Input | New-turn Priority override |
| --- | --- | --- | --- |
| 00:56:33.095 | `01a03b91-…` | `Go` | yes |
| 00:56:42.755 | same active turn | `We're on a very limited token budget` | steer; no new override |
| 01:01:53.053 | `01a03b91-…` | `Is anything running? Be brief and tell me what` | yes |

These inputs do not match either automation prompt targeting that root. Both automations were marked `PAUSED` roughly ten hours earlier.

**Correction:** the unresolved question is no longer whether a user-role input existed. It is which UI/remote/queue surface submitted it and why that surface targeted the older root.

### 2. The user was actively submitting across three roots

Inside the six-segment union window, local logs contain 12 MESSAGE_0001 submissions across the Astra, Merlin and older OLDER_TASK roots. Five new root turns carried an explicit Priority override; steering messages inherited the active turn.

This supports two competing explanations:

- ordinary rapid switching among visible tasks; or
- genuine inputs routed to a different logical root from the one the user believed was active.

The local record cannot choose between them. A root-thread ID and a MESSAGE_0003 input ID do not identify the visible composer surface.

### 3. The “complete six segments” exclude transient guardian work

Within 00:56:11.652–01:07:47.632 UTC, the logs show:

- 21 `codex-auto-review` guardian submissions;
- three guardian logical threads;
- 2,168,822 serialized submission-log bytes;
- ten review calls attached to the ROOT_B, ten to the ROOT_C and one to the older root; and
- one guardian request retried after a WebSocket disconnected before completion.

Only the older-root guardian call at 00:57:01 appears as a paired segment in analysis 36/38. The other transient review requests do not have a matching persisted task segment in the six-segment calculation.

Current official OpenAI documentation says local reviews count toward general usage limits. Their request-level token/debit records are nevertheless absent locally.

**Correction:** 26,386,511 post-initial tokens is complete only for the six paired persisted segments. It is not complete local model-request accounting for the acute window.

### 4. An auth/catalog boundary occurred at event onset

Local model-manager logs show:

| Time UTC | Observation |
| --- | --- |
| 00:54:32 fetched | seven-model catalog, ETag `4e4e297d…` |
| 00:56:11 | first acute Astra submission |
| 00:56:12 | model refresh failed: `401 Unauthorized`, `token_revoked` |
| 00:56:16 fetched | eight-model catalog, ETag `01ce13a3…` |
| 00:56:20 onward | the eight-model catalog was reused across all acute roots and guardian threads |
| 01:00:42 onward | `token_revoked` model-refresh failures recurred approximately every 270 seconds |

The snapshot's `models_cache.json` uses the legacy top-level shape (`fetched_at`, `etag`, `client_version`, `models`) without visible provider/auth identity fields. Two enabled remote-control enrollment rows later bind the same desktop/server name to two distinct hashed account and environment IDs.

This is strong evidence of **identity/catalog churn**. It does not establish that the wrong identity was billed, that the known cache defect caused the event, or that the cache lacked identity checks in memory.

### 5. The local thread projection is internally inconsistent

In the Sep. 16 state snapshot, all three acute user roots have `has_user_event=0` even though their rollouts and session-handler logs contain explicit MESSAGE_0001 user inputs.

The older root also has a projected `created_at_ms` of Sep. 15 even though preserved session metadata places that same logical root in the corpus by Aug. 26.

These fields may describe a paginated/imported projection rather than canonical thread creation and user-history state. The discrepancy supports a **client state/projection desynchronization** avenue for sidebar recency, task selection or routing anomalies. It does not prove that a user input was displayed under the wrong task.

### 6. Current-rate arithmetic makes ordinary depletion plausible

As a counterfactual only, applying the current official ChatGPT/Codex rates and current 2.5× Fast multiplier to the five known-model persisted segments gives approximately **1,876.50 credits**:

- Astra segments: approximately 1,241.12 credits;
- Sol segments: approximately 635.39 credits;
- `codex-auto-review`: excluded because its debit mapping is not locally established;
- 20 additional transient guardian submissions: excluded.

The historical local purchase UI showed 5,000 credits for US$200. Combining that historical nominal conversion with a current rate card would be a cross-time heuristic, not a valid historical reconstruction, but it demonstrates that the observed workload is easily large enough to make rapid depletion economically plausible.

The provider must still supply the Sep. 15 rate card, included-plan application, credit-to-currency conversion and request debit ledger.

### 7. Event A's task-count control is too weak to reject ordinary workload economics

Aug. 31 had only 1.21× Aug. 29 task starts, but it also had:

- 2.93× rollout source bytes;
- 55.7% explicitly Priority task starts; and
- another 21.2% task starts with unknown tier.

Using today's 2.5× Fast multiplier only as a sensitivity check, the combined rollout-byte/tier proxy is roughly **5.37× to 6.30×** Aug. 29, depending on the unknown-tier assumption.

Rollout bytes are not tokens, the tier shares are not token-weighted, and today's multiplier is not the historical rate. The calculation proves only that “task starts rose just 21%” does not imply cost intensity rose just 21%.

## Ranked explanatory avenues

| Rank | Mechanism | Local support | What it can explain | Limitation |
| --- | --- | --- | --- | --- |
| 1 | High-context Fast/Priority economics | High | rapid purchased-credit depletion in both events | historical rate/debit ledger absent |
| 2 | Omitted transient guardian/auto-review workload | High existence; unknown cost | additional invisible consumption and concurrency | 20 requests lack local usage/debit rows |
| 3 | Persisted client Priority state | High | nearly universal Priority and task-boundary transitions | initial authorization source unresolved |
| 4 | Auth/catalog identity churn | High event evidence; medium causal link | catalog/tier persistence and wrong funding-pool possibility | account identity per request provider-controlled |
| 5 | Genuine inputs attached to the wrong logical root | High inputs; medium misrouting inference | multiple-root anomaly | deliberate switching remains a competing explanation |
| 6 | Local thread-state projection desynchronization | High inconsistency; medium routing link | sidebar/recency/root-selection anomaly | canonical server thread state absent |
| 7 | Included-plan versus purchased-credit settlement | Medium | abrupt balance changes and reload timing | ledger, thresholds and negative-balance state absent |
| 8 | Fixed ~5,000-credit reload target | High structural plausibility | repeated ~5,000-credit episode magnitude | target/cap history provider-controlled |
| 9 | Remote control, queue or scheduled-task path | Mechanisms present; event link weak | submissions without another local process | no event-specific remote marker; automations paused |
| 10 | WebSocket retry duplication | One established guardian retry | small extra request/debit possibility | no evidence it materially affected total or was double-billed |
| 11 | Currency conversion/authorization display | Pending lead | `$229.95` provider display versus `330.38 CAD` card authorization | source screenshots absent; no historical purchase-page proof |

## Important reinterpretations

### Arithmetic correctness and authorization are different questions

The observed depletion may be arithmetically normal for the workload while the Priority authorization, thread target or account funding pool was wrong. These questions must not be collapsed.

### The repeated ~5,000-credit magnitude is not independent evidence by itself

If auto-reload was configured to buy or restore approximately 5,000 credits, two episodes near 5,000 are mechanically expected. The 2.36% magnitude similarity does not independently support a shared defect until the reload target and settlement rules are known.

### “No exact `/fast` command” does not mean the requests lacked an explicit tier

The acute session-handler records show the client submitted Priority in new-turn settings. The absence of `/fast` narrows the authorization source to UI state, persisted configuration, managed/default resolution, cache/catalog state or another client path.

### “One visible session” does not mean one logical workload

One desktop process handled three user roots and multiple guardian threads. Remote control and queue facilities also exist. A single operator/device claim therefore cannot bound logical or billable concurrency.

## Discriminating provider requests

Add these fields to the OpenAI request:

1. Map each acute client ID and turn ID to the submitting surface: desktop composer, mobile Remote, queued input, automation, recovery, or internal workflow.
2. Identify the account, workspace, auth identity and funding pool for every request before and after 00:56:12 UTC.
3. Provide the seven-model and eight-model catalog responses, ETags, provider/auth cache keys and default tier fields.
4. Identify why the client sent `service_tier=priority` on each new root turn and the provenance of the persisted setting.
5. Provide request/token/debit rows for all 21 guardian submissions and the 00:59:55 retry.
6. Provide the auto-reload threshold, target, cap, negative-balance state and settlement sequence for Event A.
7. Distinguish included-plan consumption, purchased-credit consumption and any cross-feature or cross-workspace debit.
8. Confirm whether either enabled remote-control enrollment submitted or steered either older-root turn.
9. Reconcile canonical server thread creation/user-event/recency fields with the inconsistent local thread projection.

## Release implication

The frozen v1.6.0 package should not be sent as the final word without a correction layer. The new evidence strengthens the request for provider records but weakens two existing formulations:

- the older-root turns have unresolved **surface/thread-target provenance**, not wholly unresolved initiation provenance; and
- six persisted segments are not complete local request accounting because transient guardian reviews are omitted.

Do not overwrite v1.6.0. Preserve it and add a separately versioned correction/addendum after owner review.

## Reproducibility

Scripts in this directory query the supplied snapshot read-only using SQLite `mode=ro&immutable=1`:

- `probe_event_b_execution_paths.py`
- `summarize_event_b_submissions.py`
- `quantify_hidden_guardian_work.py`
- `summarize_cache_states.py`
- `probe_event_b_retries.py`
- `estimate_current_rate_card.py`
- `estimate_event_a_weighted_proxy.py`

No file in `<PRIVATE_PATH>

## Current official references

These pages were verified 2026-09-20 and are used only for current mechanism/rate sensitivity, never as silent historical Sep. 15 rules:

- OpenAI ChatGPT/Codex pricing: http<PRIVATE_PATH>
- OpenAI Codex speed/Fast mode: http<PRIVATE_PATH>
- OpenAI Remote connections: http<PRIVATE_PATH>
