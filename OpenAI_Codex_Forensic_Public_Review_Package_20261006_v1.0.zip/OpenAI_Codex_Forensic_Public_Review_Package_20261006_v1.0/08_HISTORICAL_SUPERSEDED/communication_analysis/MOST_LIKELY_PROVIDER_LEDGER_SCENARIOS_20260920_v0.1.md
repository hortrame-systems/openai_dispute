> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Most likely provider-ledger scenarios — OpenAI dispute

**Date:** 2026-09-20  
**Status:** working prior and decision table; not a provider ledger, refund determination, legal opinion or statistical model

## Bottom line

The leading prediction is not that OpenAI's token arithmetic is grossly wrong. It is that its internal rows will show real requests, large token volumes and a resolved Priority/Fast tier, and support may treat the presence of `service_tier=priority` as authorization. That would answer the arithmetic question but not the authorization question.

The likely disputed defect is **provenance**: whether a deliberate owner action selected Priority, the intended visible task, and the account/workspace/funding pool charged during the `token_revoked` and model-catalog transition. A client field proves what the client sent. It does not prove who or what set the state, what the user saw, or that the user knowingly accepted the premium.

The most likely financial result for the exact Sep. 15 endpoint interval is therefore:

- most or all of the US$29.12 balance decline reconciles to actual model and guardian activity;
- the strongest partial-refund theory is the approximately **US$15.63 Fast premium** on known persisted usage if OpenAI cannot show deliberate tier authorization;
- a request-specific wrong-thread amount is approximately **US$1.26** inside the exact interval or **US$9.39** across both older-root persisted tasks in the acute window;
- a wrong-account/funding-pool finding would put up to the full **US$29.12** interval debit at issue; and
- Event A adds **US$327.50** of reconciliation exposure, but its request-level denominator is still missing.

These amounts overlap. They must not be added unless the provider rows establish distinct debits.

## Working priors about what the ledger will show

The probability bands below are judgmental priors derived from the current local evidence. They are not frequencies or statistical confidence intervals.

| Predicted ledger finding | Working prior | Why this is the current prior | What changes it |
| --- | ---: | --- | --- |
| Sep. 15 token/debit arithmetic broadly reconciles | **75–90%** | Known persisted-model usage at current rates explains 651.3204 of 728 nominal credits, or 89.47%, before pricing nine guardian calls in the exact balance interval. | Historical request rows, rate version, debit and balance-before/after either close or fail the 76.6796-credit residual. |
| Acute new turns contain a resolved Priority/Fast tier | **95–100%** | Five locally captured new-turn requests explicitly carry `service_tier=priority`. | Only a provider record showing the field was ignored or resolved to Standard would alter this. |
| OpenAI initially classifies the tier as "MESSAGE_0002" because the request field is present | **80–95%** | This is the easiest provider interpretation of the request rows. It does not establish informed consent. | A tier-provenance audit that identifies the actual writer, UI action, timestamp and prior value. |
| No retained record proves a deliberate user action enabled Priority for these turns | **55–75%** | No `/fast` command was found; the onset coincides with an auth/catalog boundary; ordinary backend ledgers often retain resolved fields more reliably than UI-state provenance. | A contemporaneous UI/setting event tied to the same stable user, device, workspace and request sequence would validate deliberate opt-in. |
| Priority state persisted or was re-resolved across the auth/catalog transition without a fresh deliberate choice | **45–65%** | `token_revoked`, a 7→8 model-catalog/ETag change and cross-root Priority reuse occur together. | A stable single auth identity plus a pre-existing, user-set Priority preference with no transition discontinuity would weaken it. |
| At least one genuine input landed on a different logical root than the visible composer the owner believed was active | **25–50%** | Explicit inputs reached the older root while local thread projections are inconsistent; the submitting surface is missing. Rapid deliberate task switching remains a real alternative. | Renderer/composer, Remote, queue and canonical thread-target events mapped to the client IDs. |
| At least one request was charged to the wrong account/workspace/funding pool | **15–35%** | The auth/catalog churn and two distinct later remote-enrollment identities make it plausible, but no local request-to-funding mapping exists. | Stable pseudonymous account/workspace/funding IDs on every request and debit can validate or dismiss it. |
| Guardian/auto-review calls explain most of the 76.6796-credit residual | **60–80%** | Nine transient guardian submissions occurred inside the exact interval; their local debit rows are absent. | Guardian tokens, model, tier and debits either reconcile to the residual or do not. |
| The one WebSocket retry was double-billed materially | **<10%** | Only one retry is established and no duplicate debit evidence exists. | Parent/retry request IDs and deduplication/debit rows. |
| All US$356.62 in the narrow Event A + Event B scope was wholly unauthorized | **<10%** | Event B contains real user inputs and model work; Event A lacks a token denominator. | This rises only if the provider maps the complete debit set to an unauthorized identity or proves no valid owner benefit/authorization. |

## Financial outcomes as records arrive

Amounts are scenario-specific and non-cumulative. "At issue" is not the same as "legally recoverable."

| Ledger outcome | Sep. 15 amount at issue | Event A amount at issue | Current status | Validate with | Dismiss with |
| --- | ---: | ---: | --- | --- | --- |
| Correct account, intended roots, deliberate Priority, complete reconciliation | **US$0** | **US$0** | Plausible but not established | Deliberate tier-setting event; intended-surface mapping; complete request/debit reconciliation | Missing or contradictory provenance, account or balance rows |
| Arithmetic discrepancy only | **US$0–3.07** | Unknown | Low-value possibility | Historical rows leave an unexplained debit after guardian and settlement timing | Guardian/rate/settlement rows close the residual |
| Correct usage, but Priority/Fast premium was not deliberately authorized | **approximately US$15.63** | **US$0–196.50 ceiling** | Strongest bounded partial-refund theory | No deliberate tier event; Standard entitlement; historical 2.5×-equivalent or actual premium by request | Contemporaneous deliberate opt-in tied to these requests |
| One older-root persisted task in the exact endpoint interval was misrouted | **approximately US$1.26** | Not quantified | Open | Visible-composer/Remote/queue target differs from server root | Matching intended task/surface event |
| Both older-root persisted tasks in the full acute window were misrouted | **approximately US$9.39** | Not quantified | Open, weaker because explicit inputs exist | Same as above for both roots | Deliberate task-switch events for both roots |
| Wrong account/workspace/funding pool for the Sep. 15 interval | **up to US$29.12** | Affected Event A debits only | Open, lower prior but high consequence | Stable provider account/workspace/funding IDs conflict with the owner's authorized identity | Every debit maps to the authorized identity and pool through the transition |
| Guardian calls were ordinarily billed | **US$0 refund** | Unknown | Likely | Guardian rows reconcile activity and residual | Duplicate, orphaned or unauthorized guardian debit rows |
| Guardian/retry duplication or non-deduplication | **up to US$3.07 on current evidence** | Unknown | Low prior | Distinct debit rows for the same retry lineage or unexplained guardian duplicates | One completed debit per logical call and proper retry deduplication |
| Event A valid work but unauthorized Fast premium only | Not additional to the Sep. 15 row | **up to US$196.50** | Highly conditional ceiling | Historical Event A requests were Fast, Standard should have applied, and 2.5× relationship applies | Standard/authorized tier, different rate, or reloads not all consumed by affected work |
| All narrow-scope usage charged to a wrong identity or wholly unauthorized | **US$29.12** | **US$327.50** | Unsupported low-prior ceiling | Complete provider rows establish wrong identity/absence of valid authorization for every debit | Any validated authorized portion reduces the amount request by request |
| Narrow combined ceiling under the preceding full-unauthorized scenario | **US$356.62 total** | Included | Audit ceiling, not present claim | Same complete wrong-identity/unauthorized proof | Any valid debit row |

## What an acceptable provider answer must contain

A prose statement such as "we confirm this was your account" or "the client requested Priority" is nonresponsive. The minimum useful response is a machine-readable reconciliation, or an attested table if raw internal logs cannot be disclosed, with one row per model/guardian request:

1. provider request and response IDs; local client ID, turn ID and root/thread ID;
2. UTC submission, start, completion, retry and settlement timestamps;
3. stable pseudonymous account, workspace, auth principal and funding-pool IDs;
4. submitting surface: desktop composer, Remote, queue, automation, recovery or internal guardian;
5. requested tier, resolved tier, the setting's writer/source, prior value and deliberate UI/config action if any;
6. model, reasoning level, input/cached/output/reasoning tokens;
7. historical rate-card version, multiplier, included-plan offset, purchased-credit debit and currency conversion;
8. credit balance before/after each settled debit;
9. guardian parentage and retry/deduplication result; and
10. export scope, retention gaps and omitted event classes.

The rows must reconcile against the local timestamps, client IDs, roots, response IDs where available, six persisted token segments, 21 guardian submissions and observed balance endpoints. A provider-controlled ledger is not automatically trusted; it becomes persuasive when independent local anchors constrain what it can truthfully say.

## Why this is a reasonable demand

Current official OpenAI documentation says Usage Insights can break credit consumption down by task, model, reasoning and speed, and explicitly advises pairing usage data with team records. It separately describes append-only compliance records for investigations and for correlating Codex activity with identity data. Eligibility and disclosure access may differ for this account, but those documented audit surfaces show that a bare support conclusion is not the only possible evidentiary form.

Official references:

- http<PRIVATE_PATH>
- http<PRIVATE_PATH>
