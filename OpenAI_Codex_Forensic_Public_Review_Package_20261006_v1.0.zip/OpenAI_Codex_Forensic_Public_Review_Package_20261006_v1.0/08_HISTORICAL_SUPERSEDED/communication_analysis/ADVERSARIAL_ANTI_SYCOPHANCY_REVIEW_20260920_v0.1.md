> HISTORICAL / SUPERSEDED SOURCE. This text records an earlier analysis or position; it is not this release's controlling claim or remedy. Consult the public README and current corrections.

# Adversarial anti-sycophancy review — OpenAI dispute

**Date:** 2026-09-20  
**Scope:** v1.6.1 corrected release, its verification scripts and safe evidence, plus the later anomaly, financial and provider-ledger scenario analyses  
**Review standard:** `communication_inter-agents/anti_sycophancy_review_integrity.md`  
**Mutation boundary:** review only; no release file or external package was changed

**Correction — 2026-09-20:** The original AR-05 improperly said contextual compatibility favored deliberate task switching. That inference exceeded the evidence. The record proves which root received the inputs, not what task the owner saw, selected or intended. AR-05 below is corrected accordingly.

## Verdict

**HOLD v1.6.1 from external submission pending one further integrated correction.**

The central evidentiary core survives: the local request/tier records, six persisted-segment arithmetic, auth/catalog transition, guardian-submission count, correction of the older-root initiation claim, and refusal to assert proven overbilling are defensible within their stated scopes.

The package is not yet the strongest external presentation. Its main defects are over-disclosure of unrelated telemetry, historical material that still speaks as if it were current, over-ranking of a cross-time sensitivity as the leading economic explanation, and verification scripts that do not independently rederive most new raw-snapshot findings. The later probability table also assigns unsupported numerical priors and should not be used.

## Findings

### AR-01 — P1 — The external package over-discloses unrelated operational telemetry

The release calls itself a positive allowlist, but three included tables alone contain 93,862 rows across weeks or months:

| File | Total rows | Rows in 00:54–01:08 UTC acute interval | Acute share |
| --- | ---: | ---: | ---: |
| `task_events.csv` | 21,745 | 12 | 0.06% |
| `token_usage_events.csv` | 32,840 | 56 | 0.17% |
| `tool_events.csv` | 39,277 | 16 | 0.04% |

They expose unrelated task/thread IDs, timestamps, source paths, model/reasoning/tier history and tool-use patterns. Other included tables expose hashed identity hints and broad thread metadata. The verifier skips secret-pattern scanning for files larger than 5 MB; these three files are 6.5 MB, 12.6 MB and 12.4 MB. A separate bounded regex check found no obvious OpenAI/GitHub/AWS token pattern, but that does not establish privacy minimization or absence of other confidential metadata.

**Consequence:** the package unnecessarily exposes HORTRAME/OLDER_TASK operational structure, gives OpenAI irrelevant material to inspect, and weakens the claim that the release is narrowly curated.

**Correction:** create event-specific extracts plus only the aggregate baseline rows actually cited. Run disclosure checks over every byte regardless of file size and inspect columns for unnecessary identifiers. Keep the broad tables in the internal evidence layer, not the external release.

### AR-02 — P1 — The 89.47% sensitivity is useful, but “leading explanation” is not established

The 651.3204-credit result is mathematically reproducible for its inputs. Its interpretation combines four different evidence classes:

1. current, not historical, token prices;
2. the current 2.5× Fast multiplier;
3. a historical nominal purchase conversion of 25 credits/US$; and
4. two first-party balance reports rather than provider ledger entries.

That scenario explaining 89.47% demonstrates quantitative compatibility. It does not establish that ordinary charging is more probable than an unauthorized-tier, wrong-funding-pool or historical-rate discrepancy. No historical likelihood weights permit ranking those alternatives.

**Consequence:** wording such as “ordinary charging is now the leading explanation” gives a counterfactual sensitivity more inferential force than its inputs support and can be attacked as cross-time cherry-picking.

**Correction:** replace “leading explanation” with: “ordinary charging cannot be rejected on magnitude alone and is quantitatively compatible under the stated current-rate scenario.” Keep authorization and attribution unresolved.

### AR-03 — P1 — Superseded evidence still speaks in current, accusatory language

The frozen baseline HTML is labeled historical by its folder README, but the HTML itself contains phrases such as “Current finding,” “current responsibility posture,” “hemorrhage,” and “zero strictly linked overlapping auto-review workers.” The later correction establishes 21 transient guardian submissions and narrows the completeness claim. A frozen first-party attestation also ends with a “Correct unresolved question” that predates the explicit-input correction.

**Consequence:** an external reviewer opening or searching the historical HTML can find assertions that conflict with the controlling v1.6.1 thesis. The package then appears internally inconsistent despite the supersession notes.

**Correction:** exclude the full historical HTML from the external release or wrap it with an unavoidable superseded-content banner and an exact correction map. Extract only the still-relied-upon facts into current evidence files. Correct the stale attestation commentary while preserving the attestation itself unchanged.

### AR-04 — P1 — The later numerical probability priors are unsupported and should be withdrawn

`MOST_LIKELY_PROVIDER_LEDGER_SCENARIOS_20260920_v0.1.md` assigns ranges such as 55–75% for missing deliberate opt-in evidence, 25–50% for wrong visible-root routing and 15–35% for wrong account/funding-pool charging. No base rate, calibrated sample, likelihood model or provider data supports those percentages.

The ranges were introduced after the owner objected that OpenAI was receiving too much benefit of the doubt. Under the anti-sycophancy standard, audience preference must not influence accepted probability. The correct response was to strengthen the evidentiary burden, not manufacture numerical confidence.

**Consequence:** the probability table converts unresolved possibilities into pseudo-quantitative probabilities and should not enter any package, demand or financial expectation.

**Correction:** replace all percentages with evidence classifications: established, supported mechanism, plausible alternative, weakly supported, contradicted, or provider-dependent. Preserve financial amounts only as explicit conditional calculations.

### AR-05 — P2 — The local record cannot rank deliberate switching against unintended targeting

The two older-root inputs—`Go`, a token-budget warning, and later `Is anything running? Be brief and tell me what`—were received by an ongoing OLDER_TASK root, and the response accurately described that root's work. That establishes root attachment and contextual compatibility only. The phrases are generic enough to fit more than one active task, and the correct response merely reflects the state of the root that received them. No renderer/composer record identifies the task the owner saw, selected or intended.

The public issue about turn notifications arriving under an unknown conversation ID corroborates a defect class, but it is an unverified third-party report about missing/displayed responses, not proof that composer input was delivered to an older root here.

**Consequence:** neither deliberate switching nor unintended targeting can be ranked from the present local record. The 25–50% routing prior remains unsupported, and the US$1.26/US$9.39 amounts remain conditional illustrations rather than expected losses.

**Correction:** preserve both explanations as unresolved and request authoritative composer/Remote/queue-to-root mapping for the client IDs.

### AR-06 — P2 — Guardian traffic exists, but its residual-cost role is unmeasured

Twenty-one guardian submissions and nine within the balance interval are established locally. Completion, billable processing, model, token totals, cache treatment and debit are not. Serialized log-byte calibration is explicitly diagnostic.

**Consequence:** the later 60–80% prior that guardian calls explain the 76.6796-credit residual is unsupported. They may explain none, some or more than the nominal residual depending on provider treatment.

**Correction:** describe guardian work as an omitted accounting category, not the likely residual explanation, until provider rows arrive.

### AR-07 — P2 — Most raw-snapshot findings are integrity-checked, not independently reproduced by the release verifier

`verify_corrected_release.py` verifies file membership/hashes, selected stored JSON values, claim statuses and the six-segment derivation. It does not rerun the raw SQLite queries for the 21 guardian submissions, auth/catalog chronology, explicit client submissions, remote enrollments, queue state or retry. Those query scripts require an external 7.3 GB raw snapshot and contain machine-specific absolute paths.

**Consequence:** “corrected evidence invariants verified” can be misread as independent reproduction of all new findings. An external reviewer cannot run the raw derivations without editing scripts and obtaining controlled raw data.

**Correction:** parameterize source paths, provide one reproducibility command and environment manifest, and make the verifier distinguish `integrity_check`, `included_safe_table_rederivation` and `controlled_raw_rederivation_not_run`.

### AR-08 — P2 — The provider request is comprehensive but insufficiently prioritized

The request asks for request/debit rows, UI surface, full model catalogs, ETags, cache keys, token-revocation history, canonical thread projections, guardian/retry treatment and Event A settlement configuration. All are relevant, but a support agent can respond selectively or declare some internal fields unavailable.

**Consequence:** an over-broad request increases the chance of a generic reply and makes it harder to characterize nonresponse precisely.

**Correction:** split the demand into:

1. **minimum dispositive ledger:** request/account/workspace/funding pool, tier and tier provenance, tokens, rate, debit, balance before/after;
2. **routing closure:** client/turn/root/submitting surface;
3. **mechanism investigation:** catalog/cache/revocation/projection internals.

### AR-09 — P3 — “Exact reported interval” uses inconsistent endpoint timestamps

Analysis 41 dates the US$4.60 rollout message at 01:07:30.134 UTC. Analysis 49 and the sensitivity script use the session-handler submission at 01:07:29.072 UTC. Both are legitimate client events, but they are not the same timestamp.

**Consequence:** “exact reported timestamp interval” is overstated by about 1.062 seconds. No observed token update appears to change the 651.3204 result, so this is a labeling/provenance defect rather than a material arithmetic error.

**Correction:** name the chosen boundary `submission_received` and report the later persisted-message timestamp separately.

### AR-10 — P3 — Stale cross-references remain

`02_SUPPORTING_ANALYSES/README.md` says the controlling interpretations are analyses 40 and 42 and ledger 43, and cites `CL156-17`. The actual controlling thesis and ledger are 50 and 51 with `CL161-*` IDs.

**Consequence:** minor credibility and navigation defect.

**Correction:** update the references in the next integrated release.

## Findings that survived adversarial review

1. **Manifest integrity:** the local verifier passes all 82 release files and the final ZIP had deterministic build evidence.
2. **Six persisted segments:** their token arithmetic rederives from included safe tables and is correctly limited to six paired persisted segments.
3. **Explicit inputs:** the older-root turns contain client/user inputs; the earlier promptless-initiation theory is contradicted.
4. **Priority request state:** five acute new user-root turns explicitly carried `service_tier=priority`; current OpenAI code maps the Fast tier's request value to `priority`.
5. **Auth/catalog chronology:** `token_revoked`, the seven-to-eight model transition and ETag change are established local observations; causation and account attribution remain unproven.
6. **Guardian existence:** 21 submissions are established locally; their token/debit cost is not.
7. **Economic non-conclusion:** no exact historical overbilling or refund amount is established.
8. **Conditional mathematics:** US$15.63 for the known-usage Fast premium and US$196.50 for the Event A all-Fast 2.5× scenario are arithmetically correct under their explicit assumptions, but neither is a present entitlement.
9. **Public mechanism evidence:** OpenAI's cache-identity fix supports a real defect class; the package correctly stops short of account-specific causation.

## Corrected adversarial conclusion

The evidence supports a serious request for an auditable provider reconciliation. It does **not** presently justify saying that wrong-account billing is the most likely outcome, that visible-thread misrouting probably occurred, that deliberate switching probably occurred, that guardian calls probably close the residual, or that a refund is more likely than not.

The strongest affirmative dispute point is narrower:

> Local records show that Fast/Priority was requested across the affected work, while the owner attests it was never knowingly selected or authorized; the preserved client data cannot identify the historical writer or funding identity. OpenAI must reconcile tier provenance and request-level debits. The observed balance decline is quantitatively compatible with ordinary Fast charging under a current-rate scenario, but historical arithmetic, authorization and attribution remain separate and unresolved.

That formulation neither trusts OpenAI's conclusion nor presumes misconduct. It defines what evidence would decide the case.
