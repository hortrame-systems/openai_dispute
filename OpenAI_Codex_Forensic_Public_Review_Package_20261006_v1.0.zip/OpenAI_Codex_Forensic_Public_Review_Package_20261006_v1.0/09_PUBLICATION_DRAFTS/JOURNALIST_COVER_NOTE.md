Subject: Reproducible Codex credit-consumption record with an unresolved provider reconciliation

Hello,

HORTRAME has prepared a public forensic archive concerning unexpected Fast/Priority state, an acute large cached-context workload, and the limits of client-side credit reconciliation.

The release includes minimized structured evidence, executable calculations, contrary evidence, withdrawn claims and a dated support history. Six persisted segments show large cumulative input totals and repeated continuations; additional guardian submissions are counted separately. Those observations do not establish a specific overcharge or causal product defect.

The procedural issue is reviewable: one support thread records provider reconciliation as open and pending, while another was closed without the requested historical reconciliation. A subsequent AI-assisted reply could not confirm the earlier internal case states. The archive does not attribute motive.

Historical authorization, request-to-funding attribution, effective pricing and debit/settlement records remain provider-controlled. The package explains what an independent technical reviewer can reproduce and what requires controlled originals or OpenAI records.

Individual remediation is being pursued separately. The public material is intended to help reviewers test the evidence and identify comparable patterns safely, rather than solicit a conclusion.

The package filename is `OpenAI_Codex_Forensic_Public_Review_Package_20261006_v1.0.zip`. Its released SHA-256 should be checked before use. The README gives the review order and reproduction commands. Publication of these drafts or sending this note has not occurred.
