# Codex: request-level reconciliation for unexpected Priority state and acute large-context consumption

HORTRAME has prepared a reproducible public forensic package from a previously submitted case. It concerns local tier provenance, context accounting and the records needed to reconcile purchased-credit debits.

The acute trace contains six paired persisted segments: 29,225,371 final cumulative input tokens, 26,350,976 cached post-initial input tokens and 50 post-initial continuations. It also identifies 21 guardian submissions, including one represented segment and 20 additional submissions. These are client accounting observations, not a complete provider request/debit inventory.

The working model separates earlier elevated consumption from the acute large-context episode. Fast/Priority can be relevant to cost, but a tier multiplier does not explain why the workload repeatedly carried that context. Context replay, orchestration, legitimate continuation and accounting behavior remain competing hypotheses.

The release preserves contrary evidence: a post-event configuration containing Priority and a frozen-rate scenario compatible with 89.47% of one nominal reported balance decline under cross-time assumptions. Neither a billing defect nor a historical debit's validity follows from that scenario.

We seek the historical requested/resolved tier, writer and authorization event; request-level usage and parentage; account/workspace/funding mapping; effective rates/multiplier stack; credit debit/balance/settlement records; and applicable adjustments.

Support correspondence records provider reconciliation as pending in one thread and closes another without providing that reconciliation. The public release preserves both statements and the latest inability of AI-assisted support to confirm internal case states.

To review, obtain `OpenAI_Codex_Forensic_Public_Review_Package_20261006_v1.0.zip`, check its published ZIP hash, and run:

```text
python -B 05_VERIFICATION/verify_public_release.py
python -B 05_VERIFICATION/run_included_reproductions.py
```

The README and claim ledger distinguish reproducible observations, conditional calculations, unresolved provider facts and withdrawn claims. Confidential raw material is retained privately. Individual remediation is handled separately.

This report requests investigation and reconciliation. It does not assert fraud, intentional misrouting, wrong-account billing or a proven overcharge.
