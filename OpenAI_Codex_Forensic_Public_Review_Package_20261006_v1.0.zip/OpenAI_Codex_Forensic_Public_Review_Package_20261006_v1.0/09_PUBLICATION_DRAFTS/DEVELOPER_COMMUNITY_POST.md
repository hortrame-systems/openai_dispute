# How to examine unexpected Fast/Priority use and large-context credit depletion

We have prepared a minimized public review archive for a Codex incident with recurring elevated consumption and an acute large-context episode.

The included acute trace reproduces six persisted segments, 50 post-initial continuations and 26,350,976 cached post-initial input tokens. Their task-final cumulative input counters total 29,225,371. These totals are neither a single request's context size nor unique resident memory. Additional guardian activity is counted but not assigned a speculative token/debit cost.

The owner reports never knowingly authorizing Fast/Priority. Local Priority fields establish recorded tier state, not who selected it or how it was billed. The package preserves both a post-event Priority configuration and a conditional ordinary-charging compatibility result as contrary evidence.

A price multiplier and workload generation require different explanations. The public working model retains Fast as relevant to earlier elevated use while keeping replay, orchestration, legitimate continuation, attribution and accounting mechanisms unresolved for the acute workload.

For your own report, preserve a private snapshot and record version, timezone, tier metadata, token/cached-token counters, balance observations and purchase/debit records. Inspect structured fields privately; quoted JSON or a literal `/fast` string is only a lead. Never upload authentication files, prompts, account identifiers or an entire Codex home to a public thread.

The archive contains an explicit-root diagnostic helper and a guide to preserving evidence. Its included-evidence verifier and reproduction command run without the confidential snapshot. Raw-dependent checks identify exactly which controlled sources are needed.

OpenAI's historical authorization, effective tier/rate, account/funding attribution and debit/settlement records are decisive. Support has documented that frontline access cannot resolve the necessary historical records; the dated public procedural record also retains the later case closure and case-state uncertainty.

See the archive README, `05_VERIFICATION/PUBLIC_REPRODUCTION.md` and `02_PUBLIC_REVIEW/SUPPORT_HISTORY.md`. Individual credit remediation is separate from this technical discussion.
