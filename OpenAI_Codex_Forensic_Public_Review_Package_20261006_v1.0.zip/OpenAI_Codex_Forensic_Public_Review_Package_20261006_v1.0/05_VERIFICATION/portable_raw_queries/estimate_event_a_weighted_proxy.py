#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import pathlib
import os
import pathlib as _runtime_pathlib
import sys as _runtime_sys
_runtime_sys.path.insert(0, str(_runtime_pathlib.Path(__file__).resolve().parent))
from _runtime import require_env, load_roots, public_id, emit_json, helper_help
helper_help(__file__)


PACKAGE_ROOT = pathlib.Path(require_env("OPENAI_DISPUTE_PACKAGE_ROOT"))
COUNTS = PACKAGE_ROOT / "02_SUPPORTING_ANALYSES/18_CREDIT_DEPLETION_ACTIVITY_PROXIES_v0.1.csv"
FAST_MULTIPLIER_CURRENT = 2.5


with COUNTS.open(newline="", encoding="utf-8-sig") as stream:
    rows = {row["date"]: row for row in csv.DictReader(stream)}
baseline = rows["2026-08-29"]
event = rows["2026-08-31"]
task_starts = int(event["task_starts"])
priority = int(event["priority_task_starts"])
default = int(event["default_task_starts"])
unknown = int(event["unknown_tier_task_starts"])
byte_ratio = int(event["source_bytes"]) / int(baseline["source_bytes"])
minimum_tier_factor = (priority * FAST_MULTIPLIER_CURRENT + default + unknown) / task_starts
maximum_tier_factor = ((priority + unknown) * FAST_MULTIPLIER_CURRENT + default) / task_starts
emit_json(
    json.dumps(
        {
            "aug31_vs_aug29": {
                "task_start_ratio": int(event["task_starts"]) / int(baseline["task_starts"]),
                "rollout_source_byte_ratio": byte_ratio,
                "priority_task_share": priority / task_starts,
                "unknown_tier_task_share": unknown / task_starts,
                "current_fast_multiplier_counterfactual": FAST_MULTIPLIER_CURRENT,
                "weighted_tier_factor_if_unknown_standard": minimum_tier_factor,
                "weighted_tier_factor_if_unknown_fast": maximum_tier_factor,
                "combined_byte_tier_proxy_low": byte_ratio * minimum_tier_factor,
                "combined_byte_tier_proxy_high": byte_ratio * maximum_tier_factor,
            },
            "boundary": "Rollout bytes are not tokens or charges, task-tier shares are not token-weighted, and the current Fast multiplier is not the historical Aug. 31 rate. This only demonstrates that modest task-count growth can coexist with a several-fold cost-intensity proxy.",
        },
        indent=2,
        sort_keys=True,
    )
)
