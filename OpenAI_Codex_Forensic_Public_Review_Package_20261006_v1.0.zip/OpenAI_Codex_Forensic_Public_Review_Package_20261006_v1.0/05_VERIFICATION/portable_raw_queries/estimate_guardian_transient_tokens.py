#!/usr/bin/env python3
"""Fail-safe audit of the superseded v1.6.4 guardian estimator.

The package does not publish a replacement token range. Exact request/turn
boundaries and provider guardian usage/debit records are required first.
"""
from __future__ import annotations

import csv
import json
import os
import pathlib as _runtime_pathlib
import sys as _runtime_sys
_runtime_sys.path.insert(0, str(_runtime_pathlib.Path(__file__).resolve().parent))
from _runtime import require_env, load_roots, public_id, emit_json, helper_help
helper_help(__file__)
import pathlib


def audit_rows(rows: list[dict[str, str]]) -> dict[str, object]:
    candidates = [
        row
        for row in rows
        if row.get("turn_input_tokens") in {"20546", "34323"}
        and row.get("thread_input_tokens") in {"20546", "54869"}
    ]
    candidates.sort(key=lambda row: row["timestamp"])
    if len(candidates) != 2 or candidates[0]["thread_id"] != candidates[1]["thread_id"]:
        raise RuntimeError("guardian counter-boundary regression fixture missing")

    first, second = candidates
    first_turn = int(first["turn_input_tokens"])
    second_turn = int(second["turn_input_tokens"])
    first_thread = int(first["thread_input_tokens"])
    second_thread = int(second["thread_input_tokens"])
    actual_second_turn = second_thread - first_thread
    v164_assignment = second_turn - first_turn
    if actual_second_turn != second_turn or v164_assignment == actual_second_turn:
        raise RuntimeError("guardian counter-boundary regression did not separate")

    return {
        "status": "SUSPENDED_PENDING_TURN_AWARE_RECALIBRATION",
        "current_estimate": None,
        "superseded_v1_6_4_range_input_tokens": {
            "p10": 234774.22293975484,
            "median": 474579.1194961018,
            "p90": 724196.3374434876,
        },
        "demonstrated_counterexample": {
            "same_thread": True,
            "first_turn_input_tokens": first_turn,
            "second_turn_input_tokens": second_turn,
            "first_thread_input_tokens": first_thread,
            "second_thread_input_tokens": second_thread,
            "actual_second_turn_contribution": actual_second_turn,
            "v1_6_4_estimator_assignment": v164_assignment,
            "underassignment": actual_second_turn - v164_assignment,
            "first_raw_record_sha256": first["raw_record_sha256"],
            "second_raw_record_sha256": second["raw_record_sha256"],
        },
        "boundary": (
            "The defect is established, but one counterexample does not determine "
            "the corrected aggregate or its direction. Recalibration requires one-to-one "
            "request/turn matching within the relevant accounting scope, explicit ambiguous "
            "and excluded matches, and provider guardian token/cache/debit records."
        ),
    }


def audit(safe_root: pathlib.Path) -> dict[str, object]:
    token_path = safe_root / "token_usage_events.csv"
    with token_path.open(newline="", encoding="utf-8-sig") as stream:
        return audit_rows(list(csv.DictReader(stream)))


if __name__ == "__main__":
    safe = pathlib.Path(require_env("OPENAI_DISPUTE_SAFE_ROOT"))
    emit_json(json.dumps(audit(safe), indent=2, sort_keys=True))
