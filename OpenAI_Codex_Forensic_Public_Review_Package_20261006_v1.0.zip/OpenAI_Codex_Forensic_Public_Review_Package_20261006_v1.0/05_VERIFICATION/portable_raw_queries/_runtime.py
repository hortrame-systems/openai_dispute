"""Controlled-source requirements and public output projection; no identity grant."""
from __future__ import annotations
import hashlib
import json
import os
import pathlib
import re
import sys
from functools import lru_cache

MAX_PRIVATE_MAP_BYTES=8*1024*1024

def map_bytes(path):
    with pathlib.Path(path).open("rb") as f:
        data=f.read(MAX_PRIVATE_MAP_BYTES+1)
    if len(data)>MAX_PRIVATE_MAP_BYTES:
        raise SystemExit("PRIVATE_MAP_LIMIT")
    return data

@lru_cache(maxsize=1)
def load_map_snapshot(path):
    data=map_bytes(path)
    return json.loads(data),hashlib.sha256(data).hexdigest()

def helper_help(file):
    if "--help" in sys.argv:
        print(pathlib.Path(file).name + ": read-only reproduction. See PUBLIC_REPRODUCTION.md. Included arithmetic needs PACKAGE_ROOT/SAFE_ROOT; SQLite extraction needs controlled RAW_ROOT and PRIVATE_MAP. Missing inputs exit 2.")
        raise SystemExit(0)

def require_env(name):
    value = os.environ.get(name)
    if not value:
        raise SystemExit("CONTROLLED_ACCESS_REQUIRED: " + name)
    return value

def private_map():
    value = os.environ.get("OPENAI_DISPUTE_PRIVATE_MAP")
    return load_map_snapshot(value)[0] if value else {}

def load_roots():
    require_env("OPENAI_DISPUTE_PRIVATE_MAP")
    return private_map()["root_roles"]

def public_id(value):
    return private_map().get("mapping", {}).get(value, value)

def emit_json(text):
    mapping = private_map().get("mapping", {})
    exact = re.compile("|".join(re.escape(k) for k in sorted(mapping, key=len, reverse=True))) if mapping else None
    def clean(value):
        if isinstance(value, dict):
            result={}
            for k,v in value.items():
                if k in {"agent_nickname","agent_role","rrule","server_name","app_server_client_name","daybreak_enabled"}:
                    continue
                if k=="short_input" and isinstance(v,str) and v not in {"Go","Is anything running? Be brief and tell me what","We're on a very limited token budget"}:
                    v="WITHHELD_CLIENT_TEXT"
                if k in {"source","thread_source"} and isinstance(v,str) and v.lstrip().startswith(("{","[")):
                    try: v=json.dumps(clean(json.loads(v)),sort_keys=True,separators=(",",":"))
                    except json.JSONDecodeError: v="UNPARSED_SOURCE_METADATA_WITHHELD"
                result[str(clean(k))]=clean(v)
            return result
        if isinstance(value, list):
            return [clean(v) for v in value]
        if isinstance(value, str):
            value = exact.sub(lambda m: mapping[m.group()], value) if exact else value
            value = re.sub(r"(?i)\b[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\b", lambda m: "ID_" + hashlib.sha256(m.group().encode()).hexdigest()[:12], value)
            value = re.sub(r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", "ACCOUNT_WITHHELD", value)
            value = re.sub(r"[A-Za-z]:[\\/].*", "PRIVATE_PATH_WITHHELD", value)
            return value.replace("aster_root", "root_b").replace("merlin_root", "root_c")
        return value
    result=clean(json.loads(text))
    path=os.environ.get("OPENAI_DISPUTE_PRIVATE_MAP")
    if path and hashlib.sha256(map_bytes(path)).hexdigest()!=load_map_snapshot(path)[1]:
        raise SystemExit("PRIVATE_MAP_CHANGED_DURING_RUN")
    print(json.dumps(result, sort_keys=True, indent=2))

if __name__ == "__main__":
    print("Shared read-only helper support. Invoke an identified reproduction program; see PUBLIC_REPRODUCTION.md.")
