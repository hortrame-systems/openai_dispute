#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import pathlib
import os
import pathlib as _runtime_pathlib
import sys as _runtime_sys
_runtime_sys.path.insert(0, str(_runtime_pathlib.Path(__file__).resolve().parent))
from _runtime import require_env, load_roots, public_id, emit_json, helper_help
helper_help(__file__)


PACKAGE_ROOT = pathlib.Path(require_env("OPENAI_DISPUTE_PACKAGE_ROOT"))
METRICS = PACKAGE_ROOT / "02_CURRENT_ANALYSES/38_EVENT_B_COMPLETE_LOCAL_WORKLOAD_METRICS_v0.1.csv"
STANDARD_CREDITS_PER_MILLION = {
    "gpt-6-astra": {"input": 250.0, "cached": 25.0, "output": 1250.0},
    "gpt-5.6-sol": {"input": 100.0, "cached": 10.0, "output": 500.0},
}
FAST_MULTIPLIER = {"gpt-6-astra": 2.5, "gpt-5.6-sol": 2.5}


rows = []
with METRICS.open(newline="", encoding="utf-8-sig") as stream:
    for row in csv.DictReader(stream):
        model = row["model"]
        rates = STANDARD_CREDITS_PER_MILLION.get(model)
        if rates is None:
            rows.append({"segment": int(row["segment_no"]), "model": model, "status": "UNPRICED_INTERNAL_MODEL"})
            continue
        multiplier = FAST_MULTIPLIER[model] if row["tier"] == "priority" else 1.0
        total_input = int(row["final_task_input_tokens"])
        cached = int(row["final_task_cached_input_tokens"])
        noncached = total_input - cached
        output = int(row["final_task_output_tokens"])
        credits = {
            "noncached_input": noncached / 1_000_000 * rates["input"] * multiplier,
            "cached_input": cached / 1_000_000 * rates["cached"] * multiplier,
            "output": output / 1_000_000 * rates["output"] * multiplier,
        }
        rows.append(
            {
                "segment": int(row["segment_no"]),
                "model": model,
                "tier": row["tier"],
                "fast_multiplier": multiplier,
                "tokens": {"noncached_input": noncached, "cached_input": cached, "output": output},
                "current_rate_card_credits": credits,
                "current_rate_card_credits_total": sum(credits.values()),
                "status": "CURRENT_RATE_CARD_COUNTERFACTUAL_NOT_HISTORICAL_RECONCILIATION",
            }
        )

known = [row for row in rows if "current_rate_card_credits_total" in row]
emit_json(
    json.dumps(
        {
            "segments": rows,
            "known_model_segments_current_rate_card_credits": sum(row["current_rate_card_credits_total"] for row in known),
            "excluded": "codex-auto-review and the 20 additional transient guardian submissions lack a locally established debit rate/token ledger",
            "boundary": "Frozen reference rates and multipliers are a plausibility check only. They do not establish the Sep. 15 historical rate card, plan allowance application, credit-to-currency conversion, or debits.",
        },
        indent=2,
        sort_keys=True,
    )
)
