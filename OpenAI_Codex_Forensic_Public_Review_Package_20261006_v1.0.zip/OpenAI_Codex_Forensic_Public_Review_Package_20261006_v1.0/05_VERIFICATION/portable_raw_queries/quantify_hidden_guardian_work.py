#!/usr/bin/env python3
from __future__ import annotations

import csv
import datetime as dt
import json
import pathlib
import os
import pathlib as _runtime_pathlib
import sys as _runtime_sys
_runtime_sys.path.insert(0, str(_runtime_pathlib.Path(__file__).resolve().parent))
from _runtime import require_env, load_roots, public_id, emit_json, helper_help
helper_help(__file__)
import re
import sqlite3


RAW = pathlib.Path(require_env("OPENAI_DISPUTE_RAW_ROOT"))
SAFE = pathlib.Path(require_env("OPENAI_DISPUTE_SAFE_ROOT"))
START_DT = dt.datetime(2026, 9, 16, 0, 56, 11, 652000, tzinfo=dt.timezone.utc)
END_DT = dt.datetime(2026, 9, 16, 1, 7, 47, 632000, tzinfo=dt.timezone.utc)
START = int(START_DT.timestamp())
END = int(END_DT.timestamp())


def ro(path: pathlib.Path) -> sqlite3.Connection:
    connection = sqlite3.connect(f"file:{path.as_posix()}?mode=ro&immutable=1", uri=True)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only=ON")
    return connection


state = ro(RAW / "state_5.sqlite")
guardian_rows = state.execute(
    "SELECT id, created_at_ms, updated_at_ms, tokens_used, source, thread_source FROM threads WHERE model='codex-auto-review'"
).fetchall()
guardian_ids = {row["id"] for row in guardian_rows}
public_guardian_ids = {public_id(i) for i in guardian_ids}
state.close()

logs = ro(RAW / "logs_2.sqlite")
submissions = logs.execute(
    "SELECT ts, ts_nanos, thread_id, feedback_log_body FROM logs WHERE ts BETWEEN ? AND ? "
    "AND module_path='codex_core::session::handlers' AND feedback_log_body LIKE '%Submission sub=Submission%' "
    "AND feedback_log_body LIKE '%op: TurnInput%' ORDER BY ts, ts_nanos",
    (START, END),
).fetchall()
logs.close()

guardian_events = []
user_events = []
for row in submissions:
    body = row["feedback_log_body"] or ""
    timestamp = dt.datetime.fromtimestamp(row["ts"], tz=dt.timezone.utc).replace(microsecond=row["ts_nanos"] // 1000).isoformat()
    client = re.search(r'client_id: Some\("([^"]+)"\)', body)
    text_match = re.search(r'Text \{ text: "((?:\\.|[^"\\])*)"', body)
    text = ""
    if text_match:
        try:
            text = json.loads('"' + text_match.group(1) + '"')
        except json.JSONDecodeError:
            text = text_match.group(1)
    event = {
        "timestamp_utc": timestamp,
        "thread_id": row["thread_id"],
        "body_bytes": len(body.encode("utf-8")),
        "input_bytes": len(text.encode("utf-8")),
        "has_client_id": bool(client),
        "priority_override": 'service_tier: Some(Some("priority"))' in body,
    }
    if row["thread_id"] in guardian_ids and not client:
        guardian_events.append(event)
    else:
        event["short_input"] = text.rstrip("\r\n") if len(text) <= 100 else None
        user_events.append(event)

guardian_by_thread: dict[str, dict[str, object]] = {}
for event in guardian_events:
    item = guardian_by_thread.setdefault(
        event["thread_id"],
        {"submissions": 0, "request_log_bytes": 0, "first_utc": event["timestamp_utc"], "last_utc": event["timestamp_utc"]},
    )
    item["submissions"] += 1
    item["request_log_bytes"] += event["body_bytes"]
    item["last_utc"] = event["timestamp_utc"]

with (SAFE / "token_usage_events.csv").open(newline="", encoding="utf-8-sig") as stream:
    token_rows = [row for row in csv.DictReader(stream) if row["thread_id"] in public_guardian_ids]
with (SAFE / "task_events.csv").open(newline="", encoding="utf-8-sig") as stream:
    task_rows = [row for row in csv.DictReader(stream) if row["session_id"] in public_guardian_ids or row["parent_thread_id"] in public_guardian_ids]

result = {
    "union_window_utc": [START_DT.isoformat(), END_DT.isoformat()],
    "guardian_threads_known_in_state": len(guardian_ids),
    "guardian_submissions_in_union": len(guardian_events),
    "guardian_by_thread": guardian_by_thread,
    "guardian_request_log_bytes_total": sum(event["body_bytes"] for event in guardian_events),
    "user_or_client_submissions_in_union": len(user_events),
    "user_or_client_events": user_events,
    "safe_token_rows_for_all_guardian_threads": len(token_rows),
    "safe_task_rows_for_all_guardian_threads": len(task_rows),
    "safe_guardian_token_timestamp_range": [
        min((row["timestamp"] for row in token_rows), default=None),
        max((row["timestamp"] for row in token_rows), default=None),
    ],
    "boundary": "Guardian submission count and serialized log bytes are established. Token/debit cost of transient guardian requests is not locally established.",
}
emit_json(json.dumps(result, indent=2, sort_keys=True))
