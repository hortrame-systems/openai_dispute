#!/usr/bin/env python3
from __future__ import annotations

import csv
import datetime as dt
import json
import pathlib


ROOT = pathlib.Path(__file__).resolve().parents[1]
INV = ROOT / "02_CURRENT_ANALYSES/36_EVENT_B_LOCAL_TASK_SEGMENT_INVENTORY_2056_2108_v0.1.csv"
METRICS = ROOT / "02_CURRENT_ANALYSES/38_EVENT_B_COMPLETE_LOCAL_WORKLOAD_METRICS_v0.1.csv"
SUMMARY = ROOT / "02_CURRENT_ANALYSES/38_EVENT_B_COMPLETE_LOCAL_WORKLOAD_SUMMARY_v0.1.json"
TOKEN = ROOT / "03_MINIMIZED_SAFE_EVIDENCE/EVENT_B_TOKEN_USAGE.csv"
LOGS = ROOT / "03_MINIMIZED_SAFE_EVIDENCE/EVENT_B_PROCESS_EVIDENCE.csv"
META = ROOT / "03_MINIMIZED_SAFE_EVIDENCE/OLD_ROOT_SESSION_METADATA.csv"
TASKS = ROOT / "03_MINIMIZED_SAFE_EVIDENCE/EVENT_B_TASK_ENDPOINTS.csv"
EXPECTED_PROCESS = "PROCESS_0002"
OLD_ROOT = "ID_0176"


def stamp(value: str) -> dt.datetime:
    return dt.datetime.fromisoformat(value.replace("Z", "+00:00"))


def read_csv(path: pathlib.Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as stream:
        return list(csv.DictReader(stream))


def fail(message: str) -> None:
    raise SystemExit("FAIL: " + message)


inventory = read_csv(INV)
metrics = read_csv(METRICS)
tokens = read_csv(TOKEN)
logs = read_csv(LOGS)
metadata = read_csv(META)
tasks = read_csv(TASKS)
if len(inventory) != 6 or len(metrics) != 6:
    fail("expected six inventory and metric rows")
metric_by_no = {row["segment_no"]: row for row in metrics}

task_index = {(row["source_file"], row["line_no"], row["raw_record_sha256"], row["payload_type"]) for row in tasks}
for segment in inventory:
    start_key = (segment["start_source_file"], segment["start_line_no"], segment["start_raw_record_sha256"], "task_started")
    end_key = (segment["end_source_file"], segment["end_line_no"], segment["end_raw_record_sha256"], "task_complete")
    if start_key not in task_index or end_key not in task_index:
        fail(f"segment {segment['segment_no']} endpoint missing")

calculated = []
for segment in inventory:
    start, end = stamp(segment["start_utc"]), stamp(segment["end_utc"])
    rows = [
        row for row in tokens
        if row["source_file"] == segment["start_source_file"] and start <= stamp(row["timestamp"]) <= end
    ]
    rows.sort(key=lambda row: stamp(row["timestamp"]))
    if not rows:
        fail(f"segment {segment['segment_no']} has no token rows")
    first, last = rows[0], rows[-1]
    input_delta = int(last["turn_input_tokens"]) - int(first["turn_input_tokens"])
    cached_delta = int(last["turn_cached_input_tokens"]) - int(first["turn_cached_input_tokens"])
    logical = last["thread_id"] or segment["session_id"]
    metric = metric_by_no[segment["segment_no"]]
    expected = {
        "logical_thread_id": logical,
        "response_accounting_updates": len(rows),
        "post_initial_continuations": max(0, len(rows) - 1),
        "final_task_input_tokens": int(last["turn_input_tokens"]),
        "final_task_cached_input_tokens": int(last["turn_cached_input_tokens"]),
        "final_task_output_tokens": int(last["turn_output_tokens"]),
        "post_initial_input_tokens": input_delta,
        "post_initial_cached_input_tokens": cached_delta,
        "post_initial_non_cached_input_tokens": input_delta - cached_delta,
        "first_usage_raw_record_sha256": first["raw_record_sha256"],
        "last_usage_raw_record_sha256": last["raw_record_sha256"],
    }
    for key, value in expected.items():
        if str(metric[key]) != str(value):
            fail(f"segment {segment['segment_no']} metric {key}: {metric[key]} != {value}")
    close = []
    for row in logs:
        if row["thread_id"] not in {logical, segment["session_id"]}:
            continue
        log_stamp = dt.datetime.fromtimestamp(float(row["ts"]), tz=dt.timezone.utc)
        if abs((log_stamp - start).total_seconds()) <= 2.0:
            close.append(row)
    if not close or not any(row["process_uuid"] == EXPECTED_PROCESS for row in close):
        fail(f"segment {segment['segment_no']} process evidence missing")
    calculated.append((segment, metric))

primary = [metric for segment, metric in calculated if segment["segment_role"] == "PRIMARY_ACUTE_TASK"]
extra = [metric for segment, metric in calculated if segment["segment_role"] != "PRIMARY_ACUTE_TASK"]
all_metrics = [metric for _, metric in calculated]


def total(rows: list[dict[str, str]], key: str) -> int:
    return sum(int(row[key]) for row in rows)


expected_summary = {
    "segments": 6,
    "primary_post_initial_input": 23408888,
    "primary_post_initial_cached": 23376896,
    "primary_post_initial_non_cached": 31992,
    "extra_post_initial_input": 2977623,
    "extra_post_initial_cached": 2974080,
    "extra_post_initial_non_cached": 3543,
    "complete_post_initial_input": 26386511,
    "complete_post_initial_cached": 26350976,
    "complete_post_initial_non_cached": 35535,
    "complete_final_task_input": 29225371,
    "complete_final_task_cached": 27501056,
    "complete_final_task_output": 19528,
    "extra_final_task_input": 4789986,
    "response_updates": 56,
    "post_initial_continuations": 50,
}
actual = {
    "segments": len(all_metrics),
    "primary_post_initial_input": total(primary, "post_initial_input_tokens"),
    "primary_post_initial_cached": total(primary, "post_initial_cached_input_tokens"),
    "primary_post_initial_non_cached": total(primary, "post_initial_non_cached_input_tokens"),
    "extra_post_initial_input": total(extra, "post_initial_input_tokens"),
    "extra_post_initial_cached": total(extra, "post_initial_cached_input_tokens"),
    "extra_post_initial_non_cached": total(extra, "post_initial_non_cached_input_tokens"),
    "complete_post_initial_input": total(all_metrics, "post_initial_input_tokens"),
    "complete_post_initial_cached": total(all_metrics, "post_initial_cached_input_tokens"),
    "complete_post_initial_non_cached": total(all_metrics, "post_initial_non_cached_input_tokens"),
    "complete_final_task_input": total(all_metrics, "final_task_input_tokens"),
    "complete_final_task_cached": total(all_metrics, "final_task_cached_input_tokens"),
    "complete_final_task_output": total(all_metrics, "final_task_output_tokens"),
    "extra_final_task_input": total(extra, "final_task_input_tokens"),
    "response_updates": total(all_metrics, "response_accounting_updates"),
    "post_initial_continuations": total(all_metrics, "post_initial_continuations"),
}
if actual != expected_summary:
    fail(f"aggregate mismatch: {actual}")

old_rows = [row for row in metadata if row["session_id"] == OLD_ROOT and not row["parent_thread_id"]]
old_rows.sort(key=lambda row: stamp(row["timestamp"]))
if not old_rows or old_rows[0]["timestamp"] != "2026-08-26T00:56:24.294Z":
    fail("old-root earliest metadata mismatch")

saved = json.loads(SUMMARY.read_text(encoding="utf-8"))
for key, value in expected_summary.items():
    if saved[key] != value:
        fail(f"summary JSON {key}: {saved[key]} != {value}")

print("PASS: included-evidence rederivation — six paired persisted segments")
print(json.dumps(actual, sort_keys=True))
