"""Rerun the included-evidence calculations. Controlled raw is optional and separate."""
from __future__ import annotations
import csv
import datetime as dt
import json
import math
import os
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
HELPERS = ROOT / "05_VERIFICATION/portable_raw_queries"
SAFE = ROOT / "07_SUBSTANTIVE_EVIDENCE/stage2safe"

def require(condition, message):
    if not condition:
        raise SystemExit("FAIL: " + message)

def run(name):
    env = os.environ.copy()
    env.update(OPENAI_DISPUTE_PACKAGE_ROOT=str(ROOT), OPENAI_DISPUTE_SAFE_ROOT=str(SAFE), PYTHONDONTWRITEBYTECODE="1")
    result = subprocess.run([sys.executable,"-X","utf8","-B",str(HELPERS/name)],env=env,cwd=ROOT,capture_output=True,text=True,encoding="utf-8")
    require(result.returncode == 0, name + ": " + (result.stdout+result.stderr).strip())
    return json.loads(result.stdout)

def read_csv(path):
    with path.open(newline="",encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))

def compare(actual, expected, path=""):
    if isinstance(actual,dict):
        require(set(actual)==set(expected),"JSON keys differ at "+path)
        for k in actual: compare(actual[k],expected[k],path+"/"+k)
    elif isinstance(actual,list):
        require(len(actual)==len(expected),"JSON list length differs at "+path)
        for i,(a,e) in enumerate(zip(actual,expected)): compare(a,e,path+"/"+str(i))
    elif isinstance(actual,(int,float)) and isinstance(expected,(int,float)):
        require(math.isclose(actual,expected,rel_tol=1e-11,abs_tol=1e-8),"number differs at "+path)
    else:
        require(actual==expected,"value differs at "+path)

def main():
    if "--help" in sys.argv:
        print(__doc__); return
    pairs = {
        "estimate_current_rate_card.py":"EVENT_B_CURRENT_RATE_SENSITIVITY.json",
        "estimate_event_a_weighted_proxy.py":"EVENT_A_WEIGHTED_PROXY_SENSITIVITY.json",
        "reconcile_balance_window_current_rates.py":"EVENT_B_BALANCE_WINDOW_CURRENT_RATE_SENSITIVITY.json",
        "estimate_guardian_transient_tokens.py":"EVENT_B_GUARDIAN_TRANSIENT_INPUT_DIAGNOSTIC.json",
    }
    for helper,expected in pairs.items():
        calculated=run(helper)
        saved=json.loads((ROOT/"03_CORRECTED_DERIVED_EVIDENCE"/expected).read_text(encoding="utf-8"))
        compare(calculated,saved,expected)
        print("PASS: included reproduction "+helper)
    cohort = json.loads((ROOT/"03_CORRECTED_DERIVED_EVIDENCE/PRIORITY_COHORT_RECOMPUTATION.json").read_text(encoding="utf-8"))
    start=dt.datetime.fromisoformat(cohort["start_utc_inclusive"].replace("Z","+00:00"))
    end=dt.datetime.fromisoformat(cohort["end_utc_exclusive"].replace("Z","+00:00"))
    counters={model:{"priority":0,"default":0,"missing_tier_excluded":0} for model in cohort["included_models"]}
    for row in read_csv(SAFE/"thread_settings_events.csv"):
        if row["model"] not in counters: continue
        stamp=dt.datetime.fromisoformat(row["timestamp"].replace("Z","+00:00"))
        if start<=stamp<end:
            key=row["service_tier"] if row["service_tier"] in {"priority","default"} else "missing_tier_excluded"
            counters[row["model"]][key]+=1
    for model,count in counters.items(): compare(count,cohort["counts"][model],model)
    require(sum(c["priority"] for c in counters.values())==1441,"Priority cohort differs")
    require(sum(c["priority"]+c["default"] for c in counters.values())==1444,"known-tier denominator differs")
    print("PASS: full included settings cohort 1441/1444 Priority; not billed-token share")
    export=json.loads((ROOT/"03_CORRECTED_DERIVED_EVIDENCE/PUBLIC_WORKSPACE_EXPORT_AGGREGATES.json").read_text(encoding="utf-8"))
    total=export["fast_labelled_credits"]+export["standard_credits"]+export["other_credits"]
    require(math.isclose(total,export["purchased_credits_total"],abs_tol=1e-8),"examined export aggregate sum")
    require(math.isclose(export["fast_labelled_share_percent"],export["fast_labelled_credits"]/total*100,abs_tol=1e-8),"examined Fast-label share")
    sensitivity=json.loads((ROOT/"03_CORRECTED_DERIVED_EVIDENCE/PUBLIC_MULTIPLIER_SENSITIVITY.json").read_text(encoding="utf-8"))
    for s in sensitivity["scenarios"]:
        m=s["multiplier"]
        require(math.isclose(s["window_credits"],651.3204*m/2.5,abs_tol=1e-8),"multiplier-only window sensitivity")
        require(math.isclose(s["full_export_conditional_premium"],export["fast_labelled_credits"]-export["fast_labelled_credits"]/m,abs_tol=1e-8),"conditional premium sensitivity")
    print("PASS: examined-export aggregate arithmetic and 1x/2x/2.5x sensitivity; original rows/historical terms unverified")
    print("BOUNDARY: frozen assumptions, extraction-dependent observations and provider ledgers remain distinct.")

if __name__=="__main__":
    main()
