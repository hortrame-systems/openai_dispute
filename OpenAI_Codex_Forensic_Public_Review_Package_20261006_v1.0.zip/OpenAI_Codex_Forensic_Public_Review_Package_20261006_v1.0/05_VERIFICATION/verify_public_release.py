"""Verify the distributed public universe and bounded calculations; no causal certification."""
from __future__ import annotations
import csv
import hashlib
import json
import pathlib
import re
import subprocess
import sys

ROOT=pathlib.Path(__file__).resolve().parents[1]
EXCLUDED={"MANIFEST.csv","SHA256SUMS.txt"}

def fail(message):
    raise SystemExit("FAIL: "+message)

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def read_csv(p):
    with p.open(newline="",encoding="utf-8-sig") as f: return list(csv.DictReader(f))

def main():
    if "--help" in sys.argv:
        print(__doc__); return
    rows=read_csv(ROOT/"MANIFEST.csv")
    expected={r["path"]:r for r in rows}
    actual={p.relative_to(ROOT).as_posix():p for p in ROOT.rglob("*") if p.is_file() and p.relative_to(ROOT).as_posix() not in EXCLUDED}
    if len(expected)!=len(rows) or set(expected)!=set(actual): fail("positive membership mismatch")
    for name,r in expected.items():
        p=actual[name]
        if p.stat().st_size!=int(r["bytes"]) or digest(p)!=r["sha256"]: fail("manifest mismatch: "+name)
    sums={line[66:]:line[:64] for line in (ROOT/"SHA256SUMS.txt").read_text(encoding="utf-8").splitlines()}
    if sums!={k:r["sha256"] for k,r in expected.items()}: fail("SHA256SUMS mismatch")
    patterns={
        "UUID":rb"(?i)\b[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\b",
        "email":rb"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b",
        "OpenAI secret":rb"\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,}",
        "GitHub token":rb"\b(?:ghp|github_pat)_[A-Za-z0-9_]{20,}",
        "AWS key":rb"\bAKIA[0-9A-Z]{16}\b",
        "private key":rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----",
        "session cookie":rb"\b(?:__oailb|__cf_bm)=",
        "private mail URL":rb"https?://mail\.google\.com/",
        "raw case number":rb"Case Number:\s*\d{6,}",
    }
    for name,p in actual.items():
        data=p.read_bytes()
        if any(x in pathlib.PurePosixPath(name).parts for x in {"raw_codex",".git","__pycache__"}): fail("excluded material: "+name)
        if p.name in {"auth.json","support_source_snapshot.json","private_mapping.json"}: fail("private source: "+name)
        for label,pattern in patterns.items():
            if re.search(pattern,data): fail("possible "+label+": "+name)
        if p.suffix==".json": json.loads(data)
        if p.suffix==".py": compile(data,str(p),"exec")
        if p.suffix==".md":
            for target in re.findall(r"\[[^\]]+\]\(([^)]+)\)",data.decode("utf-8")):
                target=target.strip("<>").split("#",1)[0]
                if target and ":" not in target and not (p.parent/target).exists(): fail("unresolved Markdown link: "+name+" -> "+target)
    for r in read_csv(ROOT/"SOURCE_PROVENANCE.csv"):
        if r["public_path"]:
            p=ROOT/r["public_path"]
            if not p.is_file() or digest(p)!=r["public_sha256"]: fail("source/public binding: "+r["public_path"])
    for rel in ["02_CURRENT_ANALYSES/ANALYSIS_INDEX.csv","07_SUBSTANTIVE_EVIDENCE/SUBSTANTIVE_INVENTORY.csv"]:
        for r in read_csv(ROOT/rel):
            p=ROOT/r["path"]
            if not p.is_file() or digest(p)!=r["sha256"] or p.stat().st_size!=int(r["bytes"]): fail("index binding: "+r["path"])
    coverage=read_csv(ROOT/"07_EXTERNAL_REVIEW_MATERIALS/CLAIM_SOURCE_COVERAGE.csv")
    if len(coverage)!=39 or len({r["claim_id"] for r in coverage})!=39: fail("legacy technical claim coverage")
    for r in coverage:
        for source in r["source_paths"].split(";"):
            if source.strip() and not (ROOT/source.strip()).is_file(): fail("claim source path: "+r["claim_id"])
        if not r.get("public_category"): fail("unclassified claim")
    claims=read_csv(ROOT/"02_PUBLIC_REVIEW/CLAIMS.csv")
    if len(claims)!=46 or not all(r.get("public_category") for r in claims): fail("public categories")
    for rel in ["README.md","PUBLIC_RELEASE_NOTES.md","CHANGELOG.md","DELIBERATE_OMISSIONS.md","02_PUBLIC_REVIEW/SUPPORT_HISTORY.md","09_PUBLICATION_DRAFTS/GITHUB_POST.md","09_PUBLICATION_DRAFTS/DEVELOPER_COMMUNITY_POST.md","09_PUBLICATION_DRAFTS/JOURNALIST_COVER_NOTE.md"]:
        if rel not in actual: fail("missing public deliverable: "+rel)
    supports=json.loads((ROOT/"02_PUBLIC_REVIEW/SUPPORT_EXCERPTS.json").read_text(encoding="utf-8"))
    if [m["case"] for m in supports["messages"]]!=["CASE_A","CASE_A","CASE_B","CASE_C"]: fail("support chronology")
    diagnostic=json.loads((ROOT/"03_CORRECTED_DERIVED_EVIDENCE/EVENT_B_GUARDIAN_TRANSIENT_INPUT_DIAGNOSTIC.json").read_text(encoding="utf-8"))
    if diagnostic["current_estimate"] is not None: fail("withdrawn guardian range promoted")
    for script in sorted((ROOT/"05_VERIFICATION/portable_raw_queries").glob("*.py")):
        p=subprocess.run([sys.executable,"-X","utf8","-B",str(script),"--help"],capture_output=True,text=True,encoding="utf-8",cwd=ROOT)
        if p.returncode: fail("helper smoke test: "+script.name)
    inspector=subprocess.run([sys.executable,"-X","utf8","-B",str(ROOT/"05_VERIFICATION/inspect_codex_tiers.py"),"--help"],capture_output=True,text=True,encoding="utf-8",cwd=ROOT)
    if inspector.returncode: fail("diagnostic helper smoke test")
    for rel in ["05_VERIFICATION/verify_event_b_v1.6.2.py","05_VERIFICATION/run_included_reproductions.py"]:
        p=subprocess.run([sys.executable,"-X","utf8","-B",str(ROOT/rel)],capture_output=True,text=True,encoding="utf-8",cwd=ROOT)
        if p.returncode: fail(rel+": "+(p.stdout+p.stderr).strip())
        print(p.stdout.strip())
    print("PASS: exact public membership, every manifest/SHA256SUMS hash and source/public binding")
    print("PASS: all-file bounded secret/identifier scan; private mapping/raw corpus excluded")
    print("PASS: current Markdown/claim paths, classifications, support chronology and withdrawn estimate")
    print("PASS: every bundled Python program compiles; helper modes execute; included calculations rederive")
    print("BOUNDARY: source acquisition/authentication, causation, privacy beyond these checks and provider reconciliation require separate evidence/review.")

if __name__=="__main__":
    main()
