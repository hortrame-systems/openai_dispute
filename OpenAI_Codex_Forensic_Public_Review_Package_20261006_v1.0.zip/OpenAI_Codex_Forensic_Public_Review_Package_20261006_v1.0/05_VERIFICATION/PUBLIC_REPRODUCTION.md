# Reproduction and access boundaries

All Python programs use the standard library. Use Python 3.11+ in a fresh local virtual environment. The archive does not invoke APIs, change Codex settings or install dependencies.

## Included evidence

From the extracted package root:

```text
python -B 05_VERIFICATION/verify_public_release.py
python -B 05_VERIFICATION/run_included_reproductions.py
```

The checks rederive the six-segment totals, frozen-rate sensitivities, known-tier cohort and the guardian estimator's demonstrated counter error. Their assertions do not authenticate the underlying extraction or prove provider accounting correctness.

Broad structured tables preserve row counts and numeric/tier fields; identifiers use one consistent public alias space. Original raw-record hashes remain source provenance, not the hash of the redacted row. `SOURCE_PROVENANCE.csv` records file transformations and omitted originals.

## Controlled-source checks

Four portable helpers query the confidential snapshot: submission, guardian-scope, execution-path and cache-state extraction. They need read-only access to the original SQLite snapshot. Selection by original identities additionally requires the private identity map kept outside this archive.

Set `OPENAI_DISPUTE_RAW_ROOT`, `OPENAI_DISPUTE_PACKAGE_ROOT`, `OPENAI_DISPUTE_SAFE_ROOT` and `OPENAI_DISPUTE_PRIVATE_MAP` to the authorized local sources. The package/safe roots select this public package and its structured tables. Missing controlled access produces an explicit dependency exit rather than invented output. Each helper's `--help` explains its mode.

The SQLite helpers use read-only immutable connections and query-only pragmas. They never search an installed user's home as a fallback. Outputs are projected through the private alias map where provided; any new unrecognized source detail must be reviewed privately before sharing.

Confidential prompts, operational content, auth material, full correspondence and private mapping are not included. Controlled rederivation can test extraction under authorized access; public recipients can rederive the distributed arithmetic and inspect provenance without that access. These are different claims.

## Test your own data

`inspect_codex_tiers.py --root PATH` scans only an explicitly chosen local snapshot and prints file aliases, line numbers, timestamps and nested tier fields. It omits prompt bodies. Its output remains private because timestamps and rare patterns can be linkable. A field in quoted JSON or tool/user content is a lead, not automatically request-tier evidence.

Public sharing should use aggregate observations and redacted examples. Preserve original evidence privately before changing settings. A public archive's size is not a measure of evidentiary completeness.
