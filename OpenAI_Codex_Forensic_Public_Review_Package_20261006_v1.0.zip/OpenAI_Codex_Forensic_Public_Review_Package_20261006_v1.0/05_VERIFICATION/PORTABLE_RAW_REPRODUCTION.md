# Controlled-source reproduction

Use [the public reproduction guide](PUBLIC_REPRODUCTION.md) for this release's current commands and access requirements.

Included arithmetic runs from the extracted public archive. SQLite-source extraction requires the retained read-only snapshot and the private source-identity map. Source roots are explicit environment inputs; no installed-home fallback is used.

Earlier private-package paths and delivery instructions are superseded for the public edition.
