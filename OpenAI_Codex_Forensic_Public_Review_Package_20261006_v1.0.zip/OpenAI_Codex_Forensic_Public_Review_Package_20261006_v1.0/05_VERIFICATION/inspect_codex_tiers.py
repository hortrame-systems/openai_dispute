"""Inspect an explicitly selected local snapshot without emitting prompt bodies."""
from __future__ import annotations
import argparse
import hashlib
import json
import re
from pathlib import Path

KNOWN_KEYS={"payload","data","metadata","response","request","params","turn_context","settings","record","service_tier"}
KNOWN_TYPES={"session_meta","turn_context","event_msg","response_item","request","response","task_started","task_complete"}
KNOWN_TIERS={"priority","fast","default","standard","auto","flex","ultrafast","scale"}

def alias(value):
    return hashlib.sha256(str(value).encode()).hexdigest()[:12]

def tiers(value, path=""):
    if isinstance(value,dict):
        for k,v in value.items():
            safe_key=k if k in KNOWN_KEYS else "KEY_"+alias(k)
            field=f"{path}.{safe_key}" if path else safe_key
            if k.casefold()=="service_tier" and isinstance(v,str):
                yield field,v if v in KNOWN_TIERS else "UNRECOGNIZED_TIER_VALUE_WITHHELD"
            yield from tiers(v,field)
    elif isinstance(value,list):
        for i,v in enumerate(value):
            yield from tiers(v,f"{path}[{i}]")

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root",type=Path,required=True)
    ap.add_argument("--count-fast-files",action="store_true")
    args=ap.parse_args()
    root=args.root.resolve(strict=True)
    files=0
    fast_files=0
    for directory in (root/"sessions",root/"archived_sessions"):
        if not directory.is_dir(): continue
        for p in sorted(directory.rglob("*.jsonl")):
            if p.is_symlink(): continue
            files+=1
            file_alias="SOURCE_"+hashlib.sha256(p.relative_to(root).as_posix().encode()).hexdigest()[:12]
            contains_fast=False
            with p.open(encoding="utf-8",errors="replace") as f:
                for line_number,line in enumerate(f,1):
                    contains_fast |= "/fast" in line
                    try: value=json.loads(line)
                    except json.JSONDecodeError: continue
                    if not isinstance(value,dict): continue
                    timestamp=value.get("timestamp","")
                    if not isinstance(timestamp,str) or not re.fullmatch(r"\d{4}-\d\d-\d\dT[0-9:.+-]+Z?",timestamp):
                        timestamp="TIMESTAMP_VALUE_WITHHELD"
                    event_type=value.get("type","")
                    if not isinstance(event_type,str) or event_type not in KNOWN_TYPES:
                        event_type="TYPE_"+alias(event_type)
                    for field,tier in tiers(value):
                        print(json.dumps({"source_alias":file_alias,"line":line_number,"timestamp":timestamp,"event_type":event_type,"field":field,"tier":tier},sort_keys=True))
            fast_files+=contains_fast
    if args.count_fast_files:
        print(json.dumps({"scanned_jsonl_files":files,"files_containing_literal_fast":fast_files,"boundary":"Literal matches and nested fields are leads; quoted/user/tool JSON does not establish authoritative request tier or authorization."},sort_keys=True))

if __name__=="__main__":
    main()
